<?php
require("db/connection.php");
$id = $_POST['id'];
?>
<div class="p-3 m-auto">
    <?php
    $q = "SELECT * FROM decorator WHERE baid=$id AND del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
        $result = mysqli_fetch_array($query);
    ?>
    <div class="row">
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <?php
                        if ($result['venue_decoration'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Venue Decoration Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['venue_deco_price']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['outdoor_decoration'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Outdoor Decoration Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['venue_deco_price']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <tr class="py-2 px-1" id="deco_price">
                        <td class="text-secondary h6 text-left">Tent Rent Per Day</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['tent_price']; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Table Decoration Price</td>
                        <td class="text-dark h6 text-right"><?php if ($result['table_deco_price'] != 0) {
                                                                    echo $result['table_deco_price'];
                                                                } ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Chair Decoration Price</td>
                        <td class="text-dark h6 text-right"><?php if ($result['chair_deco_price'] != 0) {
                                                                    echo $result['chair_deco_price'];
                                                                } ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Welcome Area Decoration Price</td>
                        <td class="text-dark h6 text-right"><?php if ($result['welcome_deco_price'] != 0) {
                                                                    echo $result['welcome_deco_price'];
                                                                } ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Car Decoration Price per car</td>
                        <td class="text-dark h6 text-right"><?php if ($result['car_deco_price'] != 0) {
                                                                    echo $result['car_deco_price'];
                                                                } ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-1 mb-2 text-left">
        <span class="h6 text-dark pr-1">Other Services:</span><span
            class="text-warp"><?php echo $result['other_service']; ?></span>
    </div>
    <?php
    }
    ?>

<!DOCTYPE html>
<html lang="en" class="h-100">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MyEvent | Registration</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!-- CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/floating-labels.css">
        <!--  -->
    </head>

    <body class="d-flex flex-column h-100">
        <div class="text-center">
            <img src="img/MyEvent.png" class="w-25" alt="MyEvent Image">
        </div>
        <form id="regForm" class="form-signin" method="post">
            <div class="text-center mb-4">
                <h1 class="h3 mb-3 font-weight-normal">Create Your MyEvent Account</h1>
            </div>
            <div>
                <div class="text-center mb-4">
                    <h1 class="h5 mb-3 font-weight-normal">Choose an Account Type</h1>
                </div>
                <div class="form-label-group">
                    <div class="border w-100 h-100 text-center d-flex flex-row bg-white m-auto">
                        <div class="w-50 flex-column border" id="utp">
                            <div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
                                <label class="btn pt-lg-2 pb-lg-1">
                                    <input type="radio" name="user_type" value="personal" class="form-check-input p-2"
                                        required autofocus>
                                    <p class="h4 text-black-50">Personal</p>
                                </label>
                            </div>
                        </div>
                        <div class="w-50 flex-column border" id="utb">
                            <div class="btn-group btn-group-toggle w-100" data-toggle=" buttons">
                                <label class="btn pt-lg-2 pb-lg-1">
                                    <input type="radio" name="user_type" value="business" class="form-check-input p-2"
                                        required autofocus>
                                    <p class="h4 text-black-50">Business</p>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center mb-4">
                    <h1 class="h5 mb-3 font-weight-normal">Add Personal info</h1>
                </div>
                <div id="error" class="text-center">
                </div>
                <div class="form-label-group">
                    <input type="text" name="name" id="inputName" onkeyup="chkname(this)" class="form-control"
                        placeholder="Name" required autofocus>
                    <label for="inputName">Name</label>
                    <span id="errorname" class="text-danger"></span>
                </div>

                <div class="form-label-group">
                    <input type="text" col="15" row=3 name="address" id="inputAddress" onkeyup="chkaddress(this)"
                        class="form-control" placeholder="Address" required autofocus>
                    <label for="inputAddress">Address</label>
                    <span id="erroraddress" class="text-danger"></span>
                </div>

                <div class="form-label-group">
                    <input type="text" name="mono" id="inputMoNo" onkeyup="chkmono(this)" class="form-control"
                        placeholder="Mobile No" required autofocus>
                    <label for="inputMoNo">Mobile Number</label>
                    <span id="errormono" class="text-danger"></span>
                </div>
                <div class="form-label-group">
                    <input type="email" name="email" id="inputEmail" onkeyup="chkemail(this)" class="form-control"
                        placeholder="Email address" required autofocus>
                    <label for="inputEmail">Email address</label>
                    <span id="erroremail" class="text-danger"></span>
                </div>

                <div class="form-label-group">
                    <input type="password" name="password" id="inputPassword" onkeyup="chkpass(this)"
                        class="form-control" placeholder="Password" required>
                    <label for="inputPassword">Enter Password</label>
                    <span id="errorpass" class="text-danger"></span>
                </div>
                <div class="form-label-group">
                    <input type="password" name="con_password" id="inputCon_Password" onchange="chkcon_pass(this)"
                        class="form-control" placeholder="Password" required>
                    <label for="inputCon_Password">Enter Confirm Password</label>
                    <span id="errorcon_pass" class="text-danger"></span>
                </div>
            </div>
            <button class="btn btn-lg btn-primary btn-block mb-2" name="submit" type="submit">Sign
                Up</button>
        </form>

        <?php

    if (isset($_POST['submit'])) {
        require("db/connection.php");
        $name = $_POST['name'];
        $mono = $_POST['mono'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $address = $_POST['address'];
        $user_type = $_POST['user_type'];
        $cs = mysqli_query($connection, "select * from user where mono='$mono' OR email='$email'");
        $row = mysqli_num_rows($cs);
        if ($row == 0) {
            mysqli_query($connection, "INSERT INTO `user`(`name`, `address`, `mono`, `email`, `password`, `type`) VALUES ('" . $name . "','" . $address . "','" . $mono . "','" . $email . "','" . $pass . "','" . $user_type . "')");
            header("Location:./login.php");
        } else {
            echo ('<script type="text/javascript">document.getElementById(\'error\').innerHTML="<label class=\"alert alert-danger\">This Phone Number Or Email is Already Exist.<a href=\"login.php\">Login</a></label>";
					</script>');
        }
    }
    ?>

        <!-- footer -->
        <footer class="footer mt-auto py-3 bg-light text-center">
            <div class="container">
                <span class="text-muted">Copyrights &copy;2020-21. All Rights Resevered by MyEvent.</span>
            </div>
        </footer>
        <!--  -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script type="text/javascript">
        function chkname(name) {
            if (name.value.length === 0) {
                document.getElementById('errorname').innerHTML = "Please Enter Name.";
                document.getElementByName('name').focus();
                return false;
            } else {
                document.getElementById('errorname').innerHTML = "";
                return true;
            }
        }

        function chkaddress(address) {
            if (address.value.length === 0) {
                document.getElementById('erroraddress').innerHTML = "Please Enter Address.";
                document.getElementByName('address').focus();
                return false;
            } else {
                document.getElementById('erroraddress').innerHTML = "";
                return true;
            }
        }

        function chkemail(email) {
            if (email.value.length === 0) {
                document.getElementById('erroremail').innerHTML = "Please Enter Email.";
                document.getElementByName('email').focus();
                return false;
            } else {
                document.getElementById('erroremail').innerHTML = "";
                return true;
            }
        }

        function chkpass(pass) {
            if (pass.value.length === 0) {
                document.getElementById('errorpass').innerHTML = "Please Enter Password.";
                document.getElementByName('password').focus();
                return false;
            }
            if (pass.value.length < 8 || pass.value.length > 20) {
                document.getElementById('errorpass').innerHTML = "Please Enter Password length must be 8 to 20.";
                document.getElementByName('password').focus();
                return false;
            } else {
                document.getElementById('errorpass').innerHTML = "";
                return true;
            }
        }

        function chkcon_pass(con_pass) {
            if (con_pass.value.length === 0) {
                document.getElementById('errorcon_pass').innerHTML = "Please Enter Confirm Password.";
                document.getElementByName('con_password').focus();
                return false;
            }
            if ($("#inputCon_Password").val() != $("#inputPassword").val()) {
                document.getElementById('errorcon_pass').innerHTML = "Confirm Password must be not match.";
                document.getElementByName('con_password').focus();
                return false;
            } else {
                document.getElementById('errorcon_pass').innerHTML = "";
                return true;
            }
        }

        function chkmono(mono) {
            if (isNaN(mono.value)) {
                document.getElementById('errormono').innerHTML = "Please Enter Only Digits.";
                document.getElementByName('mono').focus();
            }
            if (mono.value.length === 10) {
                document.getElementById('errormono').innerHTML = "";
            } else {
                document.getElementById('errormono').innerHTML = "Please Enter 10 Digit Phone Number.";
                document.getElementByName('mono').focus();
            }
        }
        </script>

        <!-- ---------------------------------------- -->
    </body>

</html>

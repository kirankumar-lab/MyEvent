<?php
require("session_personal.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    header("./decorator.php");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Photographer</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->

    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4 w-100">
            <?php
        require("db/connection.php");
        $q = "select * from photographer,business_account where photographer.del=0 and business_account.baid=photographer.baid and business_account.baid=$id";
        $query = mysqli_query($connection, $q);
        if (mysqli_num_rows($query) > 0) {
            $result = mysqli_fetch_array($query);
        ?>
            <div class="container-fluid py-3 border-bottom border-dark">
                <span class="h3">Booking Photographer</span>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-4 border-bottom p-1 pb-5">
                        <div class="border-0 border-bottom h4 text-center text-capitalize"><span>Photographer
                                Details</span>
                        </div>
                        <div class="h6 text-capitalize">photographer Name: <span
                                class="text-primary"><?php echo $result['name_organization']; ?></span>
                        </div>

                        <?php
                        if ($result['photo_day'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Photography 1 Day Price: <span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['photo_day']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['photo_vedio_day'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Photography + Vedio 1 Day Price:<span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['photo_vedio_day']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['photo_2_day'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Photography 2 Day Price: <span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['photo_2_day']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['photo_vedio_2_day'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Photography + Vedio 2 Day Price:<span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['photo_vedio_2_day']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['photo_3_day'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Photography 3 Day Price: <span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['photo_3_day']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['photo_vedio_3_day'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Photography + Vedio 3 Day Price:<span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['photo_vedio_3_day']; ?></span>
                        </div>
                        <?php
                        }
                        ?>
                        <?php
                        if ($result['album'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Album Price Additionally:<span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['album']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                    </div>
                    <div class="col-12 col-md-8 border-bottom p-1 pb-5">
                        <form method="post">
                            <div class="border-0 border-bottom h4 text-center text-capitalize"><span>Fill Booking
                                    Details</span>
                            </div>

                            <?php
                            if ($result['photo_day'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="radio" name="pv[]" class="form-check-input" <?php echo $disabled; ?>
                                    required value="p1">
                                <label for="pv" class="form-label">Photography 1 Day</label>
                            </div>
                            <?php
                            if ($result['photo_2_day'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="radio" name="pv[]" class="form-check-input" <?php echo $disabled; ?>
                                    required value="p2">
                                <label for="pv" class="form-label">Photography 2 Day</label>
                            </div>
                            <?php
                            if ($result['photo_3_day'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="radio" name="pv[]" class="form-check-input" <?php echo $disabled; ?>
                                    required value="p3">
                                <label for="pv" class="form-label">Photography 3 Day</label>
                            </div>
                            <?php
                            if ($result['photo_vedio_day'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="radio" name="pv[]" class="form-check-input" <?php echo $disabled; ?>
                                    required value="pv1">
                                <label for="pv" class="form-label">Photography + Vedio 1 Day</label>
                            </div>

                            <?php
                            if ($result['photo_vedio_2_day'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="radio" name="pv[]" class="form-check-input" <?php echo $disabled; ?>
                                    required value="pv2">
                                <label for="pv" class="form-label">Photography + Vedio 2 Day</label>
                            </div>
                            <?php
                            if ($result['photo_vedio_3_day'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="radio" name="pv[]" class="form-check-input" <?php echo $disabled; ?>
                                    required value="pv3">
                                <label for="pv" class="form-label">Photography + Vedio 3 Day</label>
                            </div>
                            <?php
                            if ($result['album'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="checkbox" name="album[]" class="form-check-input" <?php echo $disabled; ?>
                                    value="1">
                                <label for="album" class="form-label">Album Additionally</label>
                            </div>

                            <div class="h5 text-capitalize">
                                <label for="book_date_from" class="form-label">date from:</label>
                                <input type="date" name="book_date_from" id="book_date_from" class="form-control"
                                    required title="Select Date From">
                            </div>
                            <div class="text-capitalize">
                                <label for="payment_type" class="form-label">Payment Type:</label>
                                <select name="payment_type" id="payment_type" class="form-select"
                                    onchange="change_pay_type()">
                                    <option value="online">Online</option>
                                    <option value="offline">Offline</option>
                                </select>
                            </div>
                            <div class="text-capitalize">
                                <span class="text-danger justify-content-around p-2" id="off_dl"><sup>*</sup>You Pay
                                    money at photographer office or studio and confirm your booking by vendor in 1
                                    hours. after 1 hours expired
                                    your booking request.</span>
                                <br>
                                <button class="btn btn-success" type="submit" name="submit" id="submit">Book the
                                    Photographer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        </main>
        <!-- ---- -->

        <!-- Booking Process -->
        <?php
    if (isset($_POST['submit'])) {
        $uid = $_SESSION['uid'];
        $baid = $id;
        $book_date_from = $_POST['book_date_from'];
        $book_date_from = date("Y-m-d", strtotime($book_date_from));

        $photo_day = 0;
        $photo_vedio_day = 0;
        $photo_2_day = 0;
        $photo_vedio_2_day = 0;
        $photo_3_day = 0;
        $photo_vedio_3_day = 0;

        if (isset($_POST['album'])) {
            foreach ($_POST['album'] as $dc) {
                $album = $dc;
                $album_price = $result['album'];
            }
        } else {
            $album = 0;
            $album_price = 0;
        }
        if (isset($_POST['pv'])) {
            foreach ($_POST['pv'] as $dc) {
                $pv = $dc;
            }
        }
        if ($pv == "p1" || $pv == "pv1") {
            $day = 1;
            if ($pv == "p1") {
                $photo_day = 1;
                $amount = $result['photo_day'];
            }
            if ($pv == "pv1") {
                $photo_vedio_day = 1;
                $amount = $result['photo_vedio_day'];
            }
        }
        if ($pv == "p2" || $pv == "pv2") {
            $day = 2;
            if ($pv == "p2") {
                $photo_2_day = 1;
                $amount = $result['photo_2_day'];
            }
            if ($pv == "pv2") {
                $photo_vedio_2_day = 1;
                $amount = $result['photo_vedio_2_day'];
            }
        }
        if ($pv == "p3" || $pv == "pv3") {
            $day = 3;
            if ($pv == "p3") {
                $photo_3_day = 1;
                $amount = $result['photo_3_day'];
            }
            if ($pv == "pv3") {
                $photo_vedio_3_day = 1;
                $amount = $result['photo_vedio_3_day'];
            }
        }
        $book_date_to = date("Y-m-d", strtotime($book_date_from . '+ ' . $day . ' days' . '- 1 days'));

        $payment_type = $_POST['payment_type'];
        if ($payment_type == "online") {
            $confirm = 1;
        } else {
            $confirm = 0;
        }

        $amount = $amount + $album_price;

        $currentdate = date('Y-m-d');
        if ($book_date_to >= $book_date_from) {
            $q = "SELECT `book_date_from`,`book_date_to` FROM `booking` WHERE `baid`=$baid AND `cancle`=0 AND '$book_date_from'>=CURRENT_DATE AND '$book_date_to'>=CURRENT_DATE AND `book_date_from` BETWEEN '$book_date_from' AND '$book_date_to' AND `book_date_to` BETWEEN '$book_date_from' AND '$book_date_to'";
            $run = mysqli_query($connection, $q);
            if (mysqli_num_rows($run) > 0) {
                echo '<script>alert("Already Booked By Another User on this date.");</script>';
            } else {
                if ($book_date_from >= $currentdate) {
                    $q = "INSERT INTO `booking`(`uid`, `baid`, `book_date_from`, `book_date_to`, `amount`, `payment_type`, `confirm`) VALUES ($uid,$baid,'$book_date_from','$book_date_to',$amount,'$payment_type',$confirm)";
                    $r = mysqli_query($connection, $q);
                    if ($r) {
                        $q = "SELECT `book_id` FROM `booking` WHERE `uid`=$uid AND `baid`=$baid ORDER BY `book_id` DESC LIMIT 1";
                        $r = mysqli_fetch_array(mysqli_query($connection, $q));
                        $book_id = $r['book_id'];

                        $q = "INSERT INTO `booking_photographer`(`baid`, `book_id`, `photo_day`, `photo_vedio_day`, `photo_2_day`, `photo_vedio_2_day`, `photo_3_day`, `photo_vedio_3_day`, `album`, `total_amount`) VALUES ($baid,$book_id,$photo_day,$photo_vedio_day,$photo_2_day,$photo_vedio_2_day,$photo_3_day,$photo_vedio_3_day,$album,$amount)";
                        mysqli_query($connection, $q);

                        echo '<script>window.location="./booking.php";</script>';
                    }
                } else {
                    echo '<script>alert("Select Vaild Date");</script>';
                }
            }
        } else {
            echo '<script>alert("Select Vaild Date");</script>';
        }
    }
    ?>
        <!-- Booking Process END-->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        $(document).ready(function() {
            $('#off_dl').hide();
            change_pay_type();
        });

        function change_pay_type() {
            var pay = $('#payment_type').val();
            if (pay === "offline") {
                $('#submit').html("Booking request to the Photographer");
                $('#off_dl').show();
            } else {
                $('#submit').html("Book the Photographer");
                $('#off_dl').hide();
            }
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

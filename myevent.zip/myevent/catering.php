<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Catering</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        .venue {
            border-radius: 15px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }

        .chg-img {
            height: fit-content;
            width: fit-content;
            padding: 10px;
            margin: auto;
            background-color: rgba(0, 0, 0, 0.3);
        }

        .chg-img:hover {
            background-color: rgba(0, 0, 0, 1);
        }


        .venue-img {
            width: 100%;
            min-height: 250px;
            max-height: 300px;
            height: 250px;
        }

        </style>

        <!-- --------------------------------------------- -->

    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    session_start();
    if (empty($_SESSION)) {
        include("navbarVisitor.php");
    } else {
        require("session_personal.php");
        include("navbar.php");
    }
    ?>
        <!-- -----------Navbar & SideBar End------------ -->
        <!-- Main -->
        <main class="px-md-4 w-100">
            <div class="mr-2 p-3 border-bottom">

                <label class="form-label text-uppercase font-weight-bolder pt-1" for="search_user">Search Catering:
                </label>
                <input type="search" name="search_user" id="search_user" class="form-control"
                    placeholder="Ente Name of Catering for search" onkeyup="Search()" />

            </div>
            <div id="data">

            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        $(document).ready(function() {
            showdata();
        });

        function showdata() {
            $.ajax({
                url: "show_catering.php",
                type: "post",

                success: function(data, status) {
                    $('#data').html(data);
                }
            });
        }

        function book(baid) {
            window.location = "./bookingCatering.php?id=" + baid;
        }

        function display(baid) {
            window.location = "./displayCatering.php?id=" + baid;
        }

        function checkAvailable(baid) {
            var book_date_from = $("#book_date_from").val();
            var book_date_to = $("#book_date_to").val();
            if (book_date_from.length == 0) {
                $("#book_date_from").focus();
            } else if (book_date_to.length == 0) {
                $("#book_date_to").focus();
            } else {
                $.ajax({
                    url: "check_available.php",
                    type: "post",
                    data: {
                        baid: baid,
                        book_date_from: book_date_from,
                        book_date_to: book_date_to
                    },

                    success: function(data, status) {
                        alert(data);
                    }
                });
            }
        }

        function Search() {
            var search_word = $('#search_user').val();
            if (search_word.length == 0) {
                showdata();
            } else {
                $.ajax({
                    url: "search.php",
                    type: 'post',
                    data: {
                        search_catering: search_word,
                    },

                    success: function(data, status) {
                        $('#data').html(data);
                    }
                });
            }
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

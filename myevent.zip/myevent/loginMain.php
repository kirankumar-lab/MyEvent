<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyEvent | Login</title>
    <link rel="icon" href="img/myevent.png" type="image/x-icon">
    <!-- CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/floating-labels.css">
    <!--  -->
</head>

<body class="d-flex flex-column h-100">
    <div class="text-center">
        <img src="img/MyEvent.png" class="w-25" alt="MyEvent Image">
    </div>
    <form class="form-signin" method="post">
        <div class="text-center mb-4">
            <img class="mb-4" src="img/avatar2.png" alt="" width="85" height="85">
            <h1 class="h3 mb-3 font-weight-normal">Login</h1>
        </div>
        <div id="invaild" class="text-center">
        </div>
        <div class="form-label-group">
            <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
            <label for="inputEmail">Email address</label>
        </div>

        <div class="form-label-group">
            <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
            <label for="inputPassword">Enter Password</label>
        </div>
        <button class="btn btn-lg btn-primary btn-block mb-2" name="submit" type="submit">Login</button>
        <a href="forgot.php" class=" text-primary text-decoration-none">Forgot Password?</a><br>
        <a href="registration.php" class=" text-primary text-decoration-none">Create New Personal/Business
            Account</a>
    </form>
    <?php
    require("db/connection.php");
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $q = "select * from user where email='$email' and password='$password' and del=0";
        $query = mysqli_query($connection, $q);
        $row = mysqli_num_rows($query);
        if ($row == 1) {
            $row = mysqli_fetch_array($query);
            session_start();
            $_SESSION['uid'] = $row['uid'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['type'] = $row['type'];
            session_commit();
            if ($_SESSION['type'] == "personal") {
                header("Location:home.php");
            }
            if ($_SESSION['type'] == "business") {
                header("Location:./business/");
            }
        } else {
            echo ('<script type="text/javascript">document.getElementById(\'invaild\').innerHTML="<label class=\"alert alert-danger\">Incorrect Email Or Password.</label>";
					</script>');
        }
    }
    ?>


    <!-- footer -->
    <footer class="footer mt-auto py-3 bg-light text-center">
        <div class="container">
            <span class="text-muted">Copyrights &copy;2020-21. All Rights Resevered by MyEvent.</span>
        </div>
    </footer>
    <!--  -->

    <!--------------- Javascripts Link ------------->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <!-- ---------------------------------------- -->
</body>

</html>
<?php
require("session_personal.php");
require("db/connection.php");
$date = date('Y-m-d');
$q = "SELECT *,`booking_decorator`.`book_id` as b_v_id FROM `booking`,`booking_decorator` WHERE `booking`.`book_id`=`booking_decorator`.`book_id`AND `uid`=$uid ORDER BY `booking`.`book_id` DESC";
$qb = mysqli_query($connection, $q);
if (mysqli_num_rows($qb) > 0) {
    while ($rb = mysqli_fetch_array($qb)) {
?>
<div class="p-2">
    <div class="p-2 border rounded m-2 shadow">
        <div class="row m-auto mb-1 border-bottom pt-1">
            <div class="col-sm-4 col-12">
                <h6>Booking ID : <span class="text-secondary"><?php echo $rb['book_id']; ?></span></h6>
            </div>

            <div class="col-sm-4 col-12">
                <h6>Booking Date & Time : <span class="text-secondary"><?php echo $rb['timestamp']; ?></span></h6>
            </div>

            <div class="col-sm-4 col-12">
                <?php
                        if ($rb['confirm'] == 1) {
                            $status = '<span class="text-success">Confirmed</span>';
                            if ($rb['book_date_from'] <= $date) {
                                $status = '<span class="text-primary">Completed</span>';
                            }
                            if ($rb['cancle'] == 1) {
                                $status = '<span class="text-danger">Cancled</span>';
                            }
                        } else {
                            $status = '<span class="text-warning">Pendding...</span>';
                            if ($rb['cancle'] == 1) {
                                $status = '<span class="text-danger">Cancled</span>';
                            }
                        }
                        ?>
                <h6>Booking Status : <?php echo $status; ?></h6>
            </div>
        </div>
        <div class="row m-auto mb-1 border-bottom pt-1">
            <div class="col-sm-4 col-12">
                <span class="h6">Booked Date <br> From : </span><span
                    class="text-secondary"><?php echo $rb['book_date_from']; ?></span><br><span class="h6"> To :
                </span><span class="text-secondary"><?php echo $rb['book_date_to']; ?></span>
            </div>
            <div class="col-sm-4 col-12">
                <span class="h6">Total Amount</span><br><span class="text-secondary"><i
                        class="fa fa-inr pr-1"></i><?php echo $rb['amount']; ?></span>
            </div>
            <div class="col-sm-4 col-12">
                <span class="h6">Payment Type</span><br><span
                    class="text-secondary"><?php echo $rb['payment_type']; ?></span>
            </div>
        </div>

        <div class="row m-auto mb-1 border-bottom pt-1 pb-2">
            <div class="col-12">
                <div class=" text-center"><span class="h6 text-decoration-underline">Decorator Details</span><br></div>
                <?php
                        $tempq = "select * from business_account where baid=" . $rb['baid'] . ";";
                        $tempq = mysqli_query($connection, $tempq);
                        $tempq = mysqli_fetch_array($tempq);
                        ?>
                <span class="h6 pr-1">Organization Name:</span><span
                    class="text-dark"><?php echo $tempq['name_organization']; ?></span><br>
                <span class="h6 pr-1">Address:</span><span class="text-dark"><?php echo $tempq['address']; ?></span><br>
                <span class="h6 pr-1">Email:</span><span class="text-dark"><?php echo $tempq['email']; ?></span><br>
                <span class="h6 pr-1">Mobile No:</span><span class="text-dark"><?php echo $tempq['mono']; ?></span><br>
            </div>
        </div>

        <div class="row m-auto mb-1 border-bottom pt-1">
            <div class="col-sm-4 col-12">
                <div class="pb-1">
                    <span class="h6">Decoration Used:</span>
                    <br>
                    <?php
                            if ($rb['venue_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Venue Decoration</span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['outdoor_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Outdoor Decoration</span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['welcome_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Welcome Decoration</span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['tent'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Tent</span><br>
                    <?php
                            }
                            ?>
                </div>
            </div>

            <div class="col-sm-4 col-12">
                <div class="pb-1">
                    <span class="text-dark h6"></span>
                    <br>
                    <?php
                            if ($rb['table_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Table Decoration</span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['chair_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Chair Decoration</span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['car_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-circle pr-1"></i>Car Decoration</span><br>
                    <?php
                            }
                            ?>
                </div>
            </div>

            <div class="col-sm-4 col-12">
                <div class="pb-1">
                    <span class="text-dark h6"></span>
                    <br>
                    <?php
                            if ($rb['table_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-arrow-right pr-1"></i>No of Table Decoration:
                        <?php echo $rb['no_table']; ?></span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['chair_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-arrow-right pr-1"></i>No of Chair Decoration:
                        <?php echo $rb['no_chair']; ?></span><br>
                    <?php
                            }
                            ?>
                    <?php
                            if ($rb['car_deco'] == 1) {
                            ?>
                    <span><i class="fa fa-arrow-right pr-1"></i>No of Car Decoration:
                        <?php echo $rb['no_car']; ?></span><br>
                    <?php
                            }
                            ?>
                </div>
            </div>
        </div>
        <div class="text-center">
            <?php
                    if ($rb['book_date_from'] >= $date) {
                        if ($rb['cancle'] == 0) {
                    ?>
            <button class="btn btn-danger" onclick="cancle(<?php echo $rb['book_id']; ?>)">Cancle Booking</button>
            <?php
                        }
                    }
                    ?>
        </div>
    </div>
</div>
<?php
    }
} else {
    ?>
<div class="p-5 text-danger font-weight-bold h4"> No Any Booking. </div>
<?php
}
?>

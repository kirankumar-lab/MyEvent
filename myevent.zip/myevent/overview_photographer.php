<?php
require("db/connection.php");
$id = $_POST['id'];
?>
<div class="p-3 m-auto">
    <?php
    $q = "SELECT * FROM photographer WHERE baid=$id AND del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
        $result = mysqli_fetch_array($query);
    ?>
    <div class="row">
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <?php
                        if ($result['photo_day'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Photography per Day Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_day']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['photo_2_day'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Photography per 2 Day Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_2_day']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['photo_3_day'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Photography per 3 Day Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_3_day']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <?php
                        if ($result['photo_vedio_day'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Photography + Vedio per Day Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_vedio_day']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['photo_vedio_2_day'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Photography + Vedio per 2 Day Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_vedio_2_day']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['photo_vedio_3_day'] != "0") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Photography + Vedio per 3 Day Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_vedio_3_day']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-1 mb-2 text-left">
        <span class="h6 text-dark pr-1">Other Services:</span><span
            class="text-warp"><?php echo $result['other_service']; ?></span>
    </div>
    <?php
    }
    ?>

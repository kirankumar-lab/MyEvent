<?php
session_abort();
session_start();
$uid = $_SESSION['uid'];
$acct_name = $_SESSION['name'];
$type = $_SESSION['type'];
if (empty($uid)) {
    header("Location:login.php");
}
if ($type != "personal" || empty($type)) {
    session_destroy();
    header("Location:login.php");
}

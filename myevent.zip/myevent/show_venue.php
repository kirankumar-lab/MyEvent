<?php
require("db/connection.php");
$q = "select *,venue.type as vtype from venue,business_account RIGHT join user on user.uid=business_account.uid  where venue.del=0 and business_account.del=0 and business_account.baid=venue.baid and user.del=0";
$query = mysqli_query($connection, $q);
if (mysqli_num_rows($query) > 0) {
?>
<div class="container-fluid py-3 border-bottom border-dark">
    <span class="h3">Venues</span>
</div>
<?php

    while ($result = mysqli_fetch_array($query)) {

    ?>
<div class="text-center mb-4 m-3 text-capitalize order p-3 venue row">
    <div class="p-1 text-left border-bottom mb-1">
        <h4 class="text-primary pb-2"><?php echo $result['name_organization']; ?></h4>
        <span><i class="fa fa-map-marker text-secondary pr-1"></i></span><label
            class="text-primary text-wrap"><?php echo $result['address']; ?>,&nbsp;<?php echo $result['city']; ?>.</label>
    </div>
    <div class="col-md-3 col-12">
        <!-- Slidesshow -->
        <div id="slder" class="carousel slide" data-rid="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/MyEvent.png" alt="not loaded" class="venue-img">
                </div>
                <?php
                        $baid = $result['baid'];
                        $qi = "select * from image where baid=$baid and del=0";
                        $queryi = mysqli_query($connection, $qi);
                        while ($resulti = mysqli_fetch_array($queryi)) {
                        ?>
                <div class="carousel-item">
                    <img src="business/venue/<?php echo $resulti['src']; ?>" alt="not loaded" class="venue-img">
                </div>
                <?php
                        }
                        ?>
            </div>
            <!-- Slidesshow Img Ends -->
            <!-- Slide Navigation Buttons -->

            <a href="#slder" class="carousel-control-prev chg-img" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>

            <a href="#slder" class="carousel-control-next chg-img" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
            <!-- Slide Navigation Buttons Ends -->
        </div>
        <!-- Slidesshow Ends -->
    </div>
    <div class="col-md-9 col-12">
        <div class="row">
            <div class="col-md-6 col-12">
                <table class="table bg-light mt-2 py-2">
                    <tbody>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Venue Type</td>
                            <td class="text-dark h6 text-right"><?php echo $result['vtype']; ?></td>
                        </tr>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Venue People Capacity</td>
                            <td class="text-dark h6 text-right"><?php echo $result['capacity']; ?></td>
                        </tr>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Decoration</td>
                            <td class="text-dark h6 text-right"><?php echo $result['deco_policy']; ?></td>
                        </tr>
                        <?php
                                if ($result['deco_policy'] != "other allowed") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Decoration Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['deco_price']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                        <tr class="py-2 px-1" id="deco_price">
                            <td class="text-secondary h6 text-left">Rent Per Day</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['rent']; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6 col-12">
                <table class="table bg-light mt-2 py-2">
                    <tbody>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Food Policy</td>
                            <td class="text-dark h6 text-right"><?php echo $result['food_policy']; ?></td>
                        </tr>
                        <?php
                                if ($result['food_policy'] != "other allowed") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Price per Plate,veg</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['veg_price']; ?>
                            </td>
                        </tr>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Price per Plate,non-veg</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['non_veg_price']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-1 mb-2 text-left">
            <span class="h6 text-dark pr-1">Other Specification:</span><span
                class="text-warp"><?php echo $result['other_specification']; ?></span>
        </div>
        <div class="mt-2">
            <button class="btn btn-success m-1" onclick="book(<?php echo $result['baid'] ?>)">
                Book Venue
            </button>

            <button class="btn btn-info m-1" onclick="display(<?php echo $result['baid'] ?>)">
                View Details
            </button>

            <!-- Button trigger modal -->
            <button type="button" class="btn btn-secondary m-1" data-toggle="modal" data-target="#modelId">
                Check Availablity
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Check Availability</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="h5 text-capitalize">
                            <label for="book_date_from" class="form-label">date from:</label>
                            <input type="date" name="book_date_from" id="book_date_from" class="form-control" required
                                title="Select Date From">
                        </div>
                        <div class="h5 text-capitalize">
                            <label for="book_date_to" class="form-label">date to:</label>
                            <input type="date" name="book_date_to" id="book_date_to" class="form-control" required
                                title="Select Date to">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary"
                            onclick="checkAvailable(<?php echo $result['baid'] ?>)">Save</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php
    }
} else {
    echo '<p class="p-5 text-center text-danger"> No Any Venues Found.</p>';
}
?>

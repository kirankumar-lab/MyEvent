<?php
require("session_personal.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    header("./venue.php");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Venue</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->

    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4 w-100">
            <?php
        require("db/connection.php");
        $q = "select * from venue,business_account where venue.del=0 and business_account.baid=venue.baid and business_account.baid=$id";
        $query = mysqli_query($connection, $q);
        if (mysqli_num_rows($query) > 0) {
            $result = mysqli_fetch_array($query);
        ?>
            <div class="container-fluid py-3 border-bottom border-dark">
                <span class="h3">Booking Venue</span>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-4 border-bottom p-1 pb-5">
                        <div class="border-0 border-bottom h4 text-center text-capitalize"><span>Venue
                                Details</span></div>
                        <div class="h6 text-capitalize">Venue Name: <span
                                class="text-primary"><?php echo $result['name_organization']; ?></span>
                        </div>
                        <div class="h6 text-capitalize">Venue Type: <span
                                class="text-primary"><?php echo $result['type']; ?></span>
                        </div>
                        <div class="h6 text-capitalize">Venue People Capacity: <span
                                class="text-primary"><?php echo $result['capacity']; ?><i
                                    class="fa fa-user pl-1 pr-2 text-secondary"></i></span>
                        </div>
                        <?php
                        if ($result['deco_policy'] == 'inhouse decoration only') {
                        ?>
                        <div class="h6 text-capitalize">Venue Decoration Policy: <span
                                class="text-primary"><?php echo $result['deco_policy']; ?></span>
                        </div>
                        <div class="h6 text-capitalize">Venue Decoration Price: <span class="text-primary"><i
                                    class="fa fa-inr pr-2 pl-1"></i><?php echo $result['deco_price']; ?></span>
                        </div>
                        <?php
                        } else {
                        ?>
                        <div class="h6 text-capitalize">Venue Decoration Policy: <span
                                class="text-primary"><?php echo $result['deco_policy']; ?></span>
                        </div>
                        <?php
                        }
                        ?>
                        <?php
                        if ($result['food_policy'] == 'inhouse food only') {
                        ?>
                        <div class="h6 text-capitalize">Venue Food Policy:
                            <span class="text-primary"><?php echo $result['food_policy']; ?></span>
                        </div>
                        <div class="h6 text-capitalize">Venue Food Veg Price(per Plate): <span class="text-primary"><i
                                    class="fa fa-inr pr-2 pl-1"></i><?php echo $result['veg_price']; ?></span>
                        </div>
                        <div class="h6 text-capitalize">Venue Food Non-Veg Price(per Plate): <span
                                class="text-primary"><i
                                    class="fa fa-inr pr-2 pl-1"></i><?php echo $result['non_veg_price']; ?></span>
                        </div>
                        <?php
                        } else {
                        ?>
                        <div class="h6 text-capitalize">Venue Food Policy: <span
                                class="text-primary"><?php echo $result['food_policy']; ?></span>
                        </div>
                        <?php
                        }
                        ?>
                        <div class="h6 text-capitalize">Venue Rent(per day): <span class="text-primary"><i
                                    class="fa fa-inr pr-2 pl-1"></i><?php echo $result['rent']; ?></span>
                        </div>
                    </div>
                    <div class="col-12 col-md-8 border-bottom p-1 pb-5">
                        <form method="post">
                            <div class="border-0 border-bottom h4 text-center text-capitalize"><span>Fill Booking
                                    Details</span>
                            </div>
                            <div class="h5 text-capitalize" aria-disabled="true">
                                <label for="no_people" class="form-label">Enter no of people(guest):</label>
                                <input type="number" name="no_people" id="no_people" class="form-control"
                                    max="<?php echo $result['capacity']; ?>" required
                                    placeholder="Enter No. of People(Guest)" title="Enter No. of People(Guest)">
                            </div>
                            <div class="text-capitalize">
                                <label for="deco" class="form-check-label pr-1 h5">Decoration (if you use inhouse
                                    decoration):</label>
                                <?php
                                if ($result['deco_policy'] == 'other allowed') {
                                    $disabled = "disabled=disabled";
                                } else {
                                    $disabled = "";
                                } ?>
                                <br>
                                <input type="checkbox" name="deco[]" class="form-check-inline" id="deco"
                                    title="Select on You use inhouse decoration" <?php echo $disabled; ?>
                                    value="1"><span>You Use
                                    Inhouse Decoration</span>
                            </div>
                            <?php
                            if ($result['food_policy'] == 'other allowed') {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize">
                                <label for="food_lable" class="form-check-label pr-1 h5">Food (if you use inhouse
                                    food):</label>
                            </div>
                            <div class="text-capitalize">
                                <input type="checkbox" name="veg_food[]" class="form-check-inline" id="veg_check"
                                    onchange="change_veg()" title="Select on You use inhouse food"
                                    <?php echo $disabled; ?> value="1"><span>veg
                                    food</span>
                                <input type="checkbox" name="non_veg_food[]" class="form-check-inline"
                                    onchange="change_non_veg()" id="non_veg_check"
                                    title="Select on You use inhouse food" <?php echo $disabled; ?>
                                    value="1"><span>non-veg food</span>
                                <div class="h5 text-capitalize">
                                    <label for="veg_plate" class="form-label">Enter no of veg plate:</label>
                                    <input type="number" name="veg_plate" id="veg_plate" class="form-control" required
                                        placeholder="Enter No. of veg plate" title="Enter No. of veg plate"
                                        <?php echo $disabled; ?>>
                                </div>
                                <div class="h5 text-capitalize">
                                    <label for="non_veg_plate" class="form-label">Enter no of non-veg plate:</label>
                                    <input type="number" name="non_veg_plate" id="non_veg_plate" class="form-control"
                                        required placeholder="Enter No. of non-veg plate"
                                        title="Enter No. of non-veg plate" <?php echo $disabled; ?>>
                                </div>
                            </div>
                            <div class="h5 text-capitalize">
                                <label for="book_date_from" class="form-label">date from:</label>
                                <input type="date" name="book_date_from" id="book_date_from" class="form-control"
                                    required title="Select Date From">
                            </div>
                            <div class="h5 text-capitalize">
                                <label for="book_date_to" class="form-label">date to:</label>
                                <input type="date" name="book_date_to" id="book_date_to" class="form-control" required
                                    title="Select Date to">
                            </div>
                            <div class="h5 text-capitalize">
                                <label for="payment_type" class="form-label">Payment Type:</label>
                                <select name="payment_type" id="payment_type" class="form-select"
                                    onchange="change_pay_type()">
                                    <option value="online">Online</option>
                                    <option value="offline">Offline</option>
                                </select>
                            </div>
                            <div class="text-capitalize">
                                <span class="text-danger justify-content-around p-2" id="off_dl"><sup>*</sup>You Pay
                                    money at venue
                                    (vendor office) and confirm your booking by vendor in 1 hours. after 1 hours expired
                                    your booking request.</span>
                                <br>
                                <button class="btn btn-success" type="submit" name="submit" id="submit">Book the
                                    Venue</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        </main>
        <!-- ---- -->

        <!-- Booking Process -->
        <?php
    if (isset($_POST['submit'])) {
        $uid = $_SESSION['uid'];
        $baid = $id;
        $book_date_from = $_POST['book_date_from'];
        $book_date_from = date("Y-m-d", strtotime($book_date_from));
        $book_date_to = $_POST['book_date_to'];
        $book_date_to = date("Y-m-d", strtotime($book_date_to));
        $payment_type = $_POST['payment_type'];
        if ($payment_type == "online") {
            $confirm = 1;
        } else {
            $confirm = 0;
        }
        $no_people = $_POST['no_people'];
        $rent = $result['rent'];
        if (isset($_POST['deco'])) {
            foreach ($_POST['deco'] as $dc) {
                $deco = $dc;
                $deco_amount = $result['deco_price'];
            }
        } else {
            $deco = 0;
            $deco_amount = 0;
        }
        if (isset($_POST['veg_food'])) {
            foreach ($_POST['veg_food'] as $dc) {
                $veg_food = $dc;
                $veg_plate = $_POST['veg_plate'];
            }
        } else {
            $veg_food = 0;
            $veg_plate = 0;
        }
        if (isset($_POST['non_veg_food'])) {
            foreach ($_POST['non_veg_food'] as $dc) {
                $non_veg_food = $dc;
                $non_veg_plate = $_POST['non_veg_plate'];
            }
        } else {
            $non_veg_food = 0;
            $non_veg_plate = 0;
        }
        $food_amount = $veg_plate * $result['veg_price'] + $non_veg_plate * $result['non_veg_price'];
        $days = strtotime($book_date_to) / (60 * 60 * 24) - strtotime($book_date_from) / (60 * 60 * 24) + 1;
        $total_rent = $rent * $days;
        $total_amount = $total_rent + $deco_amount + $food_amount;
        $amount = $total_amount;
        $currentdate = date('Y-m-d');
        if ($book_date_to >= $book_date_from) {
            $q = "SELECT `book_date_from`,`book_date_to` FROM `booking` WHERE `baid`=$baid AND `cancle`=0 AND '$book_date_from'>=CURRENT_DATE AND '$book_date_to'>=CURRENT_DATE AND `book_date_from` BETWEEN '$book_date_from' AND '$book_date_to' AND `book_date_to` BETWEEN '$book_date_from' AND '$book_date_to'";
            $run = mysqli_query($connection, $q);
            if (mysqli_num_rows($run) > 0) {
                echo '<script>alert("Already Booked By Another User on this date.");</script>';
            } else {
                if ($book_date_from >= $currentdate) {
                    $q = "INSERT INTO `booking`(`uid`, `baid`, `book_date_from`, `book_date_to`, `amount`, `payment_type`, `confirm`) VALUES ($uid,$baid,'$book_date_from','$book_date_to',$amount,'$payment_type',$confirm)";
                    $r = mysqli_query($connection, $q);
                    if ($r) {
                        $q = "SELECT `book_id` FROM `booking` WHERE `uid`=$uid AND `baid`=$baid ORDER BY `book_id` DESC LIMIT 1";
                        $r = mysqli_fetch_array(mysqli_query($connection, $q));
                        $book_id = $r['book_id'];

                        $q = "INSERT INTO `booking_venue`(`baid`, `book_id`, `no_people`, `rent`, `deco`, `deco_amount`, `non_veg_food`, `veg_food`, `non_veg_plate`, `veg_plate`, `food_amout`, `total_amount`)VALUES ($baid,$book_id,$no_people,$rent,$deco,$deco_amount,$non_veg_food,$veg_food,$non_veg_plate,$veg_plate,$food_amount,$total_amount)";
                        mysqli_query($connection, $q);

                        echo '<script>window.location="./booking.php";</script>';
                    }
                } else {
                    echo '<script>alert("Select Vaild Date");</script>';
                }
            }
        } else {
            echo '<script>alert("Select Vaild Date");</script>';
        }
    }
    ?>
        <!-- Booking Process END-->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        $(document).ready(function() {
            $('#off_dl').hide();
            change_non_veg();
            change_veg();
            change_pay_type();
        });

        function validate() {

        }

        function change_veg() {
            if (document.getElementById('veg_check').checked) {
                $("#veg_plate").removeAttr('disabled');
            } else {
                $("#veg_plate").attr('disabled', 'disabled');
            }
        }

        function change_non_veg() {
            if (document.getElementById('non_veg_check').checked) {
                $("#non_veg_plate").removeAttr('disabled');
            } else {
                $("#non_veg_plate").attr('disabled', 'disabled');
            }
        }

        function change_pay_type() {
            var pay = $('#payment_type').val();
            if (pay === "offline") {
                $('#submit').html("Booking request to the Venue");
                $('#off_dl').show();
            } else {
                $('#submit').html("Book the Venue");
                $('#off_dl').hide();
            }
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

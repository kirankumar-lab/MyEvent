<!-- ------------Navbar & SideBar--------------- -->
<nav class="navbar navbar-expand-sm navbar-light sticky-top bg-light flex-md-nowrap p-1 shadow">
    <div class="container-fluid">
        <a class="navbar-brand w-25" href="#">
            <img src="img/MyEvent.png" alt="MyEvent" class="w-50">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample06"
            aria-controls="navbarsExample06" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse m-auto" id="navbarsExample06">
            <ul class="navbar-nav ml-auto mb-2 mb-xl-0 pr-sm-3">
                <li class="nav-item active btn">
                    <a class="nav-link text-primary" href="./"><i class="fa fa-home"></i>&nbsp;Home</a>
                </li>
                <li class="nav-item dropdown btn">
                    <a class="nav-link dropdown-toggle text-primary btn" href="#" id="services" data-toggle="dropdown"
                        aria-expanded="false"><i class="fa fa-first-order pr-1"></i>Services
                    </a>
                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="services">
                        <li>
                            <a href="venue.php" class="dropdown-item border-bottom border-top">Venues</a>
                        </li>
                        <li>
                            <a href="photographer.php" class="dropdown-item border-bottom border-top">Photographers</a>
                        </li>
                        <li>
                            <a href="catering.php" class="dropdown-item border-bottom border-top">Catering</a>
                        </li>
                        <li>
                            <a href="decorator.php" class="dropdown-item border-bottom border-top">Decorators</a>
                        </li>
                        <li>
                            <a href="wedding_planner.php" class="dropdown-item border-bottom border-top">Wedding
                                Planners</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item btn">
                    <a class="nav-link text-primary" href="./contact.php"><i class="fa fa-envelope"></i>&nbsp;Contact
                        Us</a>
                </li>
                <li>
                    <div class="nav-item pr-sm-3 p-1">
                        <a href="login.php"><button class="btn btn-outline-success">Login</button></a>
                        <a href="registration.php"><button class="btn btn-outline-success">Registration</button></a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- -----------Navbar & SideBar End------------ -->

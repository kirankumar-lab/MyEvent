<?php
require("session_business.php");
?>
<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MyEvent | Home</title>
    <link rel="icon" href="../img/myevent.png" type="image/x-icon">
    <!--------------------- CSS -------------------->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- --------------------------------------------- -->
    <style>
    </style>
</head>

<body class="d-flex flex-column h-100">

    <!-- ------------Navbar & SideBar--------------- -->
    <?php
    include("navbar.php");
    ?>
    <!-- -----------Navbar & SideBar End------------ -->

    <!-- Main -->
    <main class="mx-sm-auto px-md-4">
        <div class="text-center">
            <img src="../img/MyEvent.png" class="w-25" alt="MyEvent Image">
        </div>
        <form id="regForm" class="form-signin" method="post">
            <div class="text-center mb-4">
                <h1 class="h3 mb-3 font-weight-normal">Create Your MyEvent Business Account</h1>
            </div>
            <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                <label class="btn pt-lg-2 pb-lg-1">
                    <input type="radio" name="category" value="venue" class="form-check-input p-2" required autofocus>
                    <span class="h5 text-black-50 p-2">venue</span>
                </label><br>
                <label class="btn pt-lg-2 pb-lg-1">
                    <input type="radio" name="category" value="catering" class="form-check-input p-2" required
                        autofocus>
                    <span class="h5 text-black-50 p-2">catering</span>
                </label><br>
                <label class="btn pt-lg-2 pb-lg-1">
                    <input type="radio" name="category" value="decorator" class="form-check-input p-2" required
                        autofocus>
                    <span class="h5 text-black-50 p-2">decorator</span>
                </label><br>
                <label class="btn pt-lg-2 pb-lg-1">
                    <input type="radio" name="category" value="photographer" class="form-check-input p-2" required
                        autofocus>
                    <span class="h5 text-black-50 p-2">photographer</span>
                </label><br>
                <label class="btn pt-lg-2 pb-lg-1">
                    <input type="radio" name="category" value="wedding_planner" class="form-check-input p-2" required
                        autofocus>
                    <span class="h5 text-black-50 p-2">wedding planner</span>
                </label>
            </div>
            <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                <label class="btn pt-lg-2 pb-lg-1">
                    <span class="h5 text-black-50">Organization Name:</span>
                </label>
                <input type="text" name="org_name" placeholder="Enter Organization Name" class="form-control p-2 m-1"
                    required autofocus>
                <label class="btn pt-lg-2 pb-lg-1">
                    <span class="h5 text-black-50">Address:</span>
                </label>
                <input type="text" name="org_address" placeholder="Enter Address" class="form-control p-2 m-1" required
                    autofocus>
                <label class="btn pt-lg-2 pb-lg-1">
                    <span class="h5 text-black-50">City:</span>
                </label>
                <input type="text" name="org_city" placeholder="Enter City" class="form-control p-2 m-1" required
                    autofocus>
                <label class="btn pt-lg-2 pb-lg-1">
                    <span class="h5 text-black-50">Mobile Number:</span>
                </label>
                <input type="text" name="org_mono" placeholder="Enter Mobile Number" class="form-control p-2 m-1"
                    onkeyup="chkmono(this)" required autofocus>
                <p id="errormono" class="text-danger"></p>
                <label class="btn pt-lg-2 pb-lg-1">
                    <span class="h5 text-black-50">Email:</span>
                </label>
                <input type="text" name="org_email" placeholder="Enter Email" class="form-control p-2 m-1" required
                    autofocus>
            </div>
            <div>
                <button class="btn btn-lg btn-success mb-2 mx-1 float-right" name="submit" type="submit">Create
                    Business Account</button>
                <button class="btn btn-lg btn-danger mb-2 float-right" name="reset" type="reset">Reset
                    Detail</button>
            </div>
        </form>
        <?php
        require("../db/connection.php");
        if (isset($_POST['submit'])) {
            $category = $_POST['category'];
            $q = "select bid from business_category where catagory='$category'";
            $query = mysqli_query($connection, $q);
            $result = mysqli_fetch_array($query);
            $bid = $result['bid'];
            $org_name = $_POST['org_name'];
            $org_address = $_POST['org_address'];
            $org_city = $_POST['org_city'];
            $org_mono = $_POST['org_mono'];
            $org_email = $_POST['org_email'];
            $q = "INSERT INTO `business_account`(`uid`, `bid`, `name_organization`, `address`, `city`, `email`, `mono`) VALUES ($uid,$bid,'$org_name','$org_address','$org_city','$org_email','$org_mono')";
            $query = mysqli_query($connection, $q);
            echo '<script type="text/javascript">window.location="./' . $category . '/";</script>';
        }
        ?>
    </main>
    <!-- ---- -->

    <!-- footer -->
    <?php
    include("footer.php");
    ?>
    <!-- ------ -->

    <!--------------- Javascripts Link ------------->
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/jquery.min.js"></script>
    <script type="text/javascript">
    function chkmono(mono) {
        if (isNaN(mono.value)) {
            document.getElementById('errormono').innerHTML = "Please Enter Only Digits.";
            document.getElementByName('mono').focus();
        }
        if (mono.value.length === 10) {
            document.getElementById('errormono').innerHTML = "";
        } else {
            document.getElementById('errormono').innerHTML = "Please Enter 10 Digit Phone Number.";
            document.getElementByName('mono').focus();
        }
    }
    </script>
    <!-- ---------------------------------------- -->
</body>
<!--
             -->

</html>
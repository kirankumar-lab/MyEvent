<?php
session_start();
$uid = $_SESSION['uid'];
$acct_name = $_SESSION['name'];
$baid = $_SESSION['baid'];
if (empty($uid)) {
    header("Location:../../login.php");
} else {
    if (empty($baid))
        header("Location:../");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Decorator Photoes</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">
        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="mx-sm-auto px-md-4 w-100">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>Decorator Photoes</span>
                </div>
            </div>
            <div class="p-1">
                <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                    style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                    <div class="text-danger">
                        *Note : You are upload maximum 10 images.
                    </div>
                    <div id="btnUploadImage" class="mr-auto text-right">
                        <button class="btn btn-outline-dark" name="UploadImageBTN" id="UploadImageBTN"
                            onclick="UploadImageShow()">
                            Upload Image
                        </button>
                    </div>
                    <div class="pt-3 border-bottom w-100">
                        <div class="float-left text-dark">
                            <span>Uploaded your Images:</span>
                        </div>
                        <div class="float-right">
                            <span class="text-dark" id="numImage"></span><span class="text-secondary">/10</span>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div id="dataImage" class="card-group m-auto mt-2">
                    </div>
                    <div id="addImage" class="text-center w-100 h-100 mt-1 pt-1">
                        <form method="post" id="regForm" enctype="multipart/form-data">
                            <input type="file" id="images" name="images" class="form-file-button text-center m-auto"
                                accept="image/*">
                            <br>
                            <button class="btn btn-outline-success" name="uploadImage" id="uploadImage">
                                Upload Image
                            </button>
                            <button class="btn btn-outline-danger" name="uploadImageCancle" id="uploadImageCancle"
                                onclick="UploadImageHide()">
                                Cancle
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </main>

        <!-- ---- -->

        <!-- footer -->
        <?php include("footer.php"); ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        function UploadImageBTN() {
            $("#UploadImageBTN").attr("disabled", true);
        }

        function UploadImageHide() {
            $("#addImage").hide();
            $("#UploadImageBTN").show();
            $("#dataImage").show();
        }

        function UploadImageShow() {
            $("#addImage").show();
            $("#UploadImageBTN").hide();
            $("#dataImage").hide();
        }

        // Image Upload AJAX Function
        $(document).ready(function() {
            showdata();
        });

        function showdata() {
            $.ajax({
                url: 'photoaction.php',
                type: 'post',

                success: function(data) {
                    $('#dataImage').html(data);
                }
            });
            UploadImageHide();
        }

        function delImage(id) {
            var conf = confirm("Are you Sure to Delete Image?");
            if (conf == true) {
                $.ajax({
                    url: "photoaction.php",
                    type: 'post',
                    data: {
                        id: id
                    },

                    success: function(data, status) {
                        showdata();
                    }
                });
            }
        }
        </script>
        <!-- Images Upload Process -->
        <?php
    if (isset($_POST['uploadImage'])) {
        require("db/connection.php");
        $q = "select * from image where baid=$baid and del=0";
        $query = mysqli_query($connection, $q);
        $num = mysqli_num_rows($query);
        if ($num < 10) {
            if ($num == 0) {
                $num = 0;
            } else {
                $num = $num + 1;
            }
            //set Dirctory
            $target_dir = "uploads/";

            //set Images Name
            $target_file = $target_dir . "decorator" . $uid . $baid . $num . "." . pathinfo(basename($_FILES["images"]["name"]), PATHINFO_EXTENSION);


            //uploadStatus
            $uploadOk = 1;

            // Allow certain file formats
            $imageFileType = pathinfo(basename($_FILES["images"]["name"]), PATHINFO_EXTENSION);
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo ('<script>alert("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");</script>');
                // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["images"]["tmp_name"], $target_file)) {
                    $src = $target_file;
                    mysqli_query($connection, "INSERT INTO `image` (`baid`,`src`) VALUES($baid,'$src')");
                    echo ('<script>alert("Uploaded Successfully."); window.location="./photo.php";</script>');
                } else {
                    echo ('<script>alert("Sorry, there was an error uploading your file.");</script>');
                }
            }
        }
    }
    ?>
        <!-- End Images Upload Process -->

        <!-- ---------------------------------------- -->
    </body>

</html>

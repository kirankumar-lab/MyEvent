<?php
require("session_business.php");
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Decorator </title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        #edit_info:hover {
            color: #28A745;
            cursor: pointer;
        }

        </style>
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>Decorator Specification & Rents</span>
                </div>
            </div>
            <div class="p-1">
                <form method="post" id="regForm">
                    <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                        style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                        <div class="float-right h5" id="edit_info" onclick="edit_info()"><i class="fa fa-edit"></i><span
                                class="pl-1">Edit Decorator Specification</span>
                        </div>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Venue Decoration:</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="venue_decoration"
                            id="venue_decoration" onchange="venueDeco()">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>
                        <div id="venueDeco">
                            <label class="btn pt-lg-2 pb-lg-1">
                                <span class="h5 text-black-50">Venue Decoration Price:</span>
                            </label>
                            <input type="number" name="venue_deco_price" id="venue_deco_price"
                                placeholder="Enter Venue Decoration Price" class="form-control p-2 m-1 w-50 input"
                                value="0" disabled autofocus>
                        </div>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Outdoor Decoration:</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="outdoor_decoration"
                            id="outdoor_decoration" onchange="outdoorDeco()">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>
                        <div id="outdoorDeco">
                            <label class="btn pt-lg-2 pb-lg-1">
                                <span class="h5 text-black-50">Outdoor Decoration Price:</span>
                            </label>
                            <input type="number" name="outdoor_deco_price" id="outdoor_deco_price"
                                placeholder="Enter Outdoor Decoration Price" class="form-control p-2 m-1 w-50 input"
                                value="0" disabled autofocus>
                        </div>

                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Table Decoration Price(per table):</span>
                        </label>
                        <input type="number" name="table_deco_price" id="table_deco_price"
                            placeholder="Enter Table Decoration Price" class="form-control p-2 m-1 w-50 input" value="0"
                            disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Chair Decoration Price(per chair):</span>
                        </label>
                        <input type="number" name="chair_deco_price" id="chair_deco_price"
                            placeholder="Enter Chair Decoration Price" class="form-control p-2 m-1 w-50 input" value="0"
                            disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Welcome Decoration Price:</span>
                        </label>
                        <input type="number" name="welcome_deco_price" id="welcome_deco_price"
                            placeholder="Enter Welcome Decoration Price" class="form-control p-2 m-1 w-50 input"
                            value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Car Decoration Price(per car):</span>
                        </label>
                        <input type="number" name="car_deco_price" id="car_deco_price"
                            placeholder="Enter Car Decoration Price" class="form-control p-2 m-1 w-50 input" value="0"
                            disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Tent Price(per day):</span>
                        </label>
                        <input type="number" name="tent_price" id="tent_price" placeholder="Enter Tent Price"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Other Services:</span>
                        </label>
                        <input type="text" name="other_service" id="other_service" placeholder="Enter Other Services"
                            class="form-control p-2 m-1 w-50 input" value="no Other Services" disabled autofocus>

                        <div id="edit_action">
                            <button class="btn btn-lg btn-success mb-2 mx-1" name="submit" id="submit"
                                type="submit">Save</button>
                            <button class="btn btn-lg btn-danger mb-2 mx-1" name="cancle" id="cancle" type="button"
                                onclick="edit_info_hide()">Cancle</button>
                        </div>
                    </div>
                </form>
                <?php
            if (isset($_POST['submit'])) {
                $venue_decoration = $_POST['venue_decoration'];
                $outdoor_decoration = $_POST['outdoor_decoration'];
                $venue_deco_price = $_POST['venue_deco_price'];
                $outdoor_deco_price = $_POST['outdoor_deco_price'];
                $table_deco_price = $_POST['table_deco_price'];
                $chair_deco_price = $_POST['chair_deco_price'];
                $car_deco_price = $_POST['car_deco_price'];
                $welcome_deco_price = $_POST['welcome_deco_price'];
                $tent_price = $_POST['tent_price'];
                $other_service = $_POST['other_service'];
                require("db/connection.php");
                $q = "select * from decorator where baid=$baid and del=0";
                $query = mysqli_query($connection, $q);
                if (mysqli_num_rows($query) == 0) {
                    $q = "INSERT INTO `decorator`(`baid`, `venue_decoration`, `outdoor_decoration`, `venue_deco_price`, `outdoor_deco_price`, `table_deco_price`, `chair_deco_price`, `welcome_deco_price`, `tent_price`, `car_deco_price`, `other_service`) VALUES ($baid,$venue_decoration,$outdoor_decoration,$venue_deco_price,$outdoor_deco_price,$table_deco_price,$chair_deco_price,$welcome_deco_price,$tent_price,$car_deco_price,'$other_service')";
                    $query = mysqli_query($connection, $q);
                } else {
                    $q = "UPDATE `decorator` SET `venue_decoration`=$venue_decoration,`outdoor_decoration`=$outdoor_decoration,`venue_deco_price`=$venue_deco_price,`outdoor_deco_price`=$outdoor_deco_price,`table_deco_price`=$table_deco_price,`chair_deco_price`=$chair_deco_price,`welcome_deco_price`=$welcome_deco_price,`tent_price`=$tent_price,`car_deco_price`=$car_deco_price,`other_service`='$other_service' where baid=$baid and del=0";
                    $query = mysqli_query($connection, $q);
                    echo ('<script>window.location="./";</script>');
                }
            }
            ?>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="./js/bootstrap.bundle.min.js"></script>
        <script src="./js/jquery.min.js"></script>
        <script>
        function venueDeco() {
            if ($("#venue_decoration").val() == "0") {
                $("#venueDeco").hide();
            } else {
                $("#venueDeco").show();
            }
        }

        function outdoorDeco() {
            if ($("#outdoor_decoration").val() == "0") {
                $("#outdoorDeco").hide();
            } else {
                $("#outdoorDeco").show();
            }
        }

        function edit_info() {
            $("#edit_info").hide();
            $(".input").removeAttr("disabled");
            $(".select").removeAttr("disabled");
            $("#edit_action").show();
            venueDeco();
            outdoorDeco();
        }

        function edit_info_hide() {
            $("#edit_info").show();
            $(".input").attr("disabled", true);
            $(".select").attr("disabled", true);
            $("#edit_action").hide();
            venueDeco();
            outdoorDeco();
        }
        </script>
        <?php
    require("db/connection.php");
    $q = "select * from decorator where baid=$baid and del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) == 0) {
    ?>
        <script>
        edit_info();
        </script>
        <?php
    } else {
        $venue_data = mysqli_fetch_array($query);
    ?>
        <script>
        $("#venue_decoration").val("<?php echo $venue_data['venue_decoration']; ?>");
        $("#outdoor_decoration").val("<?php echo $venue_data['outdoor_decoration']; ?>");
        $("#venue_deco_price").val("<?php echo $venue_data['venue_deco_price']; ?>");
        $("#outdoor_deco_price").val("<?php echo $venue_data['outdoor_deco_price']; ?>");
        $("#table_deco_price").val("<?php echo $venue_data['table_deco_price']; ?>");
        $("#chair_deco_price").val("<?php echo $venue_data['chair_deco_price']; ?>");
        $("#welcome_deco_price").val("<?php echo $venue_data['welcome_deco_price']; ?>");
        $("#tent_price").val("<?php echo $venue_data['tent_price']; ?>");
        $("#car_deco_price").val("<?php echo $venue_data['car_deco_price']; ?>");
        $("#other_service").val("<?php echo $venue_data['other_service']; ?>");
        edit_info_hide();
        </script>
        <?php
    }
    ?>
        <!-- ---------------------------------------- -->
    </body>

</html>

<?php
require("session_business.php");
if (!empty($_SESSION['baid'])) {
    unset($_SESSION['baid']);
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Home</title>
        <link rel="icon" href="../img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="../font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .b_acct {
            border-radius: 50px;
            background: linear-gradient(90deg, rgba(200, 255, 200, 0.99)0%,
                    rgba(200, 255, 200, 0.7)25%,
                    rgba(200, 255, 200, 0.4)75%,
                    rgba(200, 255, 200, 0.99)100%);
        }

        .b_acct:hover {
            background: linear-gradient(170deg, rgba(200, 255, 200, 0.99)0%,
                    rgba(200, 255, 200, 0.7)25%,
                    rgba(200, 255, 200, 0.4)75%,
                    rgba(200, 255, 200, 0.99)100%);
            box-shadow: 0px 0px 25px rgba(0, 0, 0, 0.3), inset 0 0 1px rgba(255, 255, 255, 0.6);
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="mx-sm-auto px-md-4">
            <div class="text-center">
                <img src="../img/MyEvent.png" class="w-25" alt="MyEvent Image">
            </div>
            <div class="text-center mb-4 mt-5">
                <h1 class="h3 mb-3 font-weight-normal">Choose Your Account and Login</h1>
                <div class="pt-4 text-capitalize text-center">
                    <form method="post">
                        <?php
                    require("../db/connection.php");
                    $q = "select baid,bid,name_organization from business_account where uid = $uid and del=0";
                    $query = mysqli_query($connection, $q);
                    if (mysqli_num_rows($query) > 0) {
                        while ($result = mysqli_fetch_array($query)) {
                            $q1 = "select catagory from business_category where bid = " . $result['bid'] . "";
                            $query1 = mysqli_query($connection, $q1);
                            $result1 = mysqli_fetch_array($query1);
                    ?>
                        <div class="form-label-group m-1"
                            onclick="chg(<?php echo $result['baid']; ?>,'<?php echo $result1['catagory'];  ?>')">
                            <div class="p-3 font-weight-bolder b_acct w-50 flex-wrap m-auto">
                                <div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
                                    <label class="btn pt-lg-2 pb-lg-1">
                                        <div class="row p-1">
                                            <div class="col-11 text-capitalize text-left m-auto">
                                                <span
                                                    class="text-success h6 font-weight-bolder"><?php echo $result['name_organization'];  ?></span>
                                                <br />
                                                <span class="text-secondary"><?php echo $result1['catagory'];  ?></span>
                                            </div>
                                            <div class="col-1 m-auto text-success">
                                                <span><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <?php
                        }
                    } else {
                        echo '<label class="text-danger">No Any Business Account. Please Create New Business Account.</label>';
                    }
                    ?>
                    </form>
                    <div class="text-center mt-5">
                        <a href="create_business_account.php" class="text-decoration-none ">
                            <sapn class="text-success "><i class="fa fa-plus pr-4"></i>Create New
                                Business Account</sapn>
                        </a>
                    </div>
                </div>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.min.js"></script>
        <script>
        function chg(baid, cat) {
            $.ajax({
                url: "selectAccount.php",
                type: 'post',
                data: {
                    baid: baid,
                },
                success: function(status) {
                    window.location = "./" + cat + "/";
                }
            });
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

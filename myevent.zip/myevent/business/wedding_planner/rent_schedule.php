<?php
require("session_business.php");
$date = date('Y-m-d');
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="refresh" content="30">
        <title>MyEvent | Wedding Planner Rent Schedule</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4">
            <div class="p-2 shadow text-right">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-success m-1" data-toggle="modal" data-target="#modelId">
                    Pre Book
                </button>
                <!-- Modal -->
                <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Pre Book</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <div class="h5 text-capitalize">
                                    <label for="book_date_from" class="form-label">date from:</label>
                                    <input type="date" name="book_date_from" id="book_date_from" class="form-control"
                                        required title="Select Date From">
                                </div>
                                <div class="h5 text-capitalize">
                                    <label for="book_date_to" class="form-label">date to:</label>
                                    <input type="date" name="book_date_to" id="book_date_to" class="form-control"
                                        required title="Select Date to">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary"
                                    onclick="preBook(<?php echo $baid; ?>)">Pre Book</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        require("db/connection.php");
        $q = "SELECT *,`booking_wedding_planner`.`book_id` as b_v_id FROM `booking`,`booking_wedding_planner` WHERE `booking`.`book_id`=`booking_wedding_planner`.`book_id`AND `booking`.`baid`=$baid ORDER BY `booking`.`book_id` DESC";
        $qb = mysqli_query($connection, $q);
        if (mysqli_num_rows($qb) > 0) {
            while ($rb = mysqli_fetch_array($qb)) {
        ?>
            <div class="p-2">
                <div class="p-2 border rounded m-2 shadow">
                    <div class="row m-auto pb-1 border-bottom pt-1">
                        <div class="col-sm-4 col-12">
                            <h6>Booking ID : <span class="text-secondary"><?php echo $rb['book_id']; ?></span></h6>
                        </div>

                        <div class="col-sm-4 col-12">
                            <h6>Booking Date & Time : <span
                                    class="text-secondary"><?php echo $rb['timestamp']; ?></span></h6>
                        </div>

                        <div class="col-sm-4 col-12">
                            <?php
                                if ($rb['confirm'] == 1) {
                                    $status = '<span class="text-success">Confirmed</span>';
                                    if ($rb['book_date_from'] <= $date) {
                                        $status = '<span class="text-primary">Completed</span>';
                                    }
                                } else {
                                    $status = '<span class="text-warning">Pendding...</span>';
                                    if ($rb['book_date_from'] < $date) {
                                        $status = '<span class="text-danger">Request Expired</span>';
                                    }
                                }
                                if ($rb['cancle'] == 1) {
                                    $status = '<span class="text-danger">Cancled</span>';
                                }
                                if ($rb['pre_book'] == 0) {
                                ?>
                            <h6>Booking Status : <?php echo $status; ?></h6>
                            <?php
                                } else {
                                    if ($rb['cancle'] == 1) {
                                    ?>
                            <h6>Booking Status : <span class="text-danger">Cancled</span></h6>
                            <?php
                                    } else {
                                        if ($rb['book_date_from'] <= $date) {
                                            $status = '<span class="text-primary">Completed</span>';
                                        } else {
                                            $status = '<span class="text-success">Booked By You</span>';
                                        }
                                    ?>
                            <h6>Booking Status : <?php echo $status; ?></h6>
                            <?php
                                    }
                                }
                                ?>
                        </div>
                    </div>
                    <?php
                        if ($rb['pre_book'] == 0) {
                        ?>

                    <div class="row m-auto pb-1 border-bottom pt-1">
                        <div class="col-sm-4 col-12">
                            <span class="h6">Booked Date <br> From : </span><span
                                class="text-secondary"><?php echo $rb['book_date_from']; ?></span><br><span class="h6">
                                To :
                            </span><span class="text-secondary"><?php echo $rb['book_date_to']; ?></span>
                        </div>
                        <div class="col-sm-4 col-12">
                            <span class="h6">Total Amount</span><br><span class="text-secondary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $rb['amount']; ?></span>
                        </div>
                        <div class="col-sm-4 col-12">
                            <span class="h6">Payment Type</span><br><span
                                class="text-secondary"><?php echo $rb['payment_type']; ?></span>
                        </div>
                    </div>
                    <div class="row m-auto mb-1 border-bottom pt-1 pb-2">
                        <div class="col-12">
                            <span class="h6">User Details:</span><br>
                            <?php
                                    $tempq = "select name,address,mono,email from user where uid=" . $rb['uid'] . ";";
                                    $tempq = mysqli_query($connection, $tempq);
                                    $tempq = mysqli_fetch_array($tempq);
                                    ?>
                            <span class="h6 pr-1">Name:</span><span
                                class="text-dark"><?php echo $tempq['name']; ?></span><br>
                            <span class="h6 pr-1">Address:</span><span
                                class="text-dark"><?php echo $tempq['address']; ?></span><br>
                            <span class="h6 pr-1">Email:</span><span
                                class="text-dark"><?php echo $tempq['email']; ?></span><br>
                            <span class="h6 pr-1">Mobile No:</span><span
                                class="text-dark"><?php echo $tempq['mono']; ?></span><br>
                        </div>
                    </div>
                    <div class="row m-auto mb-1 border-bottom pt-1">
                        <div class="col-12">
                            <div class="pb-1">
                                <span class="h6">Selected Wedding planner:</span><br>
                                <?php
                                        if ($rb['wed_planning'] == 1) {
                                        ?>
                                <span class="text-dark">Wedding Planner</span><br>
                                <span>(Cost of agency service)</span>
                                <?php
                                        }
                                        ?>
                                <?php
                                        if ($rb['wed_manager'] == 1) {
                                        ?>
                                <span class="text-dark">Wedding
                                    Manager</span><br>
                                <span>(help with co-ordination)</span>
                                <?php
                                        }
                                        ?>
                                <?php
                                        if ($rb['wed_all'] == 1) {
                                        ?>
                                <span class="text-dark">Ready-Made
                                    Wedding</span><br>
                                <span>(except venue and outfit)</span>
                                <?php
                                        }
                                        ?>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <?php
                                if ($rb['confirm'] == 0 && $rb['cancle'] == 0 && $rb['book_date_from'] >= $date) {
                                ?>
                        <button class="btn btn-success" onclick="confirm_book(<?php echo $rb['book_id']; ?>)">Confirm
                            Booking</button>
                        <?php
                                }
                                ?>
                    </div>
                    <?php
                        }
                        ?>
                    <?php
                        if ($rb['pre_book'] == 1) {
                        ?>
                    <div class="row m-auto pb-1 border-bottom pt-1">
                        <div class="col-12">
                            <span class="h6">Booked Date <br> From : </span><span
                                class="text-secondary"><?php echo $rb['book_date_from']; ?></span><br><span class="h6">
                                To :
                            </span><span class="text-secondary"><?php echo $rb['book_date_to']; ?></span>
                        </div>
                    </div>

                    <?php
                        }
                        if ($rb['pre_book'] == 1 && $rb['cancle'] == 0 && $rb['book_date_from'] > $date) {
                        ?>
                    <div class="text-center p-2">
                        <button class="btn btn-danger" onclick="cancle(<?php echo $rb['book_id']; ?>)">Cancle
                            Booking</button>
                    </div>
                    <?php
                        }
                        ?>
                </div>
            </div>
            <?php
            }
        }
        ?>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        function cancle(book_id) {
            var can = confirm("Are you sure to cancle your pre booking.");
            if (can) {
                $.ajax({
                    url: "cancle_pre_book.php",
                    type: "post",
                    data: {
                        book_id: book_id
                    },
                    success: function(data, status) {
                        alert(data);
                        window.location = "";
                    }
                });
            }
        }

        function confirm_book(book_id) {
            $.ajax({
                url: "confirm.php",
                type: "post",
                data: {
                    book_id: book_id
                },
                success: function(data, status) {
                    window.location = "";
                }
            });
        }

        function preBook(baid) {
            var book_date_from = $("#book_date_from").val();
            var book_date_to = $("#book_date_to").val();
            $.ajax({
                url: "pre_book.php",
                type: "post",
                data: {
                    baid: baid,
                    book_date_from: book_date_from,
                    book_date_to: book_date_to
                },
                success: function(data, status) {
                    alert(data);
                    window.location = "";
                }
            });
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

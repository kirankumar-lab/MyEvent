<?php
require("session_business.php");
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Wedding Planner </title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        #edit_info:hover {
            color: #28A745;
            cursor: pointer;
        }

        </style>
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>Wedding Planner Specification & Rents</span>
                </div>
            </div>
            <div class="p-1">
                <form method="post" id="regForm">
                    <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                        style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                        <div class="float-right h5" id="edit_info" onclick="edit_info()"><i class="fa fa-edit"></i><span
                                class="pl-1">Edit Specification</span>
                        </div>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Wedding Planner(cost of agency service):</span>
                        </label>
                        <input type="number" name="wed_planner" id="wed_planner"
                            placeholder="Enter Wedding Planner Price" class="form-control p-2 m-1 w-50 input" value="0"
                            disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Wedding Manager(help with co-ordination):</span>
                        </label>
                        <input type="number" name="wed_manager" id="wed_manager"
                            placeholder="Enter Wedding Manager Price" class="form-control p-2 m-1 w-50 input" value="0"
                            disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Ready-Made Wedding(expect venue and outfit):</span>
                        </label>
                        <input type="number" name="wed_all" id="wed_all" placeholder="Enter Ready-Made Wedding Price"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Other Services:</span>
                        </label>
                        <input type="text" name="other_service" id="other_service" placeholder="Enter Other Services"
                            class="form-control p-2 m-1 input" disabled autofocus value="No Other Services">
                        <div id="edit_action">
                            <button class="btn btn-lg btn-success mb-2 mx-1" name="submit" id="submit"
                                type="submit">Save</button>
                            <button class="btn btn-lg btn-danger mb-2 mx-1" name="cancle" id="cancle" type="button"
                                onclick="edit_info_hide()">Cancle</button>
                        </div>
                    </div>
                </form>
                <?php
            if (isset($_POST['submit'])) {
                $wed_planner = $_POST['wed_planner'];
                $wed_manager = $_POST['wed_manager'];
                $wed_all = $_POST['wed_all'];
                $other_service = $_POST['other_service'];
                require("db/connection.php");
                $q = "select * from wedding_planner where baid=$baid";
                $query = mysqli_query($connection, $q);
                if (mysqli_num_rows($query) == 0) {
                    $q = "INSERT INTO `wedding_planner`(`baid`, `wed_planning`,`wed_manager`,`wed_all`,`other_service`)VALUES ($baid,$wed_planner,$wed_manager,$wed_all,'$other_service')";
                    $query = mysqli_query($connection, $q);
                } else {
                    $q = "UPDATE `wedding_planner` SET `wed_planning`=$wed_planner,`wed_manager`=$wed_manager,`wed_all`=$wed_all,`other_service`='$other_service' where baid=$baid and del=0";
                    $query = mysqli_query($connection, $q);
                    echo ('<script>window.location="./";</script>');
                }
            }
            ?>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="./js/bootstrap.bundle.min.js"></script>
        <script src="./js/jquery.min.js"></script>
        <script>
        function edit_info() {
            $("#edit_info").hide();
            $(".input").removeAttr("disabled");
            $(".select").removeAttr("disabled");
            $("#edit_action").show();
        }

        function edit_info_hide() {
            $("#edit_info").show();
            $(".input").attr("disabled", true);
            $(".select").attr("disabled", true);
            $("#edit_action").hide();
        }
        </script>
        <?php
    require("db/connection.php");
    $q = "select * from wedding_planner where baid=$baid and del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) == 0) {
    ?>
        <script>
        edit_info();
        </script>
        <?php
    } else {
        $venue_data = mysqli_fetch_array($query);
    ?>
        <script>
        $("#wed_planner").val("<?php echo $venue_data['wed_planning']; ?>");
        $("#wed_manager").val("<?php echo $venue_data['wed_manager']; ?>");
        $("#wed_all").val("<?php echo $venue_data['wed_all']; ?>");
        $("#other_service").val("<?php echo $venue_data['other_service']; ?>");
        edit_info_hide();
        </script>
        <?php
    }
    ?>
        <!-- ---------------------------------------- -->
    </body>

</html>

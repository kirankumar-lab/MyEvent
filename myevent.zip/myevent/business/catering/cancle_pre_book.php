<?php
require("session_business.php");
require("db/connection.php");
if (isset($_POST['book_id'])) {
    $book_id = $_POST['book_id'];
    $q = "UPDATE `booking` SET `cancle`=1 WHERE `book_id`=$book_id AND `pre_book`=1";
    mysqli_query($connection, $q);
    echo "Cancled Successfully!";
}

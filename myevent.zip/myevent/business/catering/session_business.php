<?php
session_start();
$uid = $_SESSION['uid'];
$acct_name = $_SESSION['name'];
$type = $_SESSION['type'];
$baid = $_SESSION['baid'];
if (empty($uid)) {
    header("Location:../");
}
if ($type != "business") {
    session_destroy();
    header("Location:../");
}
if (empty($baid))
    header("Location:../");
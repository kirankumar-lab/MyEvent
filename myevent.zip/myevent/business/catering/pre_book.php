<?php
require("session_business.php");
require("db/connection.php");
if (isset($_POST['baid'])) {
    $baid = $_POST['baid'];
    $book_date_from = $_POST['book_date_from'];
    $book_date_from = date("Y-m-d", strtotime($book_date_from));
    $book_date_to = $_POST['book_date_to'];
    $book_date_to = date("Y-m-d", strtotime($book_date_to));
    $currentdate = date('Y-m-d');
    if ($book_date_from >= $currentdate) {
        if ($book_date_to >= $book_date_from) {
            $q = "SELECT `book_date_from`,`book_date_to` FROM `booking` WHERE `baid`=$baid AND `cancle`=0 AND '$book_date_from'>=CURRENT_DATE AND '$book_date_to'>=CURRENT_DATE AND `book_date_from` BETWEEN '$book_date_from' AND '$book_date_to' AND `book_date_to` BETWEEN '$book_date_from' AND '$book_date_to'";
            $r = mysqli_query($connection, $q);
            if ($run = mysqli_num_rows($r) > 0) {
                echo 'Already Booked By Another User on this date.';
            } else {
                $q = "INSERT INTO `booking`(`uid`,`baid`, `book_date_from`, `book_date_to`, `pre_book`) VALUES ($uid,$baid,'$book_date_from','$book_date_to',1)";
                mysqli_query($connection, $q);
                $q = "SELECT `book_id` FROM `booking` WHERE `uid`=$uid AND `baid`=$baid ORDER BY `book_id` DESC LIMIT 1";
                $q = mysqli_query($connection, $q);
                $r = mysqli_fetch_array($q);
                $book_id = $r['book_id'];
                $q = "INSERT INTO `booking_catering`(`baid`, `book_id`) VALUES ($baid,$book_id)";
                mysqli_query($connection, $q);
                echo "Pre Booking Successfully!";
            }
        } else {
            echo 'Select Vaild Date';
        }
    } else {
        echo 'Select Vaild Date';
    }
}

<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyEvent | Contact Us</title>
    <!-- CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/floating-labels.css">
    <link rel="icon" href="img/myevent.png" type="image/x-icon">
    <!--  -->
</head>

<body class="d-flex flex-column h-100">

    <form class="form-signin" method="post">
        <div class="text-center mb-4">
            <h1 class="h3 mb-3 font-weight-normal">Contact With Us</h1>
        </div>
        <div class="form-label-group">
            <input type="text" name="name" id="inputName" onkeyup="chkname(this)" class="form-control"
                placeholder="Name" required autofocus>
            <label for="inputName">Name</label>
            <span id="errorname" class="text-danger"></span>
        </div>

        <div class="form-label-group">
            <input type="text" name="mono" id="inputMoNo" onkeyup="chkmono(this)" class="form-control"
                placeholder="Mobile No" required autofocus>
            <label for="inputMoNo">Mobile Number</label>
            <span id="errormono" class="text-danger"></span>
        </div>
        <div class="form-label-group">
            <input type="email" name="email" id="inputEmail" onkeyup="chkemail(this)" class="form-control"
                placeholder="Email address" required autofocus>
            <label for="inputEmail">Email Address</label>
            <span id="erroremail" class="text-danger"></span>
        </div>
        <div class="form-label-group">
            <input type="text" col="15" row=3 name="message" id="inputAddress" onkeyup="chkaddress(this)"
                class="form-control" placeholder="Address" required autofocus>
            <label for="inputAddress">Message</label>
            <span id="erroraddress" class="text-danger"></span>
        </div>

        <button class="btn btn-lg btn-primary btn-block mb-2" name="submit" type="submit">Submit</button>
    </form>

    <!-- Data Script -->
    <?php

    if (isset($_POST['submit'])) {
        require("db/connection.php");
        $name = $_POST['name'];
        $mono = $_POST['mono'];
        $email = $_POST['email'];
        $message = $_POST['message'];
        mysqli_query($connection, "INSERT INTO `contact`(`name`, `email`, `mono`, `message`) VALUES ('" . $name . "','" . $email . "','" . $mono . "','" . $message . "')");
        header("Location:./");
    }
    ?>


    <!-- Data Script Ends -->

    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-light text-center">
        <div class="container">
            <span class="text-muted">Copyrights &copy;2020-21. All Rights Resevered by MyEvent.</span>
        </div>
    </footer>
    <!--  -->
    <!--------------- Javascripts Link ------------->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script type="text/javascript">
    function chkname(name) {
        if (name.value.length === 0) {
            document.getElementById('errorname').innerHTML = "Please Enter Name.";
            document.getElementByName('name').focus();
            return false;
        } else {
            document.getElementById('errorname').innerHTML = "";
            return true;
        }
    }

    function chkaddress(address) {
        if (address.value.length === 0) {
            document.getElementById('erroraddress').innerHTML = "Please Enter Address.";
            document.getElementByName('address').focus();
            return false;
        } else {
            document.getElementById('erroraddress').innerHTML = "";
            return true;
        }
    }

    function chkemail(email) {
        if (email.value.length === 0) {
            document.getElementById('erroremail').innerHTML = "Please Enter Email.";
            document.getElementByName('email').focus();
            return false;
        } else {
            document.getElementById('erroremail').innerHTML = "";
            return true;
        }
    }

    function chkmono(mono) {
        if (isNaN(mono.value)) {
            document.getElementById('errormono').innerHTML = "Please Enter Only Digits.";
            document.getElementByName('mono').focus();
            return false;
        }
        if (mono.value.length === 10) {
            document.getElementById('errormono').innerHTML = "";
            return false;
        } else {
            document.getElementById('errormono').innerHTML = "Please Enter 10 Digit Phone Number.";
            document.getElementByName('mono').focus();
            return true;
        }
    }
    </script>

    <!-- ---------------------------------------- -->
</body>

</html>
<?php
require("session_business.php");
require("db/connection.php");
?>
<!-- Get Image Records -->
<?php
$q = "select * from image where baid=$baid and del=0";
$query = mysqli_query($connection, $q);
$num = mysqli_num_rows($query);
echo '<script>$("#numImage").text(' . $num . ');</script>';
if ($num == 0) {
    echo '<script>UploadImageShow();</script>';
}
if ($num == 10) {
    echo '<script>UploadImageBTN();</script>';
}
?>
<!-- ----------------- -->

<!-- Get Images -->
<?php
$q = "select * from image where baid=$baid and del=0";
$query = mysqli_query($connection, $q);
while ($result = mysqli_fetch_array($query)) {
?>
<div class="p-1">
    <div class="card" style="width:18rem;">
        <img class="card-img-top" src="<?php echo $result['src']; ?>" alt="Card image">
        <div class="card-footer text-right" id="delImage">
            <button class="btn btn-outline-danger" title="Delete Image"
                onclick="delImage(<?php echo $result['id']; ?>)"><i class="fa fa-close pr-1"
                    aria-hidden="true"></i>Delete
                Image</button>
        </div>
    </div>
</div>
<?php
}
?>
<!-- ---------- -->

<!-- Image Delete -->
<?php
if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $q = "UPDATE `image` SET `del`=1 WHERE id=$id";
    mysqli_query($connection, $q);
}
?>
<!-- ------------ -->

<?php
require("session_business.php");
require("db/connection.php");
if (isset($_POST['book_id'])) {
    $book_id = $_POST['book_id'];
    $q = "UPDATE `booking` SET `confirm`=1 WHERE `book_id`=$book_id AND `cancle`=0";
    mysqli_query($connection, $q);
}

<!-- ------------Navbar & SideBar--------------- -->
<nav class="navbar navbar-light sticky-top bg-light flex-md-nowrap p-0 shadow">
    <div class="navbar-brand-light col-md-3 col-lg-2 mr-0 px-3">
        <img src="../img/MyEvent.png" alt="MyEvent" width="75%"><br />
        <h5 class="text-center">Business panel</h5>
    </div>
    <div class="nav-item pr-sm-3 dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="myaccount" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false"><i class="fa fa-user p-1"></i><?php echo $acct_name; ?></a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="myaccount">
            <a href="profile.php" class="dropdown-item"><i class="fa fa-user p-1"></i>&nbsp;Profile</a>
            <a href="logout.php" class="dropdown-item"><i class="fa fa-power-off p-1"></i>&nbsp;Logout</a>
        </div>
    </div>
</nav>
<!-- -----------Navbar & SideBar End------------ -->

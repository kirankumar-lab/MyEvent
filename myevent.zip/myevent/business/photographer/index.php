<?php
require("session_business.php");
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Photographer </title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        #edit_info:hover {
            color: #28A745;
            cursor: pointer;
        }

        </style>
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>Photographer Specification & Rents</span>
                </div>
            </div>
            <div class="p-1">
                <form method="post" id="regForm">
                    <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                        style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                        <div class="float-right h5" id="edit_info" onclick="edit_info()"><i class="fa fa-edit"></i><span
                                class="pl-1">Edit Specification</span>
                        </div>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography Experience:</span>
                        </label>
                        <input type="number" name="experience" id="experience"
                            placeholder="Enter Photography Experience" class="form-control p-2 m-1 w-50 input" value="0"
                            disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Average Delivery Time of Photographic Report(in
                                months):</span>
                        </label>
                        <input type="number" name="delivery_time" id="delivery_time"
                            placeholder="Enter Delivery Time In Months" class="form-control p-2 m-1 w-50 input" disabled
                            autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography Package 1 day:</span>
                        </label>
                        <input type="number" name="photo_day" id="photo_day"
                            placeholder="Enter Photography Package Price for 1 day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography + Vedio Package 1 day:</span>
                        </label>
                        <input type="number" name="photo_vedio_day" id="photo_vedio_day"
                            placeholder="Enter Photography + Vedio Package Price for 1 day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>

                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography Package 2 day:</span>
                        </label>
                        <input type="number" name="photo_2_day" id="photo_2_day"
                            placeholder="Enter Photography Package Price for 2 day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography + Vedio Package 2 day:</span>
                        </label>
                        <input type="number" name="photo_vedio_2_day" id="photo_vedio_2_day"
                            placeholder="Enter Photography + Vedio Package Price for 2 day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>

                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography Package 3 day:</span>
                        </label>
                        <input type="number" name="photo_3_day" id="photo_3_day"
                            placeholder="Enter Photography Package Price for 3 day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Photography + Vedio Package 3 day:</span>
                        </label>
                        <input type="number" name="photo_vedio_3_day" id="photo_vedio_3_day"
                            placeholder="Enter Photography + Vedio Package Price for 1 day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Album Price Additionally:</span>
                        </label>
                        <input type="number" name="album" id="album" placeholder="Enter Album Additionally Price"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Other Services:</span>
                        </label>
                        <input type="text" name="other_service" id="other_service" placeholder="Enter Other Services"
                            class="form-control p-2 m-1 input" disabled autofocus value="No Other Service">
                        <div id="edit_action">
                            <button class="btn btn-lg btn-success mb-2 mx-1" name="submit" id="submit"
                                type="submit">Save</button>
                            <button class="btn btn-lg btn-danger mb-2 mx-1" name="cancle" id="cancle" type="button"
                                onclick="edit_info_hide()">Cancle</button>
                        </div>
                    </div>
                </form>
                <?php
            if (isset($_POST['submit'])) {
                $experience = $_POST['experience'];
                $delivery_time = $_POST['delivery_time'];
                $photo_day = $_POST['photo_day'];
                $photo_vedio_day = $_POST['photo_vedio_day'];
                $photo_2_day = $_POST['photo_2_day'];
                $photo_vedio_2_day = $_POST['photo_vedio_2_day'];
                $photo_3_day = $_POST['photo_3_day'];
                $photo_vedio_3_day = $_POST['photo_vedio_3_day'];
                $album = $_POST['album'];
                $other_service = $_POST['other_service'];
                require("db/connection.php");
                $q = "select * from photographer where baid=$baid and del=0";
                $query = mysqli_query($connection, $q);
                if (mysqli_num_rows($query) == 0) {
                    $q = "INSERT INTO `photographer`(`baid`, `experience`, `delivery_time`, `photo_day`, `photo_vedio_day`, `photo_2_day`, `photo_vedio_2_day`, `photo_3_day`, `photo_vedio_3_day`, `album`, `other_service`) VALUES ($baid,$experience,$delivery_time,$photo_day,$photo_vedio_day,$photo_2_day,$photo_vedio_2_day,$photo_3_day,$photo_vedio_3_day,$album,'$other_service')";
                    $query = mysqli_query($connection, $q);
                } else {
                    $q = "UPDATE `photographer` SET `experience`=$experience,`delivery_time`=$delivery_time,`photo_day`=$photo_day,`photo_vedio_day`=$photo_vedio_day,`photo_2_day`=$photo_2_day,`photo_vedio_2_day`=$photo_vedio_2_day,`photo_3_day`=$photo_3_day,`photo_vedio_3_day`=$photo_vedio_3_day,`album`=$album,`other_service`='$other_service' where baid=$baid and del=0";
                    $query = mysqli_query($connection, $q);
                    echo ('<script>window.location="./";</script>');
                }
            }
            ?>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="./js/bootstrap.bundle.min.js"></script>
        <script src="./js/jquery.min.js"></script>
        <script>
        function edit_info() {
            $("#edit_info").hide();
            $(".input").removeAttr("disabled");
            $(".select").removeAttr("disabled");
            $("#edit_action").show();
        }

        function edit_info_hide() {
            $("#edit_info").show();
            $(".input").attr("disabled", true);
            $(".select").attr("disabled", true);
            $("#edit_action").hide();
        }
        </script>
        <?php
    require("db/connection.php");
    $q = "select * from photographer where baid=$baid and del =0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) == 0) {
    ?>
        <script>
        edit_info();
        </script>
        <?php
    } else {
        $venue_data = mysqli_fetch_array($query);
    ?>
        <script>
        $("#experience").val("<?php echo $venue_data['experience']; ?>");
        $("#delivery_time").val("<?php echo $venue_data['delivery_time']; ?>");
        $("#photo_day").val("<?php echo $venue_data['photo_day']; ?>");
        $("#photo_vedio_day").val("<?php echo $venue_data['photo_vedio_day']; ?>");
        $("#photo_2_day").val("<?php echo $venue_data['photo_2_day']; ?>");
        $("#photo_vedio_2_day").val("<?php echo $venue_data['photo_vedio_2_day']; ?>");
        $("#photo_3_day").val("<?php echo $venue_data['photo_3_day']; ?>");
        $("#photo_vedio_3_day").val("<?php echo $venue_data['photo_vedio_3_day']; ?>");
        $("#album").val("<?php echo $venue_data['album']; ?>");
        $("#other_service").val("<?php echo $venue_data['other_service']; ?>");
        edit_info_hide();
        </script>
        <?php
    }
    ?>
        <!-- ---------------------------------------- -->
    </body>

</html>

<?php
require("session_business.php");
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Photographer Profile</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        #edit_info:hover {
            color: #28A745;
            cursor: pointer;
        }

        </style>
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="mx-sm-auto px-md-4 w-100">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>Photographer Information</span>
                </div>
            </div>
            <div class="p-1">
                <form method="post" id="regForm">
                    <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                        style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                        <div class="float-right h5" id="edit_info" onclick="edit_info()"><i class="fa fa-edit"></i><span
                                class="pl-1">Edit Photographer Detail</span>
                        </div>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Business Account ID:<span
                                    class="pl-2 text-dark"><?php echo $baid ?></span></span>
                        </label>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Organization Name:</span>
                        </label>
                        <input type="text" name="name_organization" id="name_organization"
                            placeholder="Enter Oraganization Name" class="form-control p-2 m-1 input" disabled autofocus
                            required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Address:</span>
                        </label>
                        <input type="text" name="address" id="address" placeholder="Enter Address"
                            class="form-control p-2 m-1 input" disabled autofocus required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">City:</span>
                        </label>
                        <input type="text" name="city" id="city" placeholder="Enter City"
                            class="form-control p-2 m-1 input" disabled autofocus required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Email:</span>
                        </label>
                        <input type="email" name="email" id="email" placeholder="Enter email"
                            class="form-control p-2 m-1 input" disabled autofocus required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Mobile Number:</span>
                        </label>
                        <input type="text" name="mono" id="mono" placeholder="Enter Mobile Number"
                            class="form-control p-2 m-1 input" onkeyup="chkmono(this)" disabled autofocus required>
                        <p id="errormono" class="text-danger"></p>
                        <div class=" text-center">
                            <button type="button" onclick="delPhotographer(<?php echo $baid; ?>)" name="delete"
                                id="delete" class="btn btn-lg btn-danger mb-2 mx-1">Delete
                                This
                                Photographer</button>
                        </div>
                        <div id="edit_action">
                            <button class="btn btn-lg btn-success mb-2 mx-1" name="submit" id="submit"
                                type="submit">Save</button>

                            <button class="btn btn-lg btn-danger mb-2 mx-1" name="cncl" id="cncl" type="button"
                                onclick="edit_info_hide()">Cancle</button>
                        </div>
                    </div>
                </form>
                <?php
            if (isset($_POST['submit'])) {
                $name_organization = $_POST['name_organization'];
                $address = $_POST['address'];
                $city = $_POST['city'];
                $email = $_POST['email'];
                $mono = $_POST['mono'];
                require("db/connection.php");
                $q = "UPDATE `business_account` SET `name_organization`='$name_organization',`address`='$address',`city`='$city',`email`='$email',`mono`='$mono' WHERE baid=$baid and del=0";
                $query = mysqli_query($connection, $q);
                echo ('<script>window.location="./profile.php";</script>');
            }
            ?>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script type="text/javascript">
        function chkmono(mono) {
            if (isNaN(mono.value)) {
                document.getElementById('errormono').innerHTML = "Please Enter Only Digits.";
                document.getElementByName('mono').focus();
            }
            if (mono.value.length === 10) {
                document.getElementById('errormono').innerHTML = "";
            } else {
                document.getElementById('errormono').innerHTML = "Please Enter 10 Digit Phone Number.";
                document.getElementByName('mono').focus();
            }
        }
        </script>
        <script>
        function edit_info() {
            $("#edit_info").hide();
            $(".input").removeAttr("disabled");
            $(".select").removeAttr("disabled");
            $("#delete").hide();
            $("#edit_action").show();
        }

        function edit_info_hide() {
            $("#edit_info").show();
            $(".input").attr("disabled", true);
            $(".select").attr("disabled", true);
            $("#delete").show();
            $("#edit_action").hide();
        }

        function delPhotographer(baid) {
            var conf = confirm("Are you sure to delete your this Photographer?");
            if (conf == true) {
                $.ajax({
                    url: "delPhotographer.php",
                    type: 'post',
                    data: {
                        baid: baid
                    },

                    success: function(status) {
                        window.location = "../";
                    }
                });
            }
        }
        </script>
        <?php
    require("db/connection.php");
    $q = "select * from business_account where baid=$baid";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) == 0) {
    ?>
        <script>
        edit_info();
        </script>
        <?php
    } else {
        $venue_data = mysqli_fetch_array($query);
    ?>
        <script>
        $("#name_organization").val("<?php echo $venue_data['name_organization']; ?>");
        $("#address").val("<?php echo $venue_data['address']; ?>");
        $("#city").val("<?php echo $venue_data['city']; ?>");
        $("#email").val("<?php echo $venue_data['email']; ?>");
        $("#mono").val("<?php echo $venue_data['mono']; ?>");
        edit_info_hide();
        </script>
        <?php
    }
    ?>
        <!-- ---------------------------------------- -->
    </body>

</html>

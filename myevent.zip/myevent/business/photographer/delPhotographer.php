<?php
require("session_business.php");
if ($baid === $_POST['baid']) {
    require("db/connection.php");
    $q = "UPDATE `business_account` SET `del`=1 WHERE baid=$baid and del=0";
    $query = mysqli_query($connection, $q);
    $q = "UPDATE `photographer` SET `del`=1 where baid=$baid and del=0";
    $query = mysqli_query($connection, $q);
} else {
    header("Location:../");
}

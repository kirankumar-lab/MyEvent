<?php
require("session_business.php");
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Venue </title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        #edit_info:hover {
            color: #28A745;
            cursor: pointer;
        }

        </style>
        <!-- --------------------------------------------- -->
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>Venue Specification & Rents</span>
                </div>
            </div>
            <div class="p-1">
                <form method="post" id="regForm">
                    <div class="text-left mb-4 text-capitalize border p-3" class="bg-light"
                        style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                        <div class="float-right h5" id="edit_info" onclick="edit_info()"><i class="fa fa-edit"></i><span
                                class="pl-1">Edit Specification</span>
                        </div>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Space Type:</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="type" id="type">
                            <option value="indoor space">indoor space</option>
                            <option value="outdoor space">outdoor space</option>
                            <option value="indoor + outdoor space">indoor + outdoor space</option>
                        </select>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">People Capacity:</span>
                        </label>
                        <input type="number" name="capacity" id="capacity" placeholder="Enter People Capacity"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Firecrackers Are Allowed?</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="firecrackers" id="firecrackers">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Private Parking Available?</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="private_parking"
                            id="private_parking">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Alcohol Allowed?</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="alcohol" id="alcohol">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Decoration Policy</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="deco_policy" id="deco_policy"
                            onchange="decoCHG()">
                            <option value="inhouse decoration only">Inhouse Decoration Only</option>
                            <option value="other allowed">Other Allowed</option>
                        </select>
                        <div id="decoPrice">
                            <label class="btn pt-lg-2 pb-lg-1">
                                <span class="h5 text-black-50">Decoration Rent:</span>
                            </label>
                            <input type="number" name="deco_price" id="deco_price" placeholder="Enter Decoration Price"
                                class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        </div>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Food Policy</span>
                        </label>
                        <select class="form-select text-capitalize w-50 select" name="food_policy" id="food_policy"
                            onchange="foodCHG()">
                            <option value="inhouse food only">Inhouse Food Only</option>
                            <option value="other allowed">Other Allowed</option>
                            <option value="inhouse food only">Inhouse Food Or Other Allowed</option>
                        </select>
                        <div id="foodPrice">
                            <label class="btn pt-lg-2 pb-lg-1">
                                <span class="h5 text-black-50">Veg. per Plate Price(with taxes):</span>
                            </label>
                            <input type="number" name="veg_price" id="veg_price" placeholder="Enter Veg. Price"
                                class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                            <label class="btn pt-lg-2 pb-lg-1">
                                <span class="h5 text-black-50">Non-Veg. per Plate Price(with taxes):</span>
                            </label>
                            <input type="number" name="non_veg_price" id="non_veg_price"
                                placeholder="Enter Non-Veg. Price" class="form-control p-2 m-1 w-50 input" value="0"
                                disabled autofocus>
                        </div>

                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Payments Method For Offline Booking:</span>
                        </label>
                        <br />
                        <label class="btn pt-lg-2 pb-lg-1">
                            <input type="checkbox" name="cash" id="cash" class="form-check-inline px-3  input" value="1"
                                disabled autofocus checked><span>Cash</span>
                        </label>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <input type="checkbox" name="credit_debit_card" id="credit_debit_card"
                                class="form-check-inline px-3 input" value="1" disabled autofocus><span>Credit / Debit
                                Card</span>
                        </label>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <input type="checkbox" name="bank_transfer" id="bank_transfer"
                                class="form-check-inline px-3 input" value="1" disabled autofocus><span>Bank
                                Transfer</span>
                        </label>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <input type="checkbox" name="cheque" id="cheque" class="form-check-inline px-3 input"
                                value="1" disabled autofocus><span>Cheque</span>
                        </label>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Venue Rent Per Day:</span>
                        </label>
                        <input type="number" name="rent" id="rent" placeholder="Enter Venue Rent Per Day"
                            class="form-control p-2 m-1 w-50 input" value="0" disabled autofocus>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Other Specification:</span>
                        </label>
                        <input type="text" name="other_specification" id="other_specification"
                            placeholder="Enter Other Specification" class="form-control p-2 m-1 input" disabled
                            autofocus value="No Other Specification">
                        <div id="edit_action">
                            <button class="btn btn-lg btn-success mb-2 mx-1" name="submit" id="submit"
                                type="submit">Save</button>
                            <button class="btn btn-lg btn-danger mb-2 mx-1" name="cancle" id="cancle" type="button"
                                onclick="edit_info_hide()">Cancle</button>
                        </div>
                    </div>
                </form>
                <?php
            if (isset($_POST['submit'])) {
                $type = $_POST['type'];
                $capacity = $_POST['capacity'];
                $firecrackers = $_POST['firecrackers'];
                $private_parking = $_POST['private_parking'];
                $alcohol = $_POST['alcohol'];
                $deco_policy = $_POST['deco_policy'];
                $deco_price = $_POST['deco_price'];
                $food_policy = $_POST['food_policy'];
                $veg_price = $_POST['veg_price'];
                $non_veg_price = $_POST['non_veg_price'];
                if (!empty($_POST['cash'])) {
                    $cash = $_POST['cash'];
                } else {
                    $cash = 0;
                }
                if (!empty($_POST['credit_debit_card'])) {
                    $credit_debit_card = $_POST['credit_debit_card'];
                } else {
                    $credit_debit_card = 0;
                }
                if (!empty($_POST['bank_transfer'])) {
                    $bank_transfer = $_POST['bank_transfer'];
                } else {
                    $bank_transfer = 0;
                }
                if (!empty($_POST['cheque'])) {
                    $cheque = $_POST['cheque'];
                } else {
                    $cheque = 0;
                }
                $rent = $_POST['rent'];
                $other_specification = $_POST['other_specification'];
                require("db/connection.php");
                $q = "select * from venue where baid=$baid";
                $query = mysqli_query($connection, $q);
                if (mysqli_num_rows($query) == 0) {
                    $q = "INSERT INTO `venue`(`baid`, `type`, `capacity`, `firecrackers`, `private_parking`, `alcohol`, `deco_policy`, `deco_price`, `cash`, `credit_debit_card`, `bank_transfer`, `cheque`, `food_policy`, `veg_price`, `non_veg_price`, `rent`, `other_specification`)VALUES ($baid,'$type',$capacity,$firecrackers,$private_parking,$alcohol,'$deco_policy',$deco_price,$cash,$credit_debit_card,$bank_transfer,$cheque,'$food_policy',$veg_price,$non_veg_price,$rent,'$other_specification')";
                    $query = mysqli_query($connection, $q);
                } else {
                    $q = "UPDATE `venue` SET `type`='$type', `capacity`=$capacity, `firecrackers`=$firecrackers, `private_parking`=$private_parking, `alcohol`=$alcohol, `deco_policy`='$deco_policy', `deco_price`=$deco_price, `cash`=$cash, `credit_debit_card`=$credit_debit_card, `bank_transfer`=$bank_transfer, `cheque`=$cheque, `food_policy`='$food_policy', `veg_price`=$veg_price, `non_veg_price`=$non_veg_price, `rent`=$rent, `other_specification`='$other_specification' where baid=$baid and del=0";
                    $query = mysqli_query($connection, $q);
                    echo ('<script>window.location="./";</script>');
                }
            }
            ?>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="./js/bootstrap.bundle.min.js"></script>
        <script src="./js/jquery.min.js"></script>
        <script>
        function decoCHG() {
            if ($("#deco_policy").val() == "other allowed") {
                $("#decoPrice").hide();
            } else {
                $("#decoPrice").show();
            }
        }

        function foodCHG() {
            if ($("#food_policy").val() == "other allowed") {
                $("#foodPrice").hide();
            } else {
                $("#foodPrice").show();
            }
        }

        function edit_info() {
            $("#edit_info").hide();
            $(".input").removeAttr("disabled");
            $(".select").removeAttr("disabled");
            $("#edit_action").show();
        }

        function edit_info_hide() {
            $("#edit_info").show();
            $(".input").attr("disabled", true);
            $(".select").attr("disabled", true);
            $("#edit_action").hide();
            decoCHG();
            foodCHG();
        }
        </script>
        <?php
    require("db/connection.php");
    $q = "select * from venue where baid=$baid and del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) == 0) {
    ?>
        <script>
        edit_info();
        </script>
        <?php
    } else {
        $venue_data = mysqli_fetch_array($query);
    ?>
        <script>
        $("#type").val("<?php echo $venue_data['type']; ?>");
        $("#capacity").val("<?php echo $venue_data['capacity']; ?>");
        $("#firecrackers").val("<?php echo $venue_data['firecrackers']; ?>");
        $("#private_parking").val("<?php echo $venue_data['private_parking']; ?>");
        $("#alcohol").val("<?php echo $venue_data['alcohol']; ?>");
        $("#deco_policy").val("<?php echo $venue_data['deco_policy']; ?>");
        $("#deco_price").val("<?php echo $venue_data['deco_price']; ?>");
        $("#food_policy").val("<?php echo $venue_data['food_policy']; ?>");
        $("#veg_price").val("<?php echo $venue_data['veg_price']; ?>");
        $("#non_veg_price").val("<?php echo $venue_data['non_veg_price']; ?>");
        </script>
        <?php
        if ($venue_data['cash'] == 1) {
            echo '<script>$("#cash").attr("checked",true);</script>';
        } else {
            echo '<script>$("#cash").attr("checked",false);</script>';
        }
        if ($venue_data['credit_debit_card'] == 1) {
            echo '<script>$("#credit_debit_card").attr("checked",true);</script>';
        } else {
            echo '<script>$("#credit_debit_card").attr("checked",false);</script>';
        }
        if ($venue_data['bank_transfer'] == 1) {
            echo '<script>$("#bank_transfer").attr("checked",true);</script>';
        } else {
            echo '<script>$("#bank_transfer").attr("checked",false);</script>';
        }
        if ($venue_data['cheque'] == 1) {
            echo '<script>$("#cheque").attr("checked",true);</script>';
        } else {
            echo '<script>$("#cheque").attr("checked",false);</script>';
        }
        ?>
        <script>
        $("#rent").val("<?php echo $venue_data['rent']; ?>");
        $("#other_specification").val("<?php echo $venue_data['other_specification']; ?>");
        edit_info_hide();
        </script>
        <?php
    }
    ?>
        <!-- ---------------------------------------- -->
    </body>

</html>

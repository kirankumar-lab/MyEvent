<?php
require("session_business.php");
if (isset($_POST['baid'])) {
    $_SESSION['baid'] = $_POST['baid'];
    session_commit();
}

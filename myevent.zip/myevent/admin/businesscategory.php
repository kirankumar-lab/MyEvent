<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
?>
<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Panel | MyEvent</title>
    <link rel="icon" href="img/myevent.png" type="image/x-icon">
    <!--------------------- CSS -------------------->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
    <!-- --------------------------------------------- -->
    <style>
    .dash-text {
        font-size: 15px;
        font-weight: bolder;
    }
    </style>
</head>

<body class="d-flex flex-column h-100">

    <!-- navbar -->
    <?php
    include("navbar.php");
    ?>
    <!--  -->

    <!-- main -->
    <main class="col-md-9 ml-sm-auto col-lg-10 pl-4">
        <div class="pt-3 pb-2 mb-3 mr-2 border-bottom">
            <h1 class="h2">Users</h1>
        </div>
        <?php
        require("db/totalrecord.php");
        ?>
        <div class="pb-2 border-bottom mr-2">
            <div class="bg-primary border border-primary text-light m-1 m-auto">
                <div class="row m-1">
                    <div class="col-sm-6 text-left">
                        <span><i class="fa fa-5x pt-4 fa-th-list"></i></span>
                    </div>
                    <div class="col-sm-6 text-right pt-4">
                        <div>
                            <h3><?php echo $totalbcat ?></h3>
                        </div>
                        <div>
                            <p class="dash-text">Total<br />Business Categories</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="border-bottom border-dark mr-2 pt-2 pb-5 px-2">
            <div class="m-1 p-2 mr-5">
                <section class="text-right">
                    <a href="add_business_category.php">
                        <button type="button" class="btn btn-success">Add
                            Category&nbsp;&nbsp;<i class="fa fa-plus"></i></button>
                    </a>
                </section>
            </div>
            <div class="m-1 p-2 mr-5 bg-light text-dark border">
                <label class="form-label text-uppercase font-weight-bolder pt-1">Business Categories :
                </label>
            </div>
            <div id="businesscategorydata" class="m-1 p-2 mr-5">
            </div>
        </div>
    </main>
    <!--  -->

    <!-- footer -->
    <?php
    include("footer.php");
    ?>
    <!--  -->

    <!--------------- Javascripts Link ------------->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        showdata();
    });

    function showdata() {
        $.ajax({
            url: 'show_business_category.php',
            type: 'post',

            success: function(data) {
                $('#businesscategorydata').html(data);
            }
        });
    }

    function Delete(bid) {
        var conf = confirm("Are you Sure to Delete Category?");
        if (conf == true) {
            $.ajax({
                url: "remove_business_category.php",
                type: 'post',
                data: {
                    bid: bid
                },

                success: function(data, status) {
                    showdata();
                }
            });
        }
    }

    function Recover(rbid) {
        var conf = confirm("Are you Sure to Recover Category?");
        if (conf == true) {
            $.ajax({
                url: "remove_business_category.php",
                type: 'post',
                data: {
                    rbid: rbid
                },

                success: function(data, status) {
                    showdata();
                }
            });
        }
    }
    </script>
    <!-- ---------------------------------------- -->
</body>

</html>
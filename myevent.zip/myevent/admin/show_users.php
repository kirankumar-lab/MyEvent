<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
require("db/connection.php");
$limit = 1;
$page = isset($_POST['page']) ? $_POST['page'] : 1;
$start = ($page - 1) * $limit;
?>
<div class="m-1 p-2 mr-5 bg-light text-dark border">
    <label class="text-uppercase font-weight-bolder">Registred User :</label>
    <div class="p-1">
        <?php
        $q = "select count(uid) as total_user from user;";
        $query = mysqli_query($connection, $q);
        $result = mysqli_fetch_array($query);
        $total_user = $result['total_user'];
        $pages = ceil($total_user / $limit);
        ?>
        <div class="btn-group justify-content-center float-left">
            <button <?php if ($page == 1) {
                        echo "disabled";
                    } ?> aria-label="Previous" onclick="showdata(<?php echo ($page - 1); ?>)"
                class="btn btn-outline-dark">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </button>
            <button <?php if ($page == $pages || $pages == 0) {
                        echo "disabled";
                    } ?> class="btn btn-outline-dark" onclick="showdata(<?php echo ($page + 1); ?>)" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </button>
        </div>
        <div class="float-right">
            <span class="font-weight-bold">Page: <?php if ($pages == 0) {
                                                        echo $pages;
                                                    } else {
                                                        echo $page;
                                                    } ?> of <?php echo $pages; ?> </span>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php
$q = "select * from user LIMIT $start, $limit;";
$query = mysqli_query($connection, $q);
if (mysqli_num_rows($query) > 0) {
?>
<table class="table table-striped table-hover table-bordered table-responsive text-center">
    <thead>
        <tr>
            <th>UID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>Address</th>
            <th>User type</th>
            <th>Timestamp</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php
            while ($result = mysqli_fetch_array($query)) {
            ?>
        <tr>
            <td><?php echo $result['uid'] ?></td>
            <td><?php echo $result['name'] ?></td>
            <td><?php echo $result['email'] ?></td>
            <td><?php echo $result['mono'] ?></td>
            <td><?php echo $result['address'] ?></td>
            <td><?php echo $result['type'] ?></td>
            <td><?php echo $result['timestamp'] ?></td>
            <td>
                <?php
                        if ($result['del'] == 1) {
                            echo '<span class="text-danger">This user was Deleted.<br> You Want Restore this user? Click on </span><b><a role="button" onClick="Recover(' . $result['uid'] . ');" class="text-success">Restore&nbsp;</a></b>';
                        } else {
                            echo '<button type="button" onClick="Delete(' . $result['uid'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                        }
                        ?>
            </td>
        </tr>
        <?php
            }
        }
        ?>
    </tbody>
</table>

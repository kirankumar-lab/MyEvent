<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Dashboard | MyEvent</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/dashboard.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .dash-text {
            font-size: 15px;
            font-weight: bolder;
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- navbar -->
        <?php
    include("navbar.php");
    ?>
        <!--  -->

        <!-- main -->
        <main class="col-md-9 ml-sm-auto col-lg-10 pl-4">
            <div class="pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
            </div>
            <?php
        require("db/totalrecord.php");
        ?>
            <div class="row pt-3 pb-2 mb-3 border-bottom mr-2">
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-primary border border-primary text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-users"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totaluser ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total<br /> Users</p>
                            </div>
                        </div>
                    </div>
                    <a href="users.php" class="text-decoration-none text-primary">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-primary border border-primary text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-th-list"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totalbcat ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Business Categories</p>
                            </div>
                        </div>
                    </div>
                    <a href="businesscategory.php" class="text-decoration-none text-primary">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-primary border border-primary text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-address-card"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totalbacc ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total Vendors</p>
                            </div>
                        </div>
                    </div>
                    <a href="vendors.php" class="text-decoration-none text-primary">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-primary border border-primary text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-book"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $total_booking; ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total Booking</p>
                            </div>
                        </div>
                    </div>
                    <a href="book.php" class="text-decoration-none text-primary">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-primary border border-primary text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-book"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $total_pre_book; ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total Pre Booking</p>
                            </div>
                        </div>
                    </div>
                    <a href="book.php" class="text-decoration-none text-primary">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-warning border border-warning text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-book"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $total_request_booking; ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Resquested Booking</p>
                            </div>
                        </div>
                    </div>
                    <a href="book.php" class="text-decoration-none text-warning">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-success border border-success text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-book"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $total_confirm_booking; ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Confirmed Booking</p>
                            </div>
                        </div>
                    </div>
                    <a href="book.php" class="text-decoration-none text-success">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-danger border border-danger text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-book"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $total_cancle_booking; ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Cancled Booking</p>
                            </div>
                        </div>
                    </div>
                    <a href="book.php" class="text-decoration-none text-danger">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-info border border-info text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-comments"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totalfb ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total Feedbacks</p>
                            </div>
                        </div>
                    </div>
                    <a href="feedback.php" class="text-decoration-none text-info">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-4 col-lg-2 col-md-3 bg-danger border border-danger text-light m-1">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-envelope"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $penddingc ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Pending Contact</p>
                            </div>
                        </div>
                    </div>
                    <a href="contact.php" class="text-decoration-none text-danger">
                        <div class="bg-light row py-1">
                            <div class="col-sm-6 text-left">View Detail</div>
                            <div class="col-sm-6 text-right"><span><i class="fa fa-arrow-circle-right"></span></i>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
        </main>
        <!--  -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!--  -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <!-- ---------------------------------------- -->
    </body>

</html>

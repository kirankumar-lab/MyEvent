<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel | MyEvent</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/dashboard.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .dash-text {
            font-size: 15px;
            font-weight: bolder;
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- navbar -->
        <?php
    include("navbar.php");
    ?>
        <!--  -->

        <!-- main -->
        <main class="col-md-9 ml-sm-auto col-lg-10 pl-4">
            <div class="pt-3 border-bottom text-left w-100">
                <div class="h2">
                    <span>My Profile</span>
                </div>
            </div>
            <div class="p-1">
                <div class="text-left mb-4 text-capitalize border p-3" class="bg-light" id="profile"
                    style="border-radius: 15px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1)">
                    <form method="post" id="regForm">
                        <div class="float-right h5" id="edit_info" onclick="edit_info()"><i class="fa fa-edit"></i><span
                                class="pl-1">Edit Profile</span>
                        </div>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Admin ID:<span
                                    class="pl-2 text-dark"><?php echo $aid ?></span></span>
                        </label>
                        <br>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Name:</span>
                        </label>
                        <input type="text" name="name" id="name" placeholder="Enter Your Name"
                            class="form-control p-2 m-1 input" disabled autofocus required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Address:</span>
                        </label>
                        <input type="text" name="address" id="address" placeholder="Enter Your Address"
                            class="form-control p-2 m-1 input" disabled autofocus required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Email:</span>
                        </label>
                        <input type="email" name="email" id="email" placeholder="Enter Your email"
                            class="form-control p-2 m-1 input" disabled autofocus required>
                        <label class="btn pt-lg-2 pb-lg-1">
                            <span class="h5 text-black-50">Mobile Number:</span>
                        </label>
                        <input type="text" name="mono" id="mono" placeholder="Enter Mobile Number"
                            class="form-control p-2 m-1 input" onkeyup="chkmono(this)" disabled autofocus required>
                        <p id="errormono" class="text-danger"></p>
                        <div class="text-center">
                            <button type="button" name="chgpass" id="chgpass" class="btn btn-lg btn-danger mb-2 mx-1"
                                onclick="chg_pass_action()">Change Password</button>
                        </div>
                        <div id="edit_action">
                            <button class="btn btn-lg btn-success mb-2 mx-1" name="submit" id="submit"
                                type="submit">Save</button>
                            <button class="btn btn-lg btn-danger mb-2 mx-1" name="cancle" id="cancle" type="button"
                                onclick="edit_info_hide()">Cancle</button>
                        </div>
                    </form>
                    <div id="chg_pass_action">
                        <div class="pt-lg-2 pb-lg-1 h5 text-black-50 text-center">
                            Change Password
                        </div>
                        <form method="post" name="chgpassForm" id="chgpassForm">
                            <div>
                                <label class="btn pt-lg-2 pb-lg-1">
                                    <span class="h5 text-black-50">New Password:</span>
                                </label>
                                <input type="password" name="password" id="password" placeholder="Enter New Password"
                                    onkeyup="chkpass(this)" class="form-control p-2 m-1 inputchgpass" disabled autofocus
                                    required>
                                <span id="errorpass" class="text-danger"></span>
                            </div>
                            <div>
                                <label class="btn pt-lg-2 pb-lg-1">
                                    <span class="h5 text-black-50">Confirm Password:</span>
                                </label>
                                <input type="password" name="con_password" id="con_password"
                                    placeholder="Enter Confirm New Password" onkeyup="chkcon_pass(this)"
                                    class="form-control p-2 m-1 inputchgpass" disabled autofocus required>

                                <span id="errorcon_pass" class="text-danger"></span>
                            </div>
                            <br>
                            <div class="text-center">
                                <button class="btn btn-lg btn-success mb-2 mx-1" name="chg_pass" id="chg_pass"
                                    type="submit">Change
                                    Password</button>
                                <button class="btn btn-lg btn-danger mb-2 mx-1" name="cancle" id="cancle" type="button"
                                    onclick="chg_pass_action_hide()">Cancle</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
        if (isset($_POST['submit'])) {
            $name = $_POST['name'];
            $address = $_POST['address'];
            $email = $_POST['email'];
            $mono = $_POST['mono'];
            require("db/connection.php");
            $q = "UPDATE `admin` SET `name`='$name',`address`='$address',`email`='$email',`mono`='$mono' WHERE aid=$aid and del=0";
            $query = mysqli_query($connection, $q);
        }
        if (isset($_POST['chg_pass'])) {
            $password = $_POST['password'];
            require("db/connection.php");
            $q = "UPDATE `admin` SET `password`='$password' WHERE aid=$aid and del=0";
            $query = mysqli_query($connection, $q);
        }
        ?>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        function edit_info() {
            $("#edit_info").hide();
            $("#chgpass").hide();
            $(".input").removeAttr("disabled");
            $("#edit_action").show();
        }

        function edit_info_hide() {
            $("#edit_info").show();
            $("#chgpass").show();
            $(".input").attr("disabled", true);
            $("#edit_action").hide();
        }

        function chg_pass_action() {
            $("#edit_info").hide();
            $("#chgpass").hide();
            $("#regForm").hide();
            $(".inputchgpass").removeAttr("disabled");
            $("#chg_pass_action").show();
        }

        function chg_pass_action_hide() {
            $("#edit_info").show();
            $("#chgpass").show();
            $("#regForm").show();
            $(".inputchgpass").attr = "disabled";
            $("#chg_pass_action").hide();
        }

        function chkpass(pass) {
            if (pass.value.length === 0) {
                document.getElementById('errorpass').innerHTML = "Please Enter Password.";
                document.getElementByName('password').focus();
                return false;
            }
            if (pass.value.length < 8 || pass.value.length > 20) {
                document.getElementById('errorpass').innerHTML = "Please Enter Password length must be 8 to 20.";
                document.getElementByName('password').focus();
                return false;
            } else {
                document.getElementById('errorpass').innerHTML = "";
                return true;
            }
        }

        function chkcon_pass(con_pass) {
            if (con_pass.value.length === 0) {
                document.getElementById('errorcon_pass').innerHTML = "Please Enter Confirm Password.";
                document.getElementByName('con_password').focus();
                return false;
            }
            if ($("#con_password").val() != $("#password").val()) {
                document.getElementById('errorcon_pass').innerHTML = "Confirm Password must be not match.";
                document.getElementByName('con_password').focus();
                return false;
            } else {
                document.getElementById('errorcon_pass').innerHTML = "";
                return true;
            }
        }
        </script>
        <?php
    require("db/connection.php");
    $q = "select * from admin where aid=$aid";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) == 1) {
        $data = mysqli_fetch_array($query);
    ?>
        <script>
        $("#name").val("<?php echo $data['name']; ?>");
        $("#address").val("<?php echo $data['address']; ?>");
        $("#email").val("<?php echo $data['email']; ?>");
        $("#mono").val("<?php echo $data['mono']; ?>");
        edit_info_hide();
        chg_pass_action_hide();
        </script>
        <?php
    }
    ?>
        <!-- ---------------------------------------- -->
    </body>

</html>

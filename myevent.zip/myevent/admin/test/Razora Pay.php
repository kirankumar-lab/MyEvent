<?php
// -------------------------------------Order or Booking
$order = $client->order->create([
    'receipt' => 'order_rcptid_11',
    'amount' => 50000, // amount in the smallest currency unit
    'currency' => 'INR', // <a href="/docs/payment-gateway/payments/international-payments/#supported-currencies" target="_blank">See the list of supported currencies</a>.)
]);

// -------------------------------------check Out
?>
<button id="rzp-button1">Pay</button>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var options = {
        "key": "YOUR_KEY_ID", // Enter the Key ID generated from the Dashboard    "amount": "50000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise    "currency": "INR",    "name": "Acme Corp",    "description": "Test Transaction",    "image": "https://example.com/your_logo",    "order_id": "order_9A33XWu170gUtm", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1    "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",    "prefill": {        "name": "Gaurav Kumar",        "email": "gaurav.kumar@example.com",        "contact": "9999999999"    },    "notes": {        "address": "Razorpay Corporate Office"    },    "theme": {        "color": "#3399cc"    }};var rzp1 = new Razorpay(options);document.getElementById('rzp-button1').onclick = function(e){    rzp1.open();    e.preventDefault();}
</script>

{ "razorpay_payment_id": "pay_29QQoUBi66xm2f", "razorpay_order_id": "order_9A33XWu170gUtm", "razorpay_signature":
"9ef4dffbfd84f1318f6739a3ce19f9d85851857ae648f114332d8401e0949a3d"}

generated_signature = hmac_sha256(order_id + "|" + razorpay_payment_id, secret); if (generated_signature ==
razorpay_signature) { payment is successful }

<?php

use Razorpay\Api\Api;

$api = new Api($key_id, $key_secret);
$attributes  = array('razorpay_signature'  => '23233',  'razorpay_payment_id'  => '332',  'order_id' => '12122');
$order  = $api->utility->verifyPaymentSignature($attributes)
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pricing Page</title>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="../font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/jquery.min.js"></script>

    </head>

    <body>
        <div class="container">
            <div class="row">
                <div class="card">
                    <div class="card-header">
                        <h2 class="pricing">$ 100</h2>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Product 1</h5>
                        <ul class="list-group">
                            <li class="list-group-item">Feature 1</li>
                            <li class="list-group-item">Feature 2</li>
                            <li class="list-group-item">Feature 3</li>
                            <li class="list-group-item">Feature 4</li>
                            <li class="list-group-item">Feature 5</li>
                        </ul>
                    </div>
                    <div class="card-footer">
                        Footer
                    </div>
                </div>
            </div>
        </div>
    </body>

</html>

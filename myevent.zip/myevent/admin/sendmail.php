<?php
if (isset($_POST['email'])) {
	$email = $_POST['email'];
	$replay_msg = $_POST['replay_msg'];
	$subject = "MyEvent";
	$body = '<p>' . $replay_msg . '</p>';

	// Enter Your Email Address Here To Receive Email
	$email_to = $email;

	$email_from = "kiranwebsite63410@gmail.com"; // Enter Sender Email
	$sender_name = "MyEvent"; // Enter Sender Name

	require("./mail/class.phpmailer.php");
	require("./mail/class.smtp.php");
	$mail = new PHPMailer(true);
	$mail->IsSMTP();
	$mail->Host = 'smtp.gmail.com;'; // Enter Your Host/Mail Server
	$mail->SMTPAuth = true;
	$mail->Username = "kiranwebsite63410@gmail.com"; // Enter Sender Email
	$mail->Password = "kiran63410";

	//If SMTP requires TLS encryption then remove comment from below
	$mail->SMTPSecure = "tls";
	$mail->Port = 587;
	$mail->IsHTML(true);

	$mail->From = $email_from;
	$mail->FromName = $sender_name;
	$mail->Sender = $email_from; // indicates ReturnPath header
	$mail->AddReplyTo($email_from, "No Reply"); // indicates ReplyTo headers
	$mail->Subject = $subject;
	$mail->Body = $body;
	$mail->AddAddress($email_to);

	if (!$mail->Send()) {
		echo "Mailer Error: Not Sent. Check your Internet Connection.";
	} else {
		require("db/connection.php");
		$cid = $_POST['cid'];
		$q = "update contact set read_msg=1,replay='$replay_msg' where cid=$cid";
		if (mysqli_query($connection, $q)) {
			echo "Sent Successfully !!";
		} else {
			echo $q;
		}
	}
}

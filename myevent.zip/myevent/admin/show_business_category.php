<table class="table table-striped table-hover table-bordered table-responsive text-capitalize text-center">
    <thead>
        <tr>
            <th>BID</th>
            <th>Category</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        require("db/connection.php");
        $q = "select bid,catagory,del from business_category;";
        $query = mysqli_query($connection, $q);
        if (mysqli_num_rows($query) > 0) {
            while ($result = mysqli_fetch_array($query)) {
        ?>
        <tr>
            <td><?php echo $result['bid'] ?></td>
            <td><?php echo $result['catagory'] ?></td>
            <td>
                <?php
                        if ($result['del'] == 1) {
                            echo '<span class="text-danger">This Category was Deleted.<br> You Want Restore this Category? Click on </span><b><a role="button" onClick="Recover(' . $result['bid'] . ');" class="text-success">Restore&nbsp;</a></b>';
                        } else {
                            echo '<button type="button" onClick="Delete(' . $result['bid'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                        }
                        ?>
            </td>
        </tr>
        <?php
            }
        }
        ?>
    </tbody>
</table>
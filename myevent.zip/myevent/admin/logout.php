<?php
  session_start();
  $aid=$_SESSION['aid'];
  if(!empty($aid))
  {
    session_destroy();
      header("Location:./");
  }

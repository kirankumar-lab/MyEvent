<?php
require("db/connection.php");
if (isset($_POST['fid'])) {
    $id = $_POST['fid'];
    $qdl = "update feedback set del=1 where fid=$id";
    mysqli_query($connection, $qdl);
}
if (isset($_POST['rfid'])) {
    $id = $_POST['rfid'];
    $qdl = "update feedback set del=0 where fid=$id";
    mysqli_query($connection, $qdl);
}

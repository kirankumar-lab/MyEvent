<?php
require("db/connection.php");

// ------------------------------------------------------ Search User
if (isset($_POST['search_word'])) {
    $search_word = $_POST['search_word'];
    $limit = 1;
    $page = isset($_POST['page']) ? $_POST['page'] : 1;
    $start = ($page - 1) * $limit;
?>
<div class="m-1 p-2 mr-5 bg-light text-dark border">
    <label class="text-uppercase font-weight-bolder">Searched User :</label>
    <div class="p-1">
        <?php
            $q = "SELECT count(uid) as total_user  FROM `user` WHERE `name` LIKE '%$search_word%' OR `email` LIKE '%$search_word%' OR `mono` LIKE '%$search_word%' OR `uid` LIKE '%$search_word%' OR `address` LIKE '%$search_word%' OR `timestamp` LIKE '%$search_word%'";
            $query = mysqli_query($connection, $q);
            $result = mysqli_fetch_array($query);
            $total_user = $result['total_user'];
            $pages = ceil($total_user / $limit);
            ?>
        <div class="btn-group justify-content-center float-left">
            <button <?php if ($page == 1) {
                            echo "disabled";
                        } ?> aria-label="Previous" onclick="Search(<?php echo ($page - 1); ?>)"
                class="btn btn-outline-dark">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </button>
            <button <?php if ($pages == 0 || $pages == $page) {
                            echo "disabled";
                        } ?> class="btn btn-outline-dark" onclick="Search(<?php echo ($page + 1); ?>)"
                aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </button>
        </div>
        <div class="float-right">
            <span class="font-weight-bold">Page: <?php if ($pages == 0) {
                                                            echo $pages;
                                                        } else {
                                                            echo $page;
                                                        } ?> of <?php echo $pages; ?> </span>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php
    $q = "SELECT *  FROM `user` WHERE `name` LIKE '%$search_word%' OR `email` LIKE '%$search_word%' OR `mono` LIKE '%$search_word%' OR `uid` LIKE '%$search_word%' OR `address` LIKE '%$search_word%' OR `timestamp` LIKE '%$search_word%' LIMIT $start, $limit";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
    ?>
<table class="table table-striped table-hover table-bordered table-responsive text-center">
    <thead>
        <tr>
            <th>UID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>Address</th>
            <th>User type</th>
            <th>Timestamp</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php
                while ($result = mysqli_fetch_array($query)) {
                ?>
        <tr>
            <td><?php echo $result['uid'] ?></td>
            <td><?php echo $result['name'] ?></td>
            <td><?php echo $result['email'] ?></td>
            <td><?php echo $result['mono'] ?></td>
            <td><?php echo $result['address'] ?></td>
            <td><?php echo $result['type'] ?></td>
            <td><?php echo $result['timestamp'] ?></td>
            <td>
                <?php
                            if ($result['del'] == 1) {
                                echo '<span class="text-danger">This user was Deleted.<br> You Want Restore this user? Click on </span><b><a role="button" onClick="Recover(' . $result['uid'] . ');" class="text-success">Restore&nbsp;</a></b>';
                            } else {
                                echo '<button type="button" onClick="Delete(' . $result['uid'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                            }
                            ?>
            </td>
        </tr>
        <?php
                }
                ?>
    </tbody>
</table>
<?php
    } else {
        echo '<div class="text-center w-100 text-danger"><i>No Records Founds.</i></div>';
    }
}

// ------------------------------------------------------ Search User End
?>

<?php
// ------------------------------------------------------ Search Vendors

if (isset($_POST['search_vendor'])) {
    $search_vendor = $_POST['search_vendor'];
    $limit = 1;
    $page = isset($_POST['page']) ? $_POST['page'] : 1;
    $start = ($page - 1) * $limit;
?>
<div class="m-1 p-2 mr-5 bg-light text-dark border">
    <label class="text-uppercase font-weight-bolder">Searched Vendors :</label>
    <div class="p-1">
        <?php
            $q = "SELECT count(baid) as total_business_account from business_account join business_category on business_category.bid=business_account.bid where `baid` LIKE '%$search_vendor%' OR `uid` LIKE '%$search_vendor%' OR `name_organization` LIKE '%$search_vendor%' OR `address` LIKE '%$search_vendor%' OR `city` LIKE '%$search_vendor%' OR `catagory` LIKE '%$search_vendor%' OR `email` LIKE '%$search_vendor%' OR `mono` LIKE '%$search_vendor%' OR business_account.timestamp LIKE '%$search_vendor%';";
            $query = mysqli_query($connection, $q);
            $result = mysqli_fetch_array($query);
            $total_business_account = $result['total_business_account'];
            $pages = ceil($total_business_account / $limit);
            ?>
        <div class="btn-group justify-content-center float-left">
            <button <?php if ($page == 1) {
                            echo "disabled";
                        } ?> aria-label="Previous" onclick="Search(<?php echo ($page - 1); ?>)"
                class="btn btn-outline-dark">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </button>
            <button <?php if ($pages == 0 || $pages == $page) {
                            echo "disabled";
                        } ?> class="btn btn-outline-dark" onclick="Search(<?php echo ($page + 1); ?>)"
                aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </button>
        </div>
        <div class="float-right">
            <span class="font-weight-bold">Page: <?php if ($pages == 0) {
                                                            echo $pages;
                                                        } else {
                                                            echo $page;
                                                        } ?> of <?php echo $pages; ?> </span>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php
    $q = "SELECT baid,uid,name_organization,address,city,email,mono,business_account.timestamp,business_account.del,catagory from business_account join business_category on business_category.bid=business_account.bid where `baid` LIKE '%$search_vendor%' OR `uid` LIKE '%$search_vendor%' OR `name_organization` LIKE '%$search_vendor%' OR `address` LIKE '%$search_vendor%' OR `city` LIKE '%$search_vendor%' OR `catagory` LIKE '%$search_vendor%' OR `email` LIKE '%$search_vendor%' OR `mono` LIKE '%$search_vendor%' OR business_account.timestamp LIKE '%$search_vendor%' LIMIT $start,$limit;";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
    ?>
<table class="table table-striped table-hover table-bordered table-responsive text-center">
    <thead>
        <tr>
            <th>BAID</th>
            <th>UID</th>
            <th>Category</th>
            <th>Organization Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>Address</th>
            <th>City</th>
            <th>Timestamp</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
                while ($result = mysqli_fetch_array($query)) {
                ?>
        <tr>
            <td><?php echo $result['baid'] ?></td>
            <td><?php echo $result['uid'] ?></td>
            <td><?php echo $result['catagory'] ?></td>
            <td><?php echo $result['name_organization'] ?></td>
            <td><?php echo $result['email'] ?></td>
            <td><?php echo $result['mono'] ?></td>
            <td><?php echo $result['address'] ?></td>
            <td><?php echo $result['city'] ?></td>
            <td><?php echo $result['timestamp'] ?></td>
            <td>
                <?php
                            if ($result['del'] == 1) {
                                echo '<span class="text-danger">This Vendor was Deleted.<br> You Want Restore this vendor? Click on </span><b><a role="button" onClick="Recover(' . $result['baid'] . ');" class="text-success">Restore&nbsp;</a></b>';
                            } else {
                                echo '<button type="button" onClick="Delete(' . $result['baid'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                            }
                            ?>
            </td>
        </tr>
        <?php
                }
                ?>
    </tbody>
</table>
<?php
    } else {
        echo '<div class="text-center w-100 text-danger"><i>No Records Founds.</i></div>';
    }
}
// ------------------------------------------------------ Search Vendors End
?>

<?php
// ------------------------------------------------------ Search Feedback

if (isset($_POST['search_feedback'])) {
    $search_feedback = $_POST['search_feedback'];
    $limit = 1;
    $page = isset($_POST['page']) ? $_POST['page'] : 1;
    $start = ($page - 1) * $limit;
?>
<div class="m-1 p-2 mr-5 bg-light text-dark border">
    <label class="text-uppercase font-weight-bolder">Searched Feedbacks :</label>
    <div class="p-1">
        <?php
            $q = "SELECT count(fid) as total_feedback from feedback where `fid` LIKE '%$search_feedback%' OR`name` LIKE '%$search_feedback%' OR `email` LIKE '%$search_feedback%' OR `message` LIKE '%$search_feedback%' OR `timestamp` LIKE '%$search_feedback%';";
            $query = mysqli_query($connection, $q);
            $result = mysqli_fetch_array($query);
            $total_feedback = $result['total_feedback'];
            $pages = ceil($total_feedback / $limit);
            ?>
        <div class="btn-group justify-content-center float-left">
            <button <?php if ($page == 1) {
                            echo "disabled";
                        } ?> aria-label="Previous" onclick="Search(<?php echo ($page - 1); ?>)"
                class="btn btn-outline-dark">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </button>
            <button <?php if ($pages == 0 || $pages == $page) {
                            echo "disabled";
                        } ?> class="btn btn-outline-dark" onclick="Search(<?php echo ($page + 1); ?>)"
                aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </button>
        </div>
        <div class="float-right">
            <span class="font-weight-bold">Page: <?php if ($pages == 0) {
                                                            echo $pages;
                                                        } else {
                                                            echo $page;
                                                        } ?> of <?php echo $pages; ?> </span>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php
    $q = "SELECT * from feedback where `fid` LIKE '%$search_feedback%' OR`name` LIKE '%$search_feedback%' OR `email` LIKE '%$search_feedback%' OR `message` LIKE '%$search_feedback%' OR `timestamp` LIKE '%$search_feedback%' LIMIT $start,$limit;";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
    ?>
<table class="table table-striped table-hover table-bordered table-responsive text-center">
    <thead>
        <tr>
            <th>FID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Timestamp</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
                while ($result = mysqli_fetch_array($query)) {
                ?>
        <tr>
            <td><?php echo $result['fid'] ?></td>
            <td><?php echo $result['name'] ?></td>
            <td><?php echo $result['email'] ?></td>
            <td><?php echo $result['message'] ?></td>
            <td><?php echo $result['timestamp'] ?></td>
            <td>
                <?php
                            if ($result['del'] == 1) {
                                echo '<span class="text-danger">This Feedback was Deleted.<br> You Want Restore this feedback? Click on </span><b><a role="button" onClick="Recover(' . $result['fid'] . ');" class="text-success">Restore&nbsp;</a></b>';
                            } else {
                                echo '<button type="button" onClick="Delete(' . $result['fid'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                            }
                            ?>
            </td>
        </tr>
        <?php
                }
                ?>
    </tbody>
</table>
<?php
    } else {
        echo '<div class="text-center w-100 text-danger"><i>No Records Founds.</i></div>';
    }
}
// ------------------------------------------------------ Search feedbacks End
?>


<?php
// ------------------------------------------------------ Search Contact

if (isset($_POST['search_contact'])) {
    $search_contact = $_POST['search_contact'];
    $limit = 1;
    $page = isset($_POST['page']) ? $_POST['page'] : 1;
    $start = ($page - 1) * $limit;
?>
<div class="m-1 p-2 mr-5 bg-light text-dark border">
    <label class="text-uppercase font-weight-bolder">Searched contact :</label>
    <div class="p-1">
        <?php
            $q = "SELECT count(cid) as total_contact from contact where `cid` LIKE '%$search_contact%' OR`name` LIKE '%$search_contact%' OR `email` LIKE '%$search_contact%'OR `mono` LIKE '%$search_contact%' OR `message` LIKE '%$search_contact%' OR `timestamp` LIKE '%$search_contact%';";
            $query = mysqli_query($connection, $q);
            $result = mysqli_fetch_array($query);
            $total_contact = $result['total_contact'];
            $pages = ceil($total_contact / $limit);
            ?>
        <div class="btn-group justify-content-center float-left">
            <button <?php if ($page == 1) {
                            echo "disabled";
                        } ?> aria-label="Previous" onclick="Search(<?php echo ($page - 1); ?>)"
                class="btn btn-outline-dark">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </button>
            <button <?php if ($pages == 0 || $pages == $page) {
                            echo "disabled";
                        } ?> class="btn btn-outline-dark" onclick="Search(<?php echo ($page + 1); ?>)"
                aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </button>
        </div>
        <div class="float-right">
            <span class="font-weight-bold">Page: <?php if ($pages == 0) {
                                                            echo $pages;
                                                        } else {
                                                            echo $page;
                                                        } ?> of <?php echo $pages; ?> </span>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php
    $q = "SELECT * from contact where `cid` LIKE '%$search_contact%' OR`name` LIKE '%$search_contact%' OR `email` LIKE '%$search_contact%'OR `mono` LIKE '%$search_contact%' OR `message` LIKE '%$search_contact%' OR `timestamp` LIKE '%$search_contact%' LIMIT $start,$limit;";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
    ?>
<table class="table table-striped table-hover table-bordered table-responsive text-center">
    <thead>
        <tr>
            <th>CID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>Message</th>
            <th>Timestamp</th>
            <th>Replay</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
                while ($result = mysqli_fetch_array($query)) {
                ?>
        <tr>
            <td><?php echo $result['cid'] ?></td>
            <td><?php echo $result['name'] ?></td>
            <td><?php echo $result['email'] ?></td>
            <td><?php echo $result['mono'] ?></td>
            <td><?php echo $result['message'] ?></td>
            <td><?php echo $result['timestamp'] ?></td>
            <td>
                <?php
                            if ($result['read_msg'] == 0) {
                            ?>
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-success"
                    onClick="setEmail('<?php echo $result['cid']; ?>','<?php echo $result['email']; ?>');"
                    data-toggle="modal" data-target="#modelId">
                    Replay&nbsp;<i class="fa fa-reply"></i></button>
                <?php
                            } else {
                                echo $result['replay'];
                            }
                            ?>
            </td>
            <td>
                <?php
                            if ($result['del'] == 1) {
                                echo '<span class="text-danger">This Contact was Deleted.<br> You Want Restore this contact? Click on </span><b><a role="button" onClick="Recover(' . $result['cid'] . ');" class="text-success">Restore&nbsp;</a></b>';
                            } else {
                                echo '<button type="button" onClick="Delete(' . $result['cid'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                            }
                            ?>
            </td>
        </tr>
        <?php
                }
                ?>
    </tbody>
</table>
<?php
    } else {
        echo '<div class="text-center w-100 text-danger"><i>No Records Founds.</i></div>';
    }
}
// ------------------------------------------------------ Search contacts End
?>

<?php
// ------------------------------------------------------ Search Pre-Booking

if (isset($_POST['search_pre_book'])) {
    $search_pre_book = $_POST['search_pre_book'];
    $limit = 1;
    $page = isset($_POST['page']) ? $_POST['page'] : 1;
    $start = ($page - 1) * $limit;
?>
<div class="m-1 p-2 mr-5 bg-light text-dark border">
    <label class="text-uppercase font-weight-bolder">Searched Booking :</label>
    <div class="p-1">
        <?php
            $q = "SELECT count(book_id) as total_pre_book from booking where pre_book=1 AND `book_id` LIKE '%$search_pre_book%' OR `uid` LIKE '%$search_pre_book%' OR `baid` LIKE '%$search_pre_book%'OR `book_date_from` LIKE '%$search_pre_book%' OR `book_date_to` LIKE '%$search_pre_book%' OR `timestamp` LIKE '%$search_pre_book%';";
            $query = mysqli_query($connection, $q);
            $result = mysqli_fetch_array($query);
            $total_pre_book = $result['total_pre_book'];
            $pages = ceil($total_pre_book / $limit);
            ?>
        <div class="btn-group justify-content-center float-left">
            <button <?php if ($page == 1) {
                            echo "disabled";
                        } ?> aria-label="Previous" onclick="Search(<?php echo ($page - 1); ?>)"
                class="btn btn-outline-dark">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </button>
            <button <?php if ($pages == 0 || $pages == $page) {
                            echo "disabled";
                        } ?> class="btn btn-outline-dark" onclick="Search(<?php echo ($page + 1); ?>)"
                aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </button>
        </div>
        <div class="float-right">
            <span class="font-weight-bold">Page: <?php if ($pages == 0) {
                                                            echo $pages;
                                                        } else {
                                                            echo $page;
                                                        } ?> of <?php echo $pages; ?> </span>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php
    $q = "SELECT * from booking where pre_book=1 AND `book_id` LIKE '%$search_pre_book%' OR`uid` LIKE '%$search_pre_book%' OR `baid` LIKE '%$search_pre_book%'OR `book_date_from` LIKE '%$search_pre_book%' OR `book_date_to` LIKE '%$search_pre_book%' OR `timestamp` LIKE '%$search_pre_book%' LIMIT $start,$limit;";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
    ?>
<table class="table table-striped table-hover table-bordered table-responsive text-center">
    <thead>
        <tr>
            <th>BOOK ID</th>
            <th>UID</th>
            <th>BAID</th>
            <th>Book Date From</th>
            <th>Book Date To</th>
            <th>Booking Status</th>
            <th>Timestamp</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
                while ($result = mysqli_fetch_array($query)) {
                ?>
        <tr>
            <td><?php echo $result['book_id'] ?></td>
            <td><?php echo $result['uid'] ?></td>
            <td><?php echo $result['baid'] ?></td>
            <td><?php echo $result['book_date_from'] ?></td>
            <td><?php echo $result['book_date_to'] ?></td>
            <td><?php
                            if ($result['cancle'] == 0) {
                                echo "Booked";
                            } else {
                                echo "Cancled";
                            }
                            ?></td>
            <td><?php echo $result['timestamp'] ?></td>
            <td>
                <?php
                            if ($result['del'] == 1) {
                                echo '<span class="text-danger">This Pre-Booking was Deleted.<br> You Want Restore this Pre-Booking? Click on </span><b><a role="button" onClick="Recover(' . $result['book_id'] . ');" class="text-success">Restore&nbsp;</a></b>';
                            } else {
                                echo '<button type="button" onClick="Delete(' . $result['book_id'] . ');" class="btn btn-danger">Delete&nbsp;<i class="fa fa-trash"></i></button>';
                            }
                            ?>
            </td>
        </tr>
        <?php
                }
            }
            ?>
    </tbody>
</table>

<?php
} else {
    echo '<div class="text-center w-100 text-danger"><i>No Records Founds.</i></div>';
}
// ------------------------------------------------------ Search Pre-Books End
    ?>

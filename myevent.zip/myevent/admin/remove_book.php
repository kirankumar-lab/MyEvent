<?php
require("db/connection.php");
if (isset($_POST['book_id'])) {
    $id = $_POST['book_id'];
    $qdl = "update booking set del=1 where book_id=$id";
    mysqli_query($connection, $qdl);
}
if (isset($_POST['rbook_id'])) {
    $id = $_POST['rbook_id'];
    $qdl = "update booking set del=0 where book_id=$id";
    mysqli_query($connection, $qdl);
}

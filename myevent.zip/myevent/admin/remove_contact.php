<?php
require("db/connection.php");
if (isset($_POST['cid'])) {
    $id = $_POST['cid'];
    $qdl = "update contact set del=1 where cid=$id";
    mysqli_query($connection, $qdl);
}
if (isset($_POST['rcid'])) {
    $id = $_POST['rcid'];
    $qdl = "update contact set del=0 where cid=$id";
    mysqli_query($connection, $qdl);
}

<!DOCTYPE html>
<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
?>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | MyEvent</title>
    <link rel="icon" href="img/myevent.png" type="image/x-icon">
    <!--------------------- CSS -------------------->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
    <!-- --------------------------------------------- -->

</head>

<body class="d-flex flex-column h-100">
    <!-- navbar -->
    <?php
    include("navbar.php");
    ?>
    <!--  -->
    <main class="col-md-9 ml-sm-auto col-lg-10 pl-4">
        <section class="jumbotron jumbotron-fluid text-center bg-light mt-3 mr-4 border">
            <div class="container p-5 text-secondary">
                <h1>Add Business Category</h1>
            </div>
        </section>
        <section class="p-1 mr-4 mt-2">
            <form id="add_category" name="add_category" method="POST">
                <div class="p-1 px-5 border-bottom">
                    <label for="category" class="form-label text-capitalize font-weight-bolder">Category Name
                        : </label>
                    <input type="text" name="category" id="category" class="form-control"
                        placeholder="Enter Category Name " required>
                </div>
                <div class="p-1 px-5 border-bottom">
                    <label for="category" class="form-label text-capitalize font-weight-bolder">Category Infornmation
                        Fields
                        : </label>
                    <div class="p-1 px-5 text-right">
                        <button type="button" class="btn btn-success" id="add_field">Add
                            Field&nbsp;&nbsp;<i class="fa fa-plus"></i></button>
                    </div>
                    <div class="p-1 px-5">
                        <label for="ids" class="form-label text-capitalize font-weight-bolder">IDs(Primary key and
                            Forien key)
                            : </label>
                        <input type="text" class="form-control w-25 d-inline" value="id" disabled>
                        <input type="text" class="form-control w-25 d-inline" value="baid" disabled>
                        <table class="table table-responsive">
                            <thead>
                                <tr>
                                    <th>Field Name</th>
                                    <th>Data Type</th>
                                    <th>Data Size</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="category_fields">

                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="p-1 px-5 border-bottom text-center">
                    <button type="reset" name="reset" class="btn btn-outline-danger">Reset</button>
                    <button type="submit" name="submit" class="btn btn-outline-success">Add Category</button>
                </div>
            </form>
        </section>
    </main>
    <?php
    require("db/connection.php");
    if (isset($_POST['submit'])) {
        $catagory = $_POST['category'];
        $field_q = 'CREATE TABLE ' . $catagory . '(`id` INT(11) NOT NULL AUTO_INCREMENT,`baid` INT(11) NOT NULL';
        if (isset($_POST['category_field'])) {
            $catagory_field = $_POST['category_field'];
            $type = $_POST['type'];
            $category_field_size = $_POST['category_field_size'];
            $total_field = count($catagory_field);
            if ($total_field != 0) {
                for ($x = 0; $x < $total_field; $x++) {
                    $field_q = $field_q . ",`" . $catagory_field[$x] . "` " . $type[$x] . "(" . $category_field_size[$x] . ") NOT NULL";
                }
            }
        }
        $table_q = "INSERT INTO `business_category`(`catagory`) VALUES ('$catagory');";
        mysqli_query($connection, $table_q);
        $field_q = $field_q . ",`timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,`del` BOOLEAN NOT NULL DEFAULT FALSE,PRIMARY KEY (`id`),FOREIGN KEY (`baid`) REFERENCES `business_account`(`baid`) ON DELETE RESTRICT ON UPDATE RESTRICT) ENGINE = InnoDB;";
        mysqli_query($connection, $field_q);
    }
    ?>

    <!-- footer -->
    <?php
    include("footer.php");
    ?>
    <!--  -->

    <!--------------- Javascripts Link ------------->
    <script src="js/bootstrap.bundle.min.js"> </script>
    <script src="js/jquery.min.js"></script>

    <script>
    $(document).ready(function() {
        var i = 0;
        var add_field = $('#add_field');
        var category_fields = $('#category_fields');

        add_field.click(function() {
            i++;
            category_fields.append('<tr id="row' + i + '">' +
                '<td>' +
                '<input type="text" name="category_field[]" class="form-control" required>' +
                '</td>' +
                '<td>' +
                '<select name="type[]" id="type" class="form-select" required>' +
                '<option value="VARCHAR">VARCHAR</option><option value="INT">INT</option><option value="tinyint">BOOLEAN</option>' +
                '</select>' +
                '</td>' +
                '<td>' +
                '<input type="text" name="category_field_size[]" value="11" class="form-control" required>' +
                '</td>' +
                '<td>' +
                '<button class="btn btn-danger" onClick="remove(' + i +
                ')" type="button"><i class="fa fa-close"></i></button>' +
                '</td>' +
                '</tr>');
        });
    });

    function remove(id) {
        $('#row' + id).remove();
    }
    </script>
    <!-- ---------------------------------------- -->
</body>

</html>
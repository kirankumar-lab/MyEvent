<!DOCTYPE html>
<html lang="en" class="h-100">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login | Admin Panel</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!-- CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/floating-labels.css">
        <!--  -->
    </head>

    <body class="d-flex flex-column h-100">
        <div class="text-center">
            <img src="img/MyEvent.png" class="w-25" alt="MyEvent Image">
        </div>
        <form class="form-signin" method="post">
            <div class="text-center mb-4">
                <img class="mb-4" src="img/avatar.png" alt="" width="85" height="85">
                <h1 class="h3 mb-3 font-weight-normal">Admin Login</h1>
            </div>
            <div id="invaild" class="text-center">
            </div>
            <div class="form-label-group">
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address"
                    required autofocus>
                <label for="inputEmail">Email address</label>
            </div>

            <div class="form-label-group">
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password"
                    required>
                <label for="inputPassword">Enter Password</label>
            </div>
            <button class="btn btn-lg btn-primary btn-block mb-2" name="submit" type="submit">Login</button>
            <a href="forgot.php" class=" text-primary text-decoration-none">Forgot Password?</a>
        </form>
        <?php
    require("db/connection.php");
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $q = "select * from admin where email='$email' and password='$password'";
        $query = mysqli_query($connection, $q);
        $row = mysqli_num_rows($query);
        if ($row == 1) {
            $row = mysqli_fetch_array($query);
            session_start();
            $_SESSION['aid'] = $row['aid'];
            $_SESSION['name'] = $row['name'];
            session_commit();
            header("Location:dashboard.php");
        } else {
            echo ('<script type="text/javascript">document.getElementById(\'invaild\').innerHTML="<label class=\"alert alert-danger\">Incorrect Email Or Password.</label>";
					</script>');
        }
    }
    ?>


        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!--  -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <!-- ---------------------------------------- -->
    </body>

</html>

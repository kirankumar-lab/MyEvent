<?php
require("db/connection.php");
if (isset($_POST['baid'])) {
    $id = $_POST['baid'];
    $qdl = "update business_account set del=1 where baid=$id";
    mysqli_query($connection, $qdl);
}
if (isset($_POST['rbaid'])) {
    $id = $_POST['rbaid'];
    $qdl = "update business_account set del=0 where baid=$id";
    mysqli_query($connection, $qdl);
}
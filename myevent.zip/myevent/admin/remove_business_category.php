<?php
require("db/connection.php");
if (isset($_POST['bid'])) {
    $id = $_POST['bid'];
    $qdl = "update business_category set del=1 where bid=$id";
    mysqli_query($connection, $qdl);
}
if (isset($_POST['rbid'])) {
    $id = $_POST['rbid'];
    $qdl = "update business_category set del=0 where bid=$id";
    mysqli_query($connection, $qdl);
}
<footer class="footer mt-auto py-3 bg-light text-center">
    <div class="container">
        <span class="text-muted">Copyrights &copy;2020-21. All Rights Resevered by MyEvent.</span>
    </div>
</footer>
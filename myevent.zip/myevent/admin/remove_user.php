<?php
require("db/connection.php");
if (isset($_POST['uid'])) {
    $id = $_POST['uid'];
    $qdl = "update user set del=1 where uid=$id";
    mysqli_query($connection, $qdl);
}
if (isset($_POST['ruid'])) {
    $id = $_POST['ruid'];
    $qdl = "update user set del=0 where uid=$id";
    mysqli_query($connection, $qdl);
}
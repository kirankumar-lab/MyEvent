<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel | MyEvent</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/dashboard.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .dash-text {
            font-size: 15px;
            font-weight: bolder;
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- navbar -->
        <?php
    include("navbar.php");
    ?>
        <!--  -->

        <!-- main -->
        <main class="col-md-9 ml-sm-auto col-lg-10 pl-4">
            <div class="pt-3 pb-2 mb-3 mr-2 border-bottom">
                <div class="float-left">
                    <h1 class="h2">Users</h1>
                </div>
                <div class="clearfix"></div>
            </div>
            <?php
        require("db/totalrecord.php");
        ?>
            <div class="row pb-2 border-bottom mr-2">
                <div class="col-12 col-sm-8 col-lg-4 col-md-6 bg-primary border border-primary text-light m-1 m-auto">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-users"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totalpuser ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total<br />Personal Users</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-8 col-lg-4 col-md-6 bg-primary border border-primary text-light m-1 m-auto">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-users"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totalbuser ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total <br />Business Users</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mr-2 p-3 border-bottom">
                <div class="m-1 p-2 mr-5 bg-light text-dark border">
                    <label class="form-label text-uppercase font-weight-bolder pt-1" for="search_user">Search User :
                    </label>
                    <input type="search" name="search_user" id="search_user" class="form-control"
                        placeholder="Ente UserID, Name, Email, Mobile Number, Address" onkeyup="Search(1)" />
                </div>
            </div>
            <div class="border-bottom border-dark mr-2 pt-2 pb-5 px-2">
                <div id="userdata">

                </div>
            </div>
        </main>
        <!--  -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!--  -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {
            showdata(1);
        });

        function showdata(page) {

            $.ajax({
                url: 'show_users.php',
                type: 'post',
                data: {
                    page: page,
                },

                success: function(data) {
                    $('#userdata').html(data);
                }
            });
        }

        function Delete(uid) {
            var conf = confirm("Are you Sure to Delete User?");
            if (conf == true) {
                $.ajax({
                    url: "remove_user.php",
                    type: 'post',
                    data: {
                        uid: uid
                    },

                    success: function(data, status) {
                        showdata(1);
                    }
                });
            }
        }

        function Recover(ruid) {
            var conf = confirm("Are you Sure to Recover User?");
            if (conf == true) {
                $.ajax({
                    url: "remove_user.php",
                    type: 'post',
                    data: {
                        ruid: ruid
                    },

                    success: function(data, status) {
                        showdata(1);
                    }
                });
            }
        }

        function Search(page) {
            var search_word = $('#search_user').val();
            if (search_word.length == 0) {
                showdata(page);
            } else {
                $.ajax({
                    url: "search.php",
                    type: 'post',
                    data: {
                        search_word: search_word,
                        page: page
                    },

                    success: function(data, status) {
                        $('#userdata').html(data);
                    }
                });
            }
        }
        </script>
        <!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
    </body>

</html>

<?php
require("connection.php");
$q = "select count(uid) as totaluser from user";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$totaluser =  $result['totaluser'];

$q = "select count(uid) as totalpuser from user where type='personal'";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$totalpuser =  $result['totalpuser'];

$q = "select count(uid) as totalbuser from user where type='business'";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$totalbuser =  $result['totalbuser'];

$q = "select count(bid) as totalbcat from business_category";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$totalbcat =  $result['totalbcat'];

$q = "select count(baid) as totalbacc from business_account";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$totalbacc =  $result['totalbacc'];

$q = "select count(fid) as totalfb from feedback";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$totalfb =  $result['totalfb'];

$q = "select count(cid) as penddingc from contact where read_msg=0";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$penddingc =  $result['penddingc'];

$q = "select count(cid) as c from contact";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$c =  $result['c'];

$q = "select count(book_id) as book_id from booking";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$total_booking =  $result['book_id'];

$q = "select count(book_id) as book_id from booking where pre_book=1 AND cancle=0";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$total_pre_book =  $result['book_id'];

$q = "select count(book_id) as book_id from booking where cancle=1";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$total_cancle_booking =  $result['book_id'];

$q = "select count(book_id) as book_id from booking where confirm=1 AND cancle=0";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$total_confirm_booking =  $result['book_id'];

$q = "select count(book_id) as book_id from booking where confirm=0 AND cancle=0 AND pre_book=0";
$query = mysqli_query($connection, $q);
$result = mysqli_fetch_array($query);
$total_request_booking =  $result['book_id'];

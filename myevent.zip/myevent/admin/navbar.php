<!-- ------------Navbar & SideBar--------------- -->
<nav class="navbar navbar-light sticky-top bg-light flex-md-nowrap p-0 shadow">
    <div class="navbar-brand-light col-md-3 col-lg-2 mr-0 px-3">
        <img src="img/MyEvent.png" alt="MyEvent" width="75%"><br />
        <h5 class="text-center">Admin Panel</h5>
    </div>

    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse"
        data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <ul class="navbar-nav px-3 font-weight-bold">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="profile.php"><i class="fa fa-user-circle px-1"></i>Profile</a>
        </li>
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="logout.php"><i class="fa fa-power-off px-1"></i>Logout</a>
        </li>
    </ul>
</nav>

<div class="container-fluid">
    <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-light">
            <div class="position-sticky pt-5">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fa fa-dashboard pr-1"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fa fa-users pr-1"></i>
                            Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="businesscategory.php">
                            <i class="fa fa-th-list pr-1"></i>
                            Business Categories
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="vendors.php">
                            <i class="fa fa-address-card pr-1"></i>
                            Vendors
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="vendors.php">
                            <i class="fa fa-book pr-1"></i>Booking
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="feedback.php">
                            <i class="fa fa-comments pr-1"></i>
                            Feedbacks
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">
                            <i class="fa fa-envelope pr-1"></i>
                            Contacts
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<!-- -----------Navbar & SideBar End------------ -->

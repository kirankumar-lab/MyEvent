<?php
session_start();
$aid = $_SESSION['aid'];
if (empty($aid)) {
    header("Location:./");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel | MyEvent</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/dashboard.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .dash-text {
            font-size: 15px;
            font-weight: bolder;
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- navbar -->
        <?php
    include("navbar.php");
    ?>
        <!--  -->

        <!-- main -->
        <main class="col-md-9 ml-sm-auto col-lg-10 pl-4">
            <div class="pt-3 pb-2 mb-3 mr-2 border-bottom">
                <h1 class="h2">Vendors</h1>
            </div>
            <?php
        require("db/totalrecord.php");
        ?>
            <div class="row pb-2 border-bottom mr-2">
                <div class="col-12 bg-primary border border-primary text-light m-1 m-auto">
                    <div class="row">
                        <div class=" col-sm-6 text-left">
                            <span><i class="fa fa-5x pt-4 fa-address-card"></i></span>
                        </div>
                        <div class="col-sm-6 text-right pt-4">
                            <div>
                                <h3><?php echo $totalbacc ?></h3>
                            </div>
                            <div>
                                <p class="dash-text">Total <br />Vendors</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mr-2 p-3 border-bottom">
                <div class="m-1 p-2 mr-5 bg-light text-dark border">
                    <label class="form-label text-uppercase font-weight-bolder pt-1" for="search_user">Search Vendors :
                    </label>
                    <input type="search" name="search_user" id="search_user" class="form-control"
                        placeholder="Ente Business Account ID, Organization Name, Address, City, Mobile Number, Email, Category"
                        onkeyup="Search()">
                </div>
            </div>
            <div class="border-bottom border-dark mr-2 pt-2 pb-5 px-2">
                <div id="userdata">

                </div>
            </div>
        </main>
        <!--  -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!--  -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {
            showdata(1);
        });

        function showdata(page) {
            $.ajax({
                url: 'show_vendors.php',
                type: 'post',
                data: {
                    page: page
                },

                success: function(data) {
                    $('#userdata').html(data);
                }
            });
        }

        function Delete(baid) {
            var conf = confirm("Are you Sure to Delete Business Account?");
            if (conf == true) {
                $.ajax({
                    url: "remove_vendor.php",
                    type: 'post',
                    data: {
                        baid: baid
                    },

                    success: function(data, status) {
                        showdata(1);
                    }
                });
            }
        }

        function Recover(rbaid) {
            var conf = confirm("Are you Sure to Recover Business Account?");
            if (conf == true) {
                $.ajax({
                    url: "remove_vendor.php",
                    type: 'post',
                    data: {
                        rbaid: rbaid
                    },

                    success: function(data, status) {
                        showdata(1);
                    }
                });
            }
        }

        function Search(page) {
            var search_vendor = $('#search_user').val();
            if (search_vendor.length == 0) {
                showdata(page);
            } else {

                $.ajax({
                    url: "search.php",
                    type: 'post',
                    data: {
                        search_vendor: search_vendor,
                        page: page
                    },

                    success: function(data, status) {
                        $('#userdata').html(data);
                    }
                });
            }
        }
        </script>
        <!-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -->
    </body>

</html>

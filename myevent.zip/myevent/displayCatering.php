<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    header("./venue.php");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Booking</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .title-desc {
            background: linear-gradient(0deg, rgba(255, 90, 90, 0.5)0%, rgba(255, 255, 255, 1)100%);
        }

        .tab-items {
            background: linear-gradient(0deg, rgba(90, 90, 255, 0.5)0%, rgba(255, 255, 255, 1)100%);
        }

        .tab-items:hover {
            background: linear-gradient(0deg, rgba(90, 255, 90, 0.5)0%, rgba(255, 255, 255, 1)100%);
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    session_start();
    if (empty($_SESSION)) {
        include("navbarVisitor.php");
    } else {
        require("session_personal.php");
        include("navbar.php");
    }
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4 w-100">
            <?php
        require("db/connection.php");
        $q = "select * from catering,business_account where catering.del=0 and business_account.baid=catering.baid and business_account.baid=$id";
        $query = mysqli_query($connection, $q);
        if (mysqli_num_rows($query) > 0) {
            $result = mysqli_fetch_array($query);
        ?>

            <div class="text-capitalize text-center text-danger h2 shadow p-1 title-desc">
                <span class="h3"><?php echo $result['name_organization']; ?></span>
            </div>
            <div class="h-100 mt-2">
                <div class="text-capitalize text-left py-3 px-1">
                    <div class="shadow">
                        <ul class="nav nav-tabs nav-justified font-weight-bold" id="myTab" role="tablist">
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="overview(<?php echo $id; ?>)">
                                <a class="nav-link active" id="overview-tab" data-toggle="tab" href="#overview"
                                    role="tab" aria-controls="overview" aria-selected="true">Overview</a>
                            </li>
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="photo(<?php echo $id; ?>)">
                                <a class="nav-link" id="photos-tab" data-toggle="tab" href="#photos" role="tab"
                                    aria-controls="photos" aria-selected="false">Photos</a>
                            </li>
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="contactinfo(<?php echo $id; ?>)">
                                <a class="nav-link" id="contact-info-tab" data-toggle="tab" href="#contact-info"
                                    role="tab" aria-controls="contact-info" aria-selected="false">Contact Info</a>
                            </li>
                        </ul>
                        <div class="tab-content border border-top-0 rounded-bottom" id="myTabContent" style="
    border: 2px solid #dee2e6!important;
    border-top: 0px solid #dee2e6!important;
">

                        </div>
                    </div>
                </div>
                <div class="mt-2 p-2 text-center shadow border rounded">
                    <button class="btn btn-success m-1" onclick="book(<?php echo $result['baid'] ?>)">
                        Book Catering
                    </button>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-secondary m-1" data-toggle="modal" data-target="#modelId">
                        Check Availablity
                    </button>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Check Availability</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <div class="h5 text-capitalize">
                                    <label for="book_date_from" class="form-label">date from:</label>
                                    <input type="date" name="book_date_from" id="book_date_from" class="form-control"
                                        required title="Select Date From">
                                </div>
                                <div class="h5 text-capitalize">
                                    <label for="book_date_to" class="form-label">date to:</label>
                                    <input type="date" name="book_date_to" id="book_date_to" class="form-control"
                                        required title="Select Date to">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary"
                                    onclick="checkAvailable(<?php echo $result['baid'] ?>)">Save</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        $(document).ready(function() {
            overview(<?php echo $id; ?>);
        });

        function overview(id) {
            $.ajax({
                url: "overview_catering.php",
                type: "post",
                data: {
                    id: id
                },

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function photo(id) {
            $.ajax({
                url: "photo_b.php",
                type: "post",
                data: {
                    id: id,
                    src: 'business/catering/'
                },

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function contactinfo(id) {
            $.ajax({
                url: "contact_b.php",
                type: "post",
                data: {
                    id: id
                },

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function book(baid) {
            window.location = "./bookingCatering.php?id=" + baid;
        }

        function checkAvailable(baid) {
            var book_date_from = $("#book_date_from").val();
            var book_date_to = $("#book_date_to").val();
            if (book_date_from.length == 0) {
                $("#book_date_from").focus();
            } else if (book_date_to.length == 0) {
                $("#book_date_to").focus();
            } else {
                $.ajax({
                    url: "check_available.php",
                    type: "post",
                    data: {
                        baid: baid,
                        book_date_from: book_date_from,
                        book_date_to: book_date_to
                    },

                    success: function(data, status) {
                        alert(data);
                    }
                });
            }
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

<?php
require("db/connection.php");
$id = $_POST['id'];
?>
<div class="p-3 m-auto">
    <?php
    $q = "SELECT * FROM wedding_planner WHERE baid=$id AND del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
        $result = mysqli_fetch_array($query);
    ?>
    <div class="row">
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <tr class="py-2 px-1">
                        <td class="text-secondary text-left"><span class="h6">Wedding Planner</span><br>
                            <span>(Cost of agency service)</span>
                        </td>
                        <td class="text-dark h6 text-right"><i
                                class="pr-1 fa fa-inr"></i><?php echo $result['wed_planning']; ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary text-left"><span class="h6">Wedding
                                Manager</span><br>
                            <span>(help with co-ordination)</span>
                        </td>
                        <td class="text-dark h6 text-right"><i
                                class="pr-1 fa fa-inr"></i><?php echo $result['wed_manager']; ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary text-left"><span class="h6">Ready-Made
                                Wedding</span><br>
                            <span>(except venue and outfit)</span>
                        </td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['wed_all']; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-1 mb-2 text-left">
        <span class="h6 text-dark pr-1">Other Services:</span><span
            class="text-warp"><?php echo $result['other_service']; ?></span>
    </div>
    <?php
    }
    ?>

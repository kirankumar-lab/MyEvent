<?php
require("session_personal.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    header("./decorator.php");
}
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Catering</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->

    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4 w-100">
            <?php
        require("db/connection.php");
        $q = "select * from catering,business_account where catering.del=0 and business_account.baid=catering.baid and business_account.baid=$id";
        $query = mysqli_query($connection, $q);
        if (mysqli_num_rows($query) > 0) {
            $result = mysqli_fetch_array($query);
        ?>
            <div class="container-fluid py-3 border-bottom border-dark">
                <span class="h3">Booking Catering</span>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-4 border-bottom p-1 pb-5">
                        <div class="border-0 border-bottom h4 text-center text-capitalize"><span>Catering Details</span>
                        </div>
                        <div class="h6 text-capitalize">catering Name: <span
                                class="text-primary"><?php echo $result['name_organization']; ?></span>
                        </div>
                        <?php
                        if ($result['wedding_menu'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Wedding Menu price(per person): <span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['wedding_menu']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['reception_menu'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Reception Menu price(per person): <span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['reception_menu']; ?></span>
                        </div>
                        <?php
                        }
                        ?>

                        <?php
                        if ($result['coffee_break'] > 0) {
                        ?>
                        <div class="h6 text-capitalize">Coffee break(per person): <span class="text-primary"><i
                                    class="fa fa-inr pr-1"></i><?php echo $result['coffee_break']; ?></span>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                    <div class="col-12 col-md-8 border-bottom p-1 pb-5">
                        <form method="post">
                            <div class="border-0 border-bottom h4 text-center text-capitalize"><span>Fill Booking
                                    Details</span>
                            </div>

                            <?php
                            if ($result['wedding_menu'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="checkbox" name="wedding_menu[]" class="form-check-input"
                                    <?php echo $disabled; ?> value="1" id="wedding_menu" onchange="wedding()">
                                <label for="wedding_menu" class="form-label">Wedding Menu</label>
                                <br>
                                <label for="no_person_wedding" class="form-label">No of Person for wedding menu:</label>
                                <input type="number" name="no_person_wedding" class="form-control"
                                    id="no_person_wedding" placeholder="Enter No of person for wedding menu"
                                    <?php echo $disabled; ?>>
                            </div>

                            <?php
                            if ($result['reception_menu'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>
                            <div class="text-capitalize h6 py-3">
                                <input type="checkbox" name="reception_menu[]" class="form-check-input"
                                    <?php echo $disabled; ?> value="1" id="reception_menu" onchange="reception()">
                                <label for="reception_menu" class="form-label">Reception Menu</label>
                                <br>
                                <label for="no_person_reception" class="form-label">No of Person for reception
                                    menu:</label>
                                <input type="number" name="no_person_reception" class="form-control"
                                    id="no_person_reception" placeholder="Enter No of person for reception menu"
                                    <?php echo $disabled; ?>>
                            </div>

                            <?php
                            if ($result['coffee_break'] < 0) {
                                $disabled = "disabled=disabled";
                            } else {
                                $disabled = "";
                            }
                            ?>

                            <div class="text-capitalize h6 py-3">
                                <input type="checkbox" name="coffee_break[]" class="form-check-input"
                                    <?php echo $disabled; ?> value="1" id="coffee_break" onchange="coffee()">
                                <label for="coffee_break" class="form-label">Coffee Break</label>
                                <br>
                                <label for="no_coffee_break" class="form-label">No of Coffee Break(in 1 day):</label>
                                <input type="number" name="no_coffee_break" class="form-control" id="no_coffee_break"
                                    placeholder="Enter No of coffee break" <?php echo $disabled; ?>>
                            </div>

                            <div class="h5 text-capitalize">
                                <label for="book_date_from" class="form-label">date from:</label>
                                <input type="date" name="book_date_from" id="book_date_from" class="form-control"
                                    required title="Select Date From">
                            </div>
                            <div class="h5 text-capitalize">
                                <label for="book_date_to" class="form-label">date to:</label>
                                <input type="date" name="book_date_to" id="book_date_to" class="form-control" required
                                    title="Select Date to">
                            </div>
                            <div class="text-capitalize">
                                <label for="payment_type" class="form-label">Payment Type:</label>
                                <select name="payment_type" id="payment_type" class="form-select"
                                    onchange="change_pay_type()">
                                    <option value="online">Online</option>
                                    <option value="offline">Offline</option>
                                </select>
                            </div>
                            <div class="text-capitalize">
                                <span class="text-danger justify-content-around p-2" id="off_dl"><sup>*</sup>You Pay
                                    money at catering office and confirm your booking by vendor in 1 hours. after 1
                                    hours expired
                                    your booking request.</span>
                                <br>
                                <button class="btn btn-success" type="submit" name="submit" id="submit">Book the
                                    Catering</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        </main>
        <!-- ---- -->

        <!-- Booking Process -->
        <?php
    if (isset($_POST['submit'])) {
        $uid = $_SESSION['uid'];
        $baid = $id;
        $book_date_from = $_POST['book_date_from'];
        $book_date_from = date("Y-m-d", strtotime($book_date_from));
        $book_date_to = $_POST['book_date_to'];
        $book_date_to = date("Y-m-d", strtotime($book_date_to));
        $payment_type = $_POST['payment_type'];
        if ($payment_type == "online") {
            $confirm = 1;
        } else {
            $confirm = 0;
        }

        if (isset($_POST['wedding_menu'])) {
            foreach ($_POST['wedding_menu'] as $dc) {
                $wedding_menu = $dc;
                $no_person_wedding = $_POST['no_person_wedding'];
            }
        } else {
            $wedding_menu = 0;
            $no_person_wedding = 0;
        }

        if (isset($_POST['reception_menu'])) {
            foreach ($_POST['reception_menu'] as $dc) {
                $reception_menu = $dc;
                $no_person_reception = $_POST['no_person_reception'];
            }
        } else {
            $reception_menu = 0;
            $no_person_reception = 0;
        }

        if (isset($_POST['coffee_break'])) {
            foreach ($_POST['coffee_break'] as $dc) {
                $coffee_break = $dc;
                $no_coffee_break = $_POST['no_coffee_break'];
            }
        } else {
            $coffee_break = 0;
            $no_coffee_break = 0;
        }


        $days = strtotime($book_date_to) / (60 * 60 * 24) - strtotime($book_date_from) / (60 * 60 * 24) + 1;

        $wedding_amount = $no_person_wedding * $result['wedding_menu'];
        $reception_amount = $no_person_reception * $result['reception_menu'];
        $coffee_beak_amount = $no_coffee_break * $result['coffee_break'];

        $amount = $wedding_amount * $days + $reception_amount * $days + $coffee_beak_amount * $days;

        $currentdate = date('Y-m-d');
        if ($book_date_to >= $book_date_from) {
            $q = "SELECT `book_date_from`,`book_date_to` FROM `booking` WHERE `baid`=$baid AND `cancle`=0 AND '$book_date_from'>=CURRENT_DATE AND '$book_date_to'>=CURRENT_DATE AND `book_date_from` BETWEEN '$book_date_from' AND '$book_date_to' AND `book_date_to` BETWEEN '$book_date_from' AND '$book_date_to'";
            $run = mysqli_query($connection, $q);
            if (mysqli_num_rows($run) > 0) {
                echo '<script>alert("Already Booked By Another User on this date.");</script>';
            } else {
                if ($book_date_from >= $currentdate) {
                    $q = "INSERT INTO `booking`(`uid`, `baid`, `book_date_from`, `book_date_to`, `amount`, `payment_type`, `confirm`) VALUES ($uid,$baid,'$book_date_from','$book_date_to',$amount,'$payment_type',$confirm)";
                    $r = mysqli_query($connection, $q);
                    if ($r) {
                        $q = "SELECT `book_id` FROM `booking` WHERE `uid`=$uid AND `baid`=$baid ORDER BY `book_id` DESC LIMIT 1";
                        $r = mysqli_fetch_array(mysqli_query($connection, $q));
                        $book_id = $r['book_id'];

                        $q = "INSERT INTO `booking_catering`(`baid`, `book_id`, `wedding_menu`, `reception_menu`, `coffee_break`, `no_person_wedding`, `no_person_reception`, `no_coffee_break`, `total_amount`) VALUES ($baid,$book_id,$wedding_menu,$reception_menu,$coffee_break,$no_person_wedding,$no_person_reception,$no_coffee_break,$amount)";
                        mysqli_query($connection, $q);

                        echo '<script>window.location="./booking.php";</script>';
                    }
                } else {
                    echo '<script>alert("Select Vaild Date");</script>';
                }
            }
        } else {
            echo '<script>alert("Select Vaild Date");</script>';
        }
    }
    ?>
        <!-- Booking Process END-->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        $(document).ready(function() {
            $('#off_dl').hide();
            wedding();
            reception();
            coffee();
            change_pay_type();
        });

        function wedding() {
            if (document.getElementById('wedding_menu').checked) {
                $("#no_person_wedding").removeAttr('disabled');
            } else {
                $("#no_person_wedding").attr('disabled', 'disabled');
            }
        }

        function reception() {
            if (document.getElementById('reception_menu').checked) {
                $("#no_person_reception").removeAttr('disabled');
            } else {
                $("#no_person_reception").attr('disabled', 'disabled');
            }
        }

        function coffee() {
            if (document.getElementById('coffee_break').checked) {
                $("#no_coffee_break").removeAttr('disabled');
            } else {
                $("#no_coffee_break").attr('disabled', 'disabled');
            }
        }

        function change_pay_type() {
            var pay = $('#payment_type').val();
            if (pay === "offline") {
                $('#submit').html("Booking request to the Catering");
                $('#off_dl').show();
            } else {
                $('#submit').html("Book the Catering");
                $('#off_dl').hide();
            }
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

<?php
require("session_personal.php");
require("db/connection.php");
if (isset($_POST['book_id'])) {
    $book_id = $_POST['book_id'];
    $q = "UPDATE `booking` SET `cancle`=1 WHERE `book_id`=$book_id";
    mysqli_query($connection, $q);
}

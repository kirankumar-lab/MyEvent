    <?php
    require("db/connection.php");

    $q = "select count(id) as venues from venue where del=0";
    $query = mysqli_query($connection, $q);
    $venues = mysqli_fetch_array($query);

    $q = "select count(id) as catering from catering where del=0";
    $query = mysqli_query($connection, $q);
    $catering = mysqli_fetch_array($query);

    $q = "select count(id) as decorator from decorator where del=0";
    $query = mysqli_query($connection, $q);
    $decorator = mysqli_fetch_array($query);

    $q = "select count(id) as photographer from photographer where del=0";
    $query = mysqli_query($connection, $q);
    $photographer = mysqli_fetch_array($query);

    $q = "select count(id) as wedding_planner from wedding_planner where del=0";
    $query = mysqli_query($connection, $q);
    $wedding_planner = mysqli_fetch_array($query);

    $vendors = $venues['venues'] + $catering['catering'] + $decorator['decorator'] + $photographer['photographer'] + $wedding_planner['wedding_planner'];
    ?>

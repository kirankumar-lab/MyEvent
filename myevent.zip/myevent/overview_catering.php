<?php
require("db/connection.php");
$id = $_POST['id'];
?>
<div class="p-3 m-auto">
    <?php
    $q = "SELECT * FROM catering WHERE baid=$id AND del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
        $result = mysqli_fetch_array($query);
    ?>
    <div class="row">
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Wedding Menu(per Person)</td>
                        <td class="text-dark h6 text-right"><?php echo $result['wedding_menu']; ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Reception Menu(per Person)</td>
                        <td class="text-dark h6 text-right"><?php echo $result['reception_menu']; ?>
                        </td>
                    </tr>
                    <tr class="py-2 px-1" id="deco_price">
                        <td class="text-secondary h6 text-left">Coffee Break(per Person)</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['coffee_break']; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-1 mb-2 text-left">
        <span class="h6 text-dark pr-1">Other Services:</span><span
            class="text-warp"><?php echo $result['other_service']; ?></span>
    </div>
    <?php
    }
    ?>

<?php
require("db/connection.php");
$id = $_POST['id'];
$src = $_POST['src'];
?>
<div class="card-group m-auto p-2">
    <!-- Get Images -->
    <?php
    $q = "select * from image where baid=$id and del=0";
    $query = mysqli_query($connection, $q);
    while ($result = mysqli_fetch_array($query)) {
    ?>
    <div class="p-1">
        <div class="card" style="width:10rem; height:100%;">
            <img class="card-img" style="height:100%;" src="<?php echo $src . $result['src']; ?>" alt="Card image">
        </div>
    </div>
    <?php
    }
    ?>
    <!-- ---------- -->
</div>

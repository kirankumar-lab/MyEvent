<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <style>
        .list {
            box-shadow: inset 0px 0px 7px rgba(0, 0, 0, 0.4);
        }

        .list:hover {
            box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.6);
        }

        </style>
        <!-- --------------------------------------------- -->

    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbarVisitor.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="m-sm-auto px-md-4">
            <div class="w-100" style="margin-top: -30%;">
                <img src="img/homeimg.jpg" class="w-100 h-75" alt="MyEvent Image">
            </div>
            <div class="container text-center">
                <img src="img/MyEvent.png" class="w-25" alt="MyEvent Image">
                <div class="border-top">
                    <div class="float-left h-100 pt-3 pr-3 p-2" style="width: 15%;">
                        <div class="h-100">
                            <ul class="text-left list-group list-unstyled font-weight-bolder">
                                <li class="list-group-item border-0 border-bottom text-center p-2 my-1">
                                    <span>User Services</span>
                                </li>
                                <a href="catering.php" class="text-decoration-none">
                                    <li class="list-group-item-primary p-2 my-1 list">
                                        <span>Catering</span>
                                        <i class="fa fa-angle-right float-right p-1"></i>
                                    </li>
                                </a>
                                <a href="decorator.php" class="text-decoration-none">
                                    <li class="list-group-item-success p-2 my-1 list">
                                        Decorators
                                        <i class="fa fa-angle-right float-right p-1"></i>
                                    </li>
                                </a>
                                <a href="photographer.php" class="text-decoration-none">
                                    <li class="list-group-item-secondary p-2 my-1 list">
                                        Photographers
                                        <i class="fa fa-angle-right float-right p-1"></i>
                                    </li>
                                </a>
                                <a href="venue.php" class="text-decoration-none">
                                    <li class="list-group-item-danger p-2 my-1 list">
                                        Venues
                                        <i class="fa fa-angle-right float-right p-1"></i>
                                    </li>
                                </a>
                                <a href="wedding_planner.php" class="text-decoration-none">
                                    <li class="list-group-item-info p-2 my-1 list">
                                        Wedding Planner
                                        <i class="fa fa-angle-right float-right p-1"></i>
                                    </li>
                                </a>
                            </ul>
                        </div>
                    </div>
                    <div class="float-right h-100 p-2" style="width: 85%;">
                        <div class="row text-secondary">
                            <div class="col-lg-6 col-12 mt-lg-3">
                                <p style="text-align: justify;">Wedding - a ceremony where two people
                                    are united forever; it is the
                                    most special day of any human in their whole life. It is the day when dreams come
                                    true. It is the day where the bride and groom become husband and wife. Such a
                                    special day requires special arrangements with extra special decorations. And such
                                    arrangements can only be found on MyEvent.</p>
                            </div>
                            <div class="col-lg-6 col-12 mt-lg-3">
                                <p style="text-align: justify;">Everything you need for a wedding in Ahmedabad is here -
                                    photographers,
                                    videographers, decorators, wedding planners, venues. Everything that you
                                    need to make your wedding day memorable forever can be found only in one place. All
                                    your
                                    desires
                                    and dreams for your special day come true with the help of our portal.</p>
                            </div>
                        </div>
                        <!-- Get Vendors -->
                        <?php
                    require("getVendor.php");
                    ?>
                        <!-- ----------- -->

                        <div class="text-left">
                            <span class="pr-1 font-weight-bolder"><?php echo $vendors; ?></span>Vendors in
                            MyEvent
                        </div>
                        <div class="row text-secondary mt-lg-3">
                            <div class="col-lg-4 col-12 p-lg-2">
                                <ul class="text-left">
                                    <li class="list-unstyled"><span
                                            class="pr-1 font-weight-bolder text-dark"><?php echo $venues['venues']; ?></span>Venues
                                    </li>
                                    <li class="list-unstyled"><span
                                            class="pr-1 font-weight-bolder text-dark"><?php echo $photographer['photographer']; ?></span>Photographers
                                    </li>
                                    <li class="list-unstyled"><span
                                            class="pr-1 font-weight-bolder text-dark"><?php echo $wedding_planner['wedding_planner']; ?></span>Wedding
                                        Planners</li>
                                    <li class="list-unstyled"><span
                                            class="pr-1 font-weight-bolder text-dark"><?php echo $catering['catering']; ?></span>Catering
                                    </li>
                                    <li class="list-unstyled"><span
                                            class="pr-1 font-weight-bolder text-dark"><?php echo $decorator['decorator']; ?></span>Decorators
                                    </li>
                                </ul>
                            </div>
                            <div class="col-lg-4 col-12 p-lg-2">
                            </div>

                            <div class="col-lg-4 col-12 p-lg-2 mb-1">
                                <span class="text-dark pl-lg-3 h5">Are You Vendor?</span>
                                <div class="text-dark p-5"
                                    style="border-radius: 5px; background-color:#f5f5f5; text-align: justify;">
                                    Do you provide services to brides and grooms? <i>MyEvent</i> can give you plenty of
                                    opportunities!
                                    <br>
                                    <br>
                                    <a href="registration.php" class="text-decoration-none">
                                        <button class="btn btn-success">Sign
                                            Up</button></a>
                                </div>
                            </div>

                            <div style="border-radius: 5px; background-color:#f5f5f5;">
                                <div class="h6 text-center">

                                </div>
                                <div class="text-center">

                                </div>
                                <div class="text-center">

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>

        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>

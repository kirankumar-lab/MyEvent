<?php
require("db/connection.php");
$id = $_POST['id'];
?>
<div class="p-3 m-auto">
    <?php
    $q = "SELECT * FROM venue WHERE baid=$id AND del=0";
    $query = mysqli_query($connection, $q);
    if (mysqli_num_rows($query) > 0) {
        $result = mysqli_fetch_array($query);
    ?>
    <div class="row">
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Venue Type</td>
                        <td class="text-dark h6 text-right"><?php echo $result['type']; ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Venue People Capacity</td>
                        <td class="text-dark h6 text-right"><?php echo $result['capacity']; ?></td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Decoration</td>
                        <td class="text-dark h6 text-right"><?php echo $result['deco_policy']; ?></td>
                    </tr>
                    <?php
                        if ($result['deco_policy'] != "other allowed") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Decoration Price</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['deco_price']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                    <tr class="py-2 px-1" id="deco_price">
                        <td class="text-secondary h6 text-left">Rent Per Day</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['rent']; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-6 col-12">
            <table class="table bg-light mt-2 py-2">
                <tbody>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Food Policy</td>
                        <td class="text-dark h6 text-right"><?php echo $result['food_policy']; ?></td>
                    </tr>
                    <?php
                        if ($result['food_policy'] != "other allowed") {
                        ?>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Price per Plate,veg</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['veg_price']; ?>
                        </td>
                    </tr>
                    <tr class="py-2 px-1">
                        <td class="text-secondary h6 text-left">Price per Plate,non-veg</td>
                        <td class="text-dark h6 text-right">
                            <i class="pr-1 fa fa-inr"></i><?php echo $result['non_veg_price']; ?>
                        </td>
                    </tr>
                    <?php
                        }
                        ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-1 mb-2 text-left">
        <table class="mauto py-2 table-borderless text-dark h5 table">
            <tbody>
                <tr class="py-2">
                    <?php
                        if ($result['firecrackers'] == 0) {
                        ?>
                    <td class="text-decoration-line-through text-secondary">
                        <span><i class="fa fa-close text-danger">&nbsp;</i></span>
                        <?php
                        } else {
                            ?>
                    <td>
                        <span><i class="fa fa-check text-success">&nbsp;</i></span>
                        <?php
                        }
                            ?>
                        Firecrackers Allowed
                    </td>
                    <?php
                            if ($result['private_parking'] == 0) {
                            ?>
                    <td class="text-decoration-line-through text-secondary">
                        <span><i class="fa fa-close text-danger">&nbsp;</i></span>
                        <?php
                            } else {
                                ?>
                    <td>
                        <span><i class="fa fa-check text-success">&nbsp;</i></span>
                        <?php
                            }
                                ?>
                        Private Parking Available
                    </td>
                    <?php
                                if ($result['alcohol'] == 0) {
                                ?>
                    <td class="text-decoration-line-through text-secondary">
                        <span><i class="fa fa-close text-danger">&nbsp;</i></span>
                        <?php
                                } else {
                                    ?>
                    <td>
                        <span><i class="fa fa-check text-success">&nbsp;</i></span>
                        <?php
                                }
                                    ?>
                        Alcohol Allowed
                    </td>
                </tr>

                <tr class="text-left h6">
                    <td>Payment Accepted Using:</td>
                </tr>
                <tr class="py-2 text-left h6">
                    <?php
                        if ($result['cash'] == 1) {
                        ?>
                    <td><span><i class="fa fa-check text-success">&nbsp;</i></span>Chash</td>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['credit_debit_card'] == 1) {
                        ?>
                    <td><span><i class="fa fa-check text-success">&nbsp;</i></span>Credit Or Debit Card</td>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['bank_transfer'] == 1) {
                        ?>
                    <td><span><i class="fa fa-check text-success">&nbsp;</i></span>Net Banking</td>
                    <?php
                        }
                        ?>
                    <?php
                        if ($result['cheque'] == 1) {
                        ?>
                    <td><span><i class="fa fa-check text-success">&nbsp;</i></span>Cheque</td>
                    <?php
                        }
                        ?>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="mt-1 mb-2 text-left">
        <span class="h6 text-dark pr-1">Other Specification:</span><span
            class="text-warp"><?php echo $result['other_specification']; ?></span>
    </div>
    <?php
    }
    ?>

<?php
require("db/connection.php");
$q = "select * from photographer,business_account join user on user.uid=business_account.uid  where photographer.del=0 and business_account.del=0 and business_account.baid=photographer.baid and user.del=0";
$query = mysqli_query($connection, $q);
if (mysqli_num_rows($query) > 0) {
?>
<div class="container-fluid py-3 border-bottom border-dark">
    <span class="h3">Photographer</span>
</div>
<?php
    while ($result = mysqli_fetch_array($query)) {

    ?>
<div class="text-center mb-4 m-3 text-capitalize order p-3 venue row">
    <div class="p-1 text-left border-bottom mb-1">
        <h4 class="text-primary pb-2"><?php echo $result['name_organization']; ?></h4>
        <span><i class="fa fa-map-marker text-secondary pr-1"></i></span><label
            class="text-primary text-wrap"><?php echo $result['address']; ?>,&nbsp;<?php echo $result['city']; ?>.</label>
    </div>
    <div class="col-md-3 col-12">
        <!-- Slidesshow -->
        <div id="slder" class="carousel slide" data-rid="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/MyEvent.png" alt="not loaded" class="venue-img">
                </div>
                <?php
                        $baid = $result['baid'];
                        $qi = "select * from image where baid=$baid and del=0";
                        $queryi = mysqli_query($connection, $qi);
                        while ($resulti = mysqli_fetch_array($queryi)) {
                        ?>
                <div class="carousel-item">
                    <img src="business/photographer/<?php echo $resulti['src']; ?>" alt="not loaded" class="venue-img">
                </div>
                <?php
                        }
                        ?>
            </div>
            <!-- Slidesshow Img Ends -->
            <!-- Slide Navigation Buttons -->

            <a href="#slder" class="carousel-control-prev chg-img" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>

            <a href="#slder" class="carousel-control-next chg-img" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
            <!-- Slide Navigation Buttons Ends -->
        </div>
        <!-- Slidesshow Ends -->
    </div>
    <div class="col-md-9 col-12">
        <div class="row">
            <div class="col-md-6 col-12">
                <table class="table bg-light mt-2 py-2">
                    <tbody>
                        <?php
                                if ($result['photo_day'] != "0") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Photography 1 Day Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_day']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                        <?php
                                if ($result['photo_2_day'] != "0") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Photography 2 Day Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_2_day']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                        <?php
                                if ($result['photo_3_day'] != "0") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Photography 3 Day Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_3_day']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6 col-12">
                <table class="table bg-light mt-2 py-2">
                    <tbody>
                        <?php
                                if ($result['photo_vedio_day'] != "0") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Photography + Vedio Day Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_vedio_day']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                        <?php
                                if ($result['photo_vedio_2_day'] != "0") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Photography + Vedio 2 Day Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_vedio_2_day']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                        <?php
                                if ($result['photo_vedio_3_day'] != "0") {
                                ?>
                        <tr class="py-2 px-1">
                            <td class="text-secondary h6 text-left">Photography + Vedio 3 Day Price</td>
                            <td class="text-dark h6 text-right">
                                <i class="pr-1 fa fa-inr"></i><?php echo $result['photo_vedio_3_day']; ?>
                            </td>
                        </tr>
                        <?php
                                }
                                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
                if ($result['album'] != "0") {
                ?>
        <div class="mt-1 mb-2 text-left">
            <span class="h6 text-dark pr-1">Album Price Additionallay:</span><span
                class="text-warp"><?php echo $result['album']; ?></span>
        </div>
        <?php
                }
                ?>
        <div class="mt-1 mb-2 text-left">
            <span class="h6 text-dark pr-1">Other Services:</span><span
                class="text-warp"><?php echo $result['other_service']; ?></span>
        </div>
        <div class="mt-2">
            <button class="btn btn-success m-1" onclick="book(<?php echo $result['baid'] ?>)">
                Book Photographer
            </button>

            <button class="btn btn-info m-1" onclick="display(<?php echo $result['baid'] ?>)">
                View Details
            </button>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-secondary m-1" data-toggle="modal" data-target="#modelId">
                Check Availablity
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Check Availability</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="h5 text-capitalize">
                            <label for="book_date_from" class="form-label">date from:</label>
                            <input type="date" name="book_date_from" id="book_date_from" class="form-control" required
                                title="Select Date From">
                        </div>
                        <div class="h5 text-capitalize">
                            <label for="book_date_to" class="form-label">date to:</label>
                            <input type="date" name="book_date_to" id="book_date_to" class="form-control" required
                                title="Select Date to">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary"
                            onclick="checkAvailable(<?php echo $result['baid'] ?>)">Save</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php
    }
} else {
    echo '<p class="p-5 text-center text-danger"> No Any Photographer Found.</p>';
}
?>

<footer class="footer mt-auto py-1 bg-light border-top">
    <div class="container-fluid row">
        <div class="col-lg-6 col-12 text-left">
            <span class="text-muted">Copyrights &copy;2020-21. All Rights Resevered by MyEvent.</span>
        </div>
        <div class="col-lg-6 col-12 text-right">
            <span class="text-muted"><b><i class="fa fa-envelope pr-1"></i>Email:<a href="contact.php"
                        class="text-decoration-none pl-1">admin@myevent.com</a></b></span>
        </div>
    </div>
</footer>

<?php
require("db/connection.php");
$id = $_POST['id'];
$q = "SELECT * FROM `business_account`,`user` WHERE `baid`=$id AND `user`.`del`=0";
$query = mysqli_query($connection, $q);
if (mysqli_num_rows($query)) {
    $result = mysqli_fetch_array($query);
?>
<div class="p-3">
    <span class="h6">Contact Info:</span>
    <table class="table table-borderless h6">
        <tr>
            <td class="text-right">Organization Name:</td>
            <td class="text-left"><?php echo $result['name_organization']; ?></td>
        </tr>
        <tr>
            <td class="text-right">Address:</td>
            <td class="text-left"><?php echo $result['address']; ?></td>
        </tr>
        <tr>
            <td class="text-right">City:</td>
            <td class="text-left"><?php echo $result['city']; ?></td>
        </tr>
        <tr>
            <td class="text-right">E-mail:</td>
            <td class="text-left text-lowercase"><a
                    href="mailto:<?php echo $result['email']; ?>"><?php echo $result['email']; ?></a></td>
        </tr>
        <tr>
            <td class="text-right">Mobile Number:</td>
            <td class="text-left"><?php echo $result['mono']; ?></td>
        </tr>
    </table>
</div>
<?php
}
?>

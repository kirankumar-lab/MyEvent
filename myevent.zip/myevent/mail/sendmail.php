<?php
if(isset($_POST['submit']))
{
	$email = $_POST['email'];
$subject = "Regarding The Table Reservation";
$body = '<p>Congratulations!</p>';
$body .= '<p>Table is Confirm</p>';

// Enter Your Email Address Here To Receive Email
$email_to = $email;

$email_from = "kiranwebsite63410@gmail.com"; // Enter Sender Email
$sender_name = "Hall Booking"; // Enter Sender Name

require("class.phpmailer.php");
$mail = new PHPMailer(true);
$mail->IsSMTP();
$mail->Host = 'smtp.gmail.com;'; // Enter Your Host/Mail Server
$mail->SMTPAuth = true;
$mail->Username = "kiranwebsite63410@gmail.com"; // Enter Sender Email
$mail->Password = "kiran63410";

//If SMTP requires TLS encryption then remove comment from below
$mail->SMTPSecure = "tls";
$mail->Port = 587;
$mail->IsHTML(true);

$mail->From = $email_from;
$mail->FromName = $sender_name;
$mail->Sender = $email_from; // indicates ReturnPath header
$mail->AddReplyTo($email_from, "No Reply"); // indicates ReplyTo headers
$mail->Subject = $subject;
$mail->Body = $body;
$mail->AddAddress($email_to);

if (!$mail->Send()) {
	echo "Mailer Error: " . $mail->ErrorInfo;
} else {
	echo "Sent Successfully !!";
}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Testing</title>
</head>

<body>
<form method="post">
	<input type="email" name="email"/>
	<input type="submit" name="submit" value="Send" />
</form>
</body>

</html>
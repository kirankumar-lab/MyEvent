<?php
require("db/connection.php");
if (isset($_POST['book_date_from']) || isset($_POST['book_date_to']) || isset($_POST['baid'])) {
    $baid = $_POST['baid'];
    $book_date_from = $_POST['book_date_from'];
    $book_date_from = date("Y-m-d", strtotime($book_date_from));
    $book_date_to = $_POST['book_date_to'];
    $book_date_to = date("Y-m-d", strtotime($book_date_to));
    $currentdate = date('Y-m-d');
    if ($book_date_from >= $currentdate) {
        if ($book_date_to >= $book_date_from) {
            $q = "SELECT `book_date_from`,`book_date_to` FROM `booking` WHERE `baid`=$baid AND `cancle`=0 AND '$book_date_from'>=CURRENT_DATE AND '$book_date_to'>=CURRENT_DATE AND `book_date_from` BETWEEN '$book_date_from' AND '$book_date_to' AND `book_date_to` BETWEEN '$book_date_from' AND '$book_date_to'";
            $run = mysqli_query($connection, $q);
            if (mysqli_num_rows($run) > 0) {
                echo 'Already Booked By Another User on this date.';
            } else {
                echo 'Available on this date.';
            }
        } else {
            echo 'Select Vaild Date';
        }
    } else {
        echo 'Select Vaild Date';
    }
}

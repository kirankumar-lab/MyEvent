<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyEvent | Forgot Password</title>
    <!-- CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/floating-labels.css">
    <link rel="icon" href="img/myevent.png" type="image/x-icon">
    <!--  -->
</head>

<body class="d-flex flex-column h-100">

    <form class="form-signin" method="post">
        <div class="text-center mb-4">
            <h1 class="h3 mb-3 font-weight-normal">Forgot Password</h1>
        </div>
        <div id="invaild" class="text-center">
        </div>
        <div class="form-label-group">
            <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required
                autofocus>
            <label for="inputEmail">Email address</label>
        </div>

        <button class="btn btn-lg btn-primary btn-block mb-2" name="submit" type="submit">Forgot Password</button>
    </form>

    <!-- Data Script -->
    <?php
	if (isset($_POST['submit'])) {

		$email = $_POST['email'];
		require("db/connection.php");
		$cs = mysqli_query($connection, "select * from user where email='$email'");
		$row = mysqli_fetch_array($cs);

		if ($row['email'] != $email) {
			echo ('<script type="text/javascript">document.getElementById(\'invaild\').innerHTML="<label class=\"alert alert-danger\">Incorrect Email Address or This Emial Address Not Registrated.</label>";
					</script>');
		} else {
			$subject = "MyEvent Account Forgot Password";

			$password = $row['password'];



			$body = "Your password is : '$password'.";

			// Enter Your Email Address Here To Receive Email
			$email_to = $email;

			$email_from = "kiranwebsite63410@gmail.com"; // Enter Sender Email

			$sender_name = "MyEvent"; // Enter Sender Name

			require("mail/class.phpmailer.php");

			$mail = new PHPMailer(true);

			$mail->IsSMTP();

			$mail->Host = 'smtp.gmail.com;'; // Enter Your Host/Mail Server

			$mail->SMTPAuth = true;

			$mail->Username = "kiranwebsite63410@gmail.com"; // Enter Sender Email

			$mail->Password = "kiran63410";

			//If SMTP requires TLS encryption then remove comment from below
			$mail->SMTPSecure = "tls";

			$mail->Port = 587;

			$mail->IsHTML(true);

			$mail->From = $email_from;

			$mail->FromName = $sender_name;

			$mail->Sender = $email_from; // indicates ReturnPath header

			$mail->AddReplyTo($email_from, "No Reply"); // indicates ReplyTo headers

			$mail->Subject = $subject;

			$mail->Body = $body;

			$mail->AddAddress($email_to);

			if (!$mail->Send()) {
				echo "Mailer Error: " . $mail->ErrorInfo;
			} else {
				echo ('<script type="text/javascript">document.getElementById(\'invaild\').innerHTML="<label class=\"alert alert-success\">Forgot Successfully. Please check your Email.<a href=\"index.php\" >Login</a></label>";
					</script>');
			}
		}
	}
	?>
    <!-- Data Script Ends -->

    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-light text-center">
        <div class="container">
            <span class="text-muted">Copyrights &copy;2020-21. All Rights Resevered by MyEvent.</span>
        </div>
    </footer>
    <!--  -->
    <!--------------- Javascripts Link ------------->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <!-- ---------------------------------------- -->
</body>

</html>
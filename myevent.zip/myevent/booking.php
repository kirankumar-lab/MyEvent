<?php
require("session_personal.php");
?>
<!doctype html>
<html lang="en" class="h-100">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MyEvent | Booking</title>
        <link rel="icon" href="img/myevent.png" type="image/x-icon">
        <!--------------------- CSS -------------------->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- --------------------------------------------- -->
        <style>
        .title-desc {
            background: linear-gradient(0deg, rgba(255, 90, 90, 0.5)0%, rgba(255, 255, 255, 1)100%);
        }

        .tab-items {
            background: linear-gradient(0deg, rgba(90, 90, 255, 0.5)0%, rgba(255, 255, 255, 1)100%);
        }

        .tab-items:hover {
            background: linear-gradient(0deg, rgba(90, 255, 90, 0.5)0%, rgba(255, 255, 255, 1)100%);
        }

        </style>
    </head>

    <body class="d-flex flex-column h-100">

        <!-- ------------Navbar & SideBar--------------- -->
        <?php
    include("navbar.php");
    ?>
        <!-- -----------Navbar & SideBar End------------ -->

        <!-- Main -->
        <main class="px-md-4 w-100">
            <div class="h-100 mt-2">
                <div class="text-capitalize text-left py-3 px-1">
                    <div class="shadow">
                        <ul class="nav nav-tabs nav-justified font-weight-bold" id="myTab" role="tablist">
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="venue()">
                                <a class="nav-link active" id="venue-tab" data-toggle="tab" href="#venue" role="tab"
                                    aria-controls="venue" aria-selected="true">Venue</a>
                            </li>
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="photographer()">
                                <a class="nav-link" id="photographer-tab" data-toggle="tab" href="#photographer"
                                    role="tab" aria-controls="photographer" aria-selected="false">Photographer</a>
                            </li>
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="decorator()">
                                <a class="nav-link" id="decorator-tab" data-toggle="tab" href="#decorator" role="tab"
                                    aria-controls="decorator" aria-selected="false">Decorator</a>
                            </li>
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="catering()">
                                <a class="nav-link" id="catering-tab" data-toggle="tab" href="#catering" role="tab"
                                    aria-controls="catering" aria-selected="false">Catering</a>
                            </li>
                            <li class="nav-item tab-items rounded-top border-bottom-0 border" role="presentation"
                                onclick="wedding_planner()">
                                <a class="nav-link" id="wedding_planner-tab" data-toggle="tab" href="#wedding_planner"
                                    role="tab" aria-controls="wedding_planner" aria-selected="false">Wedding Planner</a>
                            </li>
                        </ul>
                        <div class="tab-content border border-top-0 rounded-bottom" id="myTabContent" style="
    border: 2px solid #dee2e6!important;
    border-top: 0px solid #dee2e6!important;
">
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- ---- -->

        <!-- footer -->
        <?php
    include("footer.php");
    ?>
        <!-- ------ -->

        <!--------------- Javascripts Link ------------->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script>
        $(document).ready(function() {
            venue();
        });

        function venue() {
            $.ajax({
                url: "booked_venue.php",
                type: "post",

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function photographer() {
            $.ajax({
                url: "booked_photographer.php",
                type: "post",

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function decorator() {
            $.ajax({
                url: "booked_decorator.php",
                type: "post",

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function catering() {
            $.ajax({
                url: "booked_catering.php",
                type: "post",

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function wedding_planner() {
            $.ajax({
                url: "booked_wedding_planner.php",
                type: "post",

                success: function(data, status) {
                    $("#myTabContent").html(data);
                }
            });
        }

        function cancle(book_id) {
            var cancle = confirm("Are you Sure to cancle your booking?");
            if (cancle) {
                $.ajax({
                    url: "booking_cancle.php",
                    type: "post",
                    data: {
                        book_id: book_id
                    },

                    success: function(data, status) {
                        alert(status);
                        window.location = "";
                    }
                });
            }
        }
        </script>
        <!-- ---------------------------------------- -->
    </body>

</html>
